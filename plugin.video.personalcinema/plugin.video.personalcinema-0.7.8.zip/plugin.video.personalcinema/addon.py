"""Thin Kodi navigation adapter. Provider and database code lives in resources.lib."""
import json
import os
import re
import sys
import time
from urllib.parse import parse_qsl, urlencode
from urllib.parse import urlparse

import xbmc
import xbmcgui
import xbmcplugin
from resources.lib.core import ProviderError, folder_bytes, inspect_source, normalize
from resources.lib.runtime import ADDON, setting, store, storage, storage_base, usage, tmdb, webshare, limit
from resources.lib.discovery import expand_query, rank_titles, assess_source, source_order, source_groups, candidate_order, filename_title
from resources.lib.subtitles import OpenSubtitles, movie_hash, rank_subtitles, language_code
from resources.lib.media import media_identity, validate_direct_url
from resources.lib.artwork import menu_art, source_art
from resources.lib.providers import (ArchiveProvider, LocalProvider, PROVIDER_NAMES,
                                    assess_candidate, candidate, resolve_candidate, youtube_id, ProviderCancelled)
from resources.lib.ct import CTProvider
from resources.lib.webvideo import WebVideoProvider, video_id
from resources.lib.provider_subtitles import cache_ct_subtitles
from resources.lib.http_addon import HTTPAddonProvider
from resources.lib.i18n import tr, display, Dialog, Progress, language, translation_batch

BASE, HANDLE = sys.argv[0], int(sys.argv[1])
PARAMS = dict(parse_qsl(sys.argv[2][1:]))
DB = store()
DIALOG = Dialog(xbmcgui.Dialog())
BROWSER = None
ART_ROOT = os.path.dirname(os.path.abspath(__file__))


def url(action, **args):
    return BASE + '?' + urlencode(dict(args, action=action))


@translation_batch()
def item(label, action, folder=True, data=None, secondary='', art=None, **args):
    external_title = data and label in (data.get('title'), data.get('name'))
    li = xbmcgui.ListItem(label=label if external_title else display(label), label2=display(secondary))
    li.setProperty('personalcinema.label', label)
    li.setProperty('personalcinema.secondary', secondary)
    li.setProperty('personalcinema.external_title', 'true' if external_title else '')
    li.setProperty('personalcinema.language', language())
    icon = menu_art(ART_ROOT, action, data, args)
    li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
    context = [('Back', 'Action(Back)'), ('Personal Cinema home',
                            'Container.Update(%s,replace)' % BASE),
                           ('Playback / subtitles', 'RunPlugin(%s)' % url('playback_tools'))]
    li.setProperty('personalcinema.context', json.dumps(context))
    li.addContextMenuItems([(tr(label), command) for label, command in context])
    if data:
        tag = li.getVideoInfoTag()
        tag.setTitle(data.get('title') or data.get('name') or label)
        tag.setPlot(display(data.get('overview') or ''))
        tag.setMediaType('episode' if data.get('media_type') == 'episode' else 'tvshow' if data.get('media_type') == 'tv' else 'movie')
        if data.get('vote_average'):
            tag.setRating(float(data['vote_average']), int(data.get('vote_count') or 0), 'tmdb', True)
        poster = data.get('poster_path')
        if poster:
            li.setArt({'poster': 'https://image.tmdb.org/t/p/w500' + poster,
                       'thumb': 'https://image.tmdb.org/t/p/w500' + poster})
        if data.get('backdrop_path'):
            li.setArt({'fanart': 'https://image.tmdb.org/t/p/w1280' + data['backdrop_path']})
        if data.get('image'):
            li.setArt({'poster': data['image'], 'thumb': data['image']})
    if art:
        li.setArt({'icon': art, 'thumb': art, 'poster': art})
        li.setProperty('personalcinema.source_art', art)
    if BROWSER:
        params = dict(args, action=action)
        # Opening a source is an action, not another blank directory.
        BROWSER.rows.append((li, params, folder and action not in ('source',)))
        return
    xbmcplugin.addDirectoryItem(HANDLE, url(action, **args), li, folder)


def finish():
    if BROWSER:
        BROWSER.render()
    else:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def launch_browser():
    """Finish the plugin directory before a separate script owns any GUI window."""
    host = xbmcgui.Window(10000)
    running = host.getProperty('personalcinema.browser.running')
    # A valid, cached landing page avoids another automatic launch when Kodi
    # restores/reloads its Videos container. This row also allows manual reopening.
    if HANDLE >= 0:
        item('Open Personal Cinema', 'open_browser', folder=False)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    if not running:
        host.setProperty('personalcinema.browser.running', 'starting')
        path = os.path.join(ART_ROOT, 'browser_entry.py')
        xbmc.executebuiltin('RunScript("%s")' % path)


def setup(require_storage=False):
    if setting('storage_mode_initialized') != 'true':
        ADDON.setSetting('storage_mode', '1' if setting('storage') else '0')
        ADDON.setSetting('storage_mode_initialized', 'true')
    root = storage()
    if not root:
        if require_storage:
            DIALOG.ok('Media storage disabled', 'Set a media folder in Settings → Storage to enable downloads and disk buffering.')
            return False
        if setting('storage_setup_done') == 'true':
            return True
        choice = DIALOG.select('Media storage', ['Stream only — no media folder', 'Choose a media folder'])
        ADDON.setSetting('storage_setup_done', 'true')
        if choice != 1:
            return True
        suggested = 'D:\\MovieLibrary\\' if os.name == 'nt' and os.path.isdir('D:\\') else ''
        if not suggested and xbmc.getCondVisibility('System.Platform.Android'):
            import xbmcvfs
            suggested = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        root = DIALOG.browseSingle(0, 'Choose a dedicated media folder (20 GB default)', 'files',
                                   defaultt=suggested)
        if not root:
            return True
        os.makedirs(root, exist_ok=True)
        ADDON.setSetting('storage', root)
        ADDON.setSetting('storage_mode', '1')
        root = storage()
    os.makedirs(root, exist_ok=True)
    return True


def catalogue(query=None, page=1):
    query = query or DIALOG.input('Search movies and TV shows')
    if not query:
        finish()
        return
    if page == 1:
        DB.remember_search(query)
    provider = tmdb()
    expanded = expand_query(query)
    try:
        result = provider.catalogue_search(expanded, page)
    except ProviderError:
        result = {'results': [], 'total_pages': 1}
        DIALOG.notification('TMDB', 'Catalogue unavailable; searching enabled public providers.')
    xbmcgui.Window(10000).setProperty('personalcinema.last_search', query)
    results = result.get('results', [])
    # Rank a small result pool, not just the first twenty arbitrary API matches.
    if page == 1:
        for next_page in range(2, min(result.get('total_pages', 1), 3) + 1):
            try:
                results.extend(provider.search(expanded, next_page).get('results', []))
            except ProviderError:
                break
    for data in rank_titles(results, expanded):
        kind = data.get('media_type')
        if kind not in ('movie', 'tv'):
            continue
        key = '%s:%s' % (kind, data['id'])
        DB.title(key, data)
        name = data.get('title') or data.get('name')
        year = (data.get('release_date') or data.get('first_air_date') or '')[:4]
        cached_rows = DB.db.execute("SELECT data FROM sources WHERE title_key=? AND provider NOT IN ('youtube','dailymotion')", (key,)).fetchall()
        count = sum(assess_candidate(json.loads(r[0]), [name, data.get('original_title') or data.get('original_name') or name],
                                 year, min_mb=float(setting('min_movie_mb') or 80),
                                 max_gb=float(setting('max_source_gb') or 20))['accepted'] for r in cached_rows)
        label = '%s (%s) | %s | TMDB %.1f' % (name, year, kind.upper(), data.get('vote_average', 0))
        if count:
            label += ' | %d cached sources' % count
        item(label, 'title', data=data, key=key, secondary='%s votes' % data.get('vote_count', 0))
    if page == 1:
        public_catalogue_results(expanded)
    next_page = 4 if page == 1 else page + 1
    if next_page <= result.get('total_pages', 1):
        item('More results', 'search', query=query, page=next_page)
    if not BROWSER:
        xbmcplugin.setContent(HANDLE, 'movies')
    finish()
    if not BROWSER and setting('poster_view') != 'false' and xbmc.getSkinDir() == 'skin.estuary':
        xbmc.executebuiltin('Container.SetViewMode(51)')


def title_page(key):
    data = DB.title(key)
    if data.get('native_provider'):
        if data.get('ct_show_id'):
            ct_show_page(data['ct_show_id'])
        else:
            source_page(key)
        return
    if key.startswith('tv:') and ':s' not in key:
        details = tmdb().get('tv/' + str(data['id']))
        for season in details.get('seasons', []):
            artwork = dict(data, poster_path=season.get('poster_path') or data.get('poster_path'),
                           overview=season.get('overview') or data.get('overview', ''))
            item(season['name'], 'season', key=key, season=season['season_number'], data=artwork)
    else:
        item('Find sources — all enabled providers', 'sources', key=key)
        item('Cached sources (availability may have changed)', 'sources', key=key, cached=1)
        item('Refine provider query (keeps selected title and episode)', 'sources', key=key, custom=1)
        item('Attach direct media URL to THIS title (not a webpage)', 'manual', folder=False, key=key)
        item('Find / download subtitles', 'subtitles', folder=False, key=key)
    item('Search ČT on-demand catalogue for this title', 'ct_search', query=data.get('name') or data.get('title') or '')
    item('Search Internet Archive for this title', 'archive_search', query=data.get('title') or data.get('name') or '')
    item('Where else is this available? (TMDB / JustWatch)', 'watch_providers', key=key, folder=False)
    finish()


def season_page(key, number):
    series = DB.title(key)
    details = tmdb().get('tv/%s/season/%s' % (series['id'], number))
    translated = {}
    if setting('enable_ct') == 'true':
        try:
            translated = {e['episode_number']:e['name'] for e in tmdb().get(
                'tv/%s/season/%s' % (series['id'], number), language='cs-CZ').get('episodes', [])}
        except ProviderError:
            pass
    for episode in details.get('episodes', []):
        epkey = '%s:s%se%s' % (key, number, episode['episode_number'])
        data = dict(series, season=number, episode=episode['episode_number'],
                    poster_path=details.get('poster_path') or series.get('poster_path'),
                    overview=episode.get('overview', ''), episode_name=episode['name'],
                    episode_match_names=list(dict.fromkeys(n for n in (episode['name'], translated.get(episode['episode_number'])) if n)))
        DB.title(epkey, data)
        item('S%02dE%02d - %s' % (number, episode['episode_number'], episode['name']),
             'title', key=epkey, data=data)
    finish()


def verified_names(key, data):
    parent_key = '%s:%s' % ('tv' if key.startswith('tv:') else 'movie', data['id'])
    parent = DB.title(parent_key) or data
    names = parent.get('match_names')
    # Version 2 includes the Slovak translation, even when TMDB does not list
    # it under alternative_titles. Refresh old caches on their next source lookup.
    if not names or parent.get('match_names_version', 0) < 2:
        names = tmdb().title_names('tv' if key.startswith('tv:') else 'movie', data['id'])
        parent['match_names'] = names
        parent['match_names_version'] = 2
        DB.title(parent_key, parent)
    return names


def source_page(key, cached=False, custom=False, show_hidden=False, edition_filter='All editions'):
    selected = DB.title(key) or {}
    if selected.get('native_provider') in ('youtube','dailymotion'):
        video_sources_page(key)
        return
    if BROWSER:
        BROWSER.current_key = key
        if BROWSER.params.get('action') != 'sources':
            BROWSER.params = {'action':'sources', 'key':key}
    data = DB.title(key)
    title = data.get('title') or data.get('name')
    year = (data.get('release_date') or data.get('first_air_date') or '')[:4]
    season, episode = data.get('season'), data.get('episode')
    if not cached and season is not None and not data.get('native_provider') and setting('enable_ct') == 'true' and not data.get('episode_match_names'):
        try:
            translated = tmdb().get('tv/%s/season/%s/episode/%s' % (data['id'], season, episode), language='cs-CZ')
            data['episode_match_names'] = list(dict.fromkeys(n for n in (data.get('episode_name'), translated.get('name')) if n))
            DB.title(key, data)
        except ProviderError:
            pass
    names = [title] if data.get('native_provider') else verified_names(key, data)
    minimum = float(setting('min_episode_mb') or 20) if season is not None else float(setting('min_movie_mb') or 80)
    maximum = float(setting('max_source_gb') or 20)
    if setting('http_providers') and not data.get('native_provider') and not data.get('imdb_id'):
        try:
            external = tmdb().get('%s/%s/external_ids' % ('tv' if season is not None else 'movie', data['id']))
            data['imdb_id'] = external.get('imdb_id')
            DB.title(key, data)
        except ProviderError:
            pass
    if data.get('native_provider'):
        if not cached:
            try:
                if data['native_provider'] == 'ct':
                    fresh = CTProvider().sources(data['ct_idec'])
                elif data['native_provider'] == 'archive':
                    fresh = ArchiveProvider().sources(data['archive_id'])
                elif data['native_provider'] == 'prehraj':
                    fresh=prehraj().sources({'id':data['video_id'],'page':data['prehraj_page'],'name':title+'.mp4'})
                    for src in fresh:src['native_selection']=True
                elif data['native_provider'] in ('youtube', 'dailymotion'):
                    fresh = video_task('Finding video qualities', lambda cancelled:
                                       web_video(data['native_provider']).sources(data['video_id'], cancelled=cancelled))
                else:
                    fresh = [data['local_source']]
                DB.record_check(key, names[0], fresh, provider=data['native_provider'])
            except ProviderCancelled:
                finish()
                return
            except ProviderError as exc:
                DB.record_check(key, names[0], [], 'restricted_or_unavailable', provider=data['native_provider'])
                item(str(exc), 'provider_checks', key=key, folder=False)
                if data.get('web_url'):
                    item('Open this programme on the official website', 'open_web', folder=False, link=data['web_url'])
                item('Retry provider', 'sources', key=key)
                finish()
                return
        cached = True
    if cached:
        rows = DB.db.execute('SELECT data,checked FROM sources WHERE title_key=?', (key,)).fetchall()
        sources = [json.loads(row['data']) for row in rows]
    else:
        queries = list(dict.fromkeys(names))[:6]
        if custom:
            q = DIALOG.input('Provider query — matching still uses ' + title, defaultt=queries[0])
            if not q:
                finish()
                return
            queries = [q]
            # Refine retrieval only. Arbitrary search text must not change the selected series identity.
        if setting('enable_webshare') == 'false':
            queries = []
        found, pages_limited = {}, False
        progress = Progress(xbmcgui.DialogProgress())
        progress.create('Finding sources', 'Checking title and episode matches...')
        try:
            provider = webshare()
            cancelled = False
            for index, q in enumerate(queries):
                # Search title first: broad episode tokens can dominate provider results.
                pages = 4 if season is not None else 2
                for offset in range(0, pages * 50, 50):
                    if progress.iscanceled():
                        cancelled = True
                        break
                    progress.update(int(index * 100 / len(queries)), 'Searching ' + q)
                    results, total = provider.search(q, offset)
                    for src in results:
                        found[src['id']] = src
                    if offset + 50 >= total:
                        break
                    if offset == (pages - 1) * 50:
                        pages_limited = True
                if cancelled:
                    break
            sources = list(found.values())
            assessed = [assess_source(s, names, year, season, episode, minimum, maximum) for s in sources]
            DB.record_check(key, ' | '.join(queries), assessed,
                            'disabled' if not queries else 'cancelled' if cancelled else 'ok')
            sources = assessed
        except ProviderError:
            DB.record_check(key, ' | '.join(queries), [], 'provider_error')
            sources = []
            DIALOG.notification('Webshare', 'Search unavailable; other providers will still be checked.')
        finally:
            progress.close()
        if cancelled:
            finish()
            return
        if pages_limited:
            DIALOG.notification('Personal Cinema', 'Search capped; use a more specific title if your episode is missing.')
        progress = Progress(xbmcgui.DialogProgress())
        progress.create('Free providers', 'Checking login-free sources...')
        try:
            providers = free_providers()
            for index, (provider_id, provider) in enumerate(providers):
                if progress.iscanceled():
                    DB.record_check(key, title, [], 'cancelled', provider=provider_id)
                    break
                progress.update(int(index*100/max(1,len(providers))), 'Checking ' + PROVIDER_NAMES[provider_id])
                if season is not None and provider_id == 'archive':
                    DB.record_check(key, title, [], 'browse_native_episodes', provider=provider_id)
                    continue
                try:
                    fresh = provider.find(data, names, progress.iscanceled)
                    fresh = [assess_candidate(s, names, year, season, episode, minimum, maximum) for s in fresh]
                    DB.record_check(key, ' | '.join(names[:3]), fresh, provider=provider_id)
                    sources.extend(fresh)
                except ProviderCancelled:
                    DB.record_check(key, title, [], 'cancelled', provider=provider_id)
                    break
                except (ProviderError, OSError, ValueError):
                    DB.record_check(key, title, [], 'provider_error', provider=provider_id)
                    DIALOG.notification(PROVIDER_NAMES[provider_id], 'Search unavailable. Its previous cache is preserved.')
                    sources.extend(json.loads(row['data']) for row in DB.db.execute('SELECT data FROM sources WHERE title_key=? AND provider=?',(key,provider_id)))
        finally:
            progress.close()
    pinned = DB.pinned_sources(key)
    by_id = {(s['provider'], s['id']): s for s in sources}
    for src in pinned:
        if (src['provider'], src['id']) not in by_id:
            by_id[(src['provider'], src['id'])] = src
    sources = list(by_id.values())
    if not data.get('native_provider'):
        sources = [s for s in sources if s['provider'] not in ('youtube','dailymotion')]
    # Apply current filters to old caches as well; never expose executables in overrides.
    sources = [assess_candidate(s, names, year, season, episode, minimum, maximum) for s in sources]
    # Keep cached scoring in agreement with the list and subsequent source-action dialog.
    with DB.db:
        DB.db.executemany('UPDATE sources SET data=? WHERE title_key=? AND provider=? AND ident=?',
                         [(json.dumps(s), key, s['provider'], s['id']) for s in sources])
    file_sources = [s for s in sources if s['provider'] in ('webshare', 'local', 'prehraj')]
    accepted, hidden, ignored = source_groups(file_sources)
    accepted += [s for s in sources if s['provider'] not in ('webshare', 'local', 'prehraj') and s.get('accepted')]
    hidden += [s for s in sources if s['provider'] not in ('webshare', 'local', 'prehraj') and not s.get('accepted')]
    displayed = [s for s in accepted if edition_filter == 'All editions' or s['edition'] == edition_filter]
    if show_hidden:
        displayed += hidden
    displayed.sort(key=lambda s: candidate_order(s, setting('audio_primary')))
    selection = title + (' — S%02dE%02d' % (season, episode) if season is not None else '')
    if show_hidden:
        item('Filtered video candidates for ' + selection, 'source_help', folder=False, key=key,
             secondary='Closest episode/title first. These files did not pass automatic matching.')
    elif not accepted:
        item('No automatic match for ' + selection, 'source_help', folder=False, key=key,
             secondary='Matching aliases: %s | %d video candidates filtered; %d non-video files ignored.' % (' / '.join(names[:3]), len(hidden), ignored))
    elif not displayed:
        item('No sources labelled ' + edition_filter, 'source_help', folder=False, key=key,
             secondary='Change the edition filter to see other video sources.')
    for i, src in enumerate(displayed):
        marker = PROVIDER_NAMES.get(src['provider'], src['provider']) + ' | '
        if any(p['provider'] == src['provider'] and p['id'] == src['id'] for p in pinned):
            marker += 'Confirmed match | '
        if not src['accepted']:
            marker = 'Filtered: ' + src['rejection'] + ' | '
        detected = ('S%02dE%02d | ' % (src['detected_season'], src['detected_episode'])) if src.get('detected_season') is not None else ''
        label = '%s%s | %s | %s%s | %s' % (marker, src['quality'], src['edition'], src['languages'],
                '' if src.get('language_verified') else ' (hint)',
                '%.2f GB' % (src['size'] / 1e9) if src.get('size') else 'Size unknown / stream')
        viewdata = dict(data, overview='Selected: ' + selection + '\nFilename title: ' + src['detected_title'] +
                        '\nDetected episode: ' + (detected.rstrip(' |') or 'Unrecognised') + '\n\n' + src['name'] + '\n\n' + src['metadata'] +
                        '\n\nUse playback controls to inspect actual audio/subtitle tracks.')
        DB.execute('INSERT OR IGNORE INTO sources VALUES (?,?,?,?,?)',
                   (key, src['provider'], src['id'], json.dumps(src), time.time()))
        item(label, 'source', key=key, ident=src['id'], provider=src['provider'], data=viewdata,
             secondary=detected + src['name'], art=source_art(ART_ROOT, src))
    if data.get('native_provider'):
        item('Refresh provider sources', 'sources', key=key)
    else:
        if setting('enable_oneplay')=='true':
            item('Search this title on Oneplay','oneplay_search',query=title,
                 secondary='Checks the Oneplay catalogue · availability/subscription not yet verified')
        item('Search again / refine title', 'sources', key=key, custom=1)
        if season is not None:
            item('Browse ČT programme episodes (provider numbering)', 'ct_search', query=names[0],
                 secondary='Fallback when a unique translated episode-title match cannot be established.')
    item('Filter editions: ' + edition_filter, 'edition_filter', key=key, folder=False)
    checks = DB.db.execute('SELECT provider,outcome,count,checked FROM checks WHERE title_key=? ORDER BY checked DESC LIMIT 10', (key,)).fetchall()
    if checks:
        detail = ' | '.join('%s: %s (%d)' % (PROVIDER_NAMES.get(r['provider'], r['provider']), r['outcome'], r['count']) for r in checks)
        item('Provider checks / availability', 'provider_checks', key=key, folder=False, secondary=detail)
    if hidden and not show_hidden:
        item('%d video candidates filtered — inspect reasons' % len(hidden), 'sources', key=key, cached=1, show_hidden=1)
    if not BROWSER:
        xbmcplugin.setContent(HANDLE, 'files')
    finish()
    if not BROWSER and xbmc.getSkinDir() == 'skin.estuary':
        xbmc.executebuiltin('Container.SetViewMode(50)')


def log_playback(key, media_key, provider, status, detail=''):
    DB.execute('INSERT INTO playback_events(title_key,media_key,provider,status,detail,created) VALUES (?,?,?,?,?,?)',
               (key, media_key, provider, status, detail, time.time()))


def resolve_source(src, key):
    try:
        if src['provider'] == 'prehraj':
            provider=prehraj()
            status=provider.cached_status()
            if status['subscription']!='active':
                DIALOG.notification('Přehraj access', 'Premium is inactive; free access can have limits.' if status['subscription']=='inactive'
                                    else 'Subscription unverified; provider limits may apply to public playback.')
            return provider.resolve(src)
        if src['provider'] == 'webshare':
            return {'url': webshare().resolve(src['id'])}
        if src['provider'] in ('youtube', 'dailymotion'):
            return video_task('Opening video stream', lambda cancelled:
                              web_video(src['provider']).resolve(src, cancelled=cancelled))
        if src['provider'].startswith('httpaddon_'):
            provider = next((p for ident,p in http_providers() if ident == src['provider']), None)
            if not provider:
                raise ProviderError('This HTTP provider was removed from settings. Add it again to refresh its streams.')
            provider.manifest()
            return provider.resolve(src)
        resolved = resolve_candidate(src, setting('local_library'))
        if src['provider'] == 'ct' and resolved.get('subtitle_tracks'):
            try:
                resolved['subtitles'] = cache_ct_subtitles(resolved, src['ct_idec'], storage(), limit(), usage())
            except (ProviderError, OSError):
                resolved['subtitles'] = []
                DIALOG.notification('ČT subtitles', 'Provider subtitles could not be cached. Check storage or use local/OpenSubtitles files.')
        return resolved
    except ProviderCancelled:
        log_playback(key, media_identity(key, src['provider'], src['id']), src['provider'], 'cancelled')
        raise
    except ProviderError as exc:
        log_playback(key, media_identity(key, src['provider'], src['id']), src['provider'], 'failed', str(exc))
        raise


def play(path, key, source=None):
    data = DB.title(key) or {}
    resolved = path if isinstance(path, dict) else {'url': path}
    path = resolved['url']
    headers = {k:v for k,v in resolved.get('headers', {}).items() if k.lower() in ('user-agent','referer','origin')}
    if headers:
        path += '|' + urlencode(headers)
    li = xbmcgui.ListItem(path=path)
    if resolved.get('mime'):
        li.setMimeType(resolved['mime'])
        li.setContentLookup(False)
        if resolved['mime'] in ('application/vnd.apple.mpegurl','application/x-mpegURL') and xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if headers:
                li.setProperty('inputstream.adaptive.stream_headers', urlencode(headers))
    if resolved.get('subtitles'):
        li.setSubtitles(resolved['subtitles'])
    li.setProperty('IsPlayable', 'true')
    li.getVideoInfoTag().setTitle(data.get('title') or data.get('name') or 'Personal Cinema')
    source = source or {'provider': 'direct', 'id': path, 'name': 'Direct stream', 'size': 0}
    media_key = media_identity(key, source['provider'], source['id'])
    row = DB.db.execute('SELECT * FROM progress WHERE title_key=?', (media_key,)).fetchone()
    if row and row['position'] > 20 and row['position'] < row['duration'] * .95:
        if DIALOG.yesno('Resume playback', 'Resume at %d minutes?' % (row['position'] / 60)):
            li.setProperty('StartOffset', str(row['position']))
    # Reserve the buffer after the user answers Resume, so the service's
    # playback-start timeout cannot expire while that dialog is open.
    if storage() and setting('disk_cache')=='true' and source.get('provider') in ('webshare','archive','prehraj') and urlparse(resolved['url']).scheme=='https':
        try:resolved=buffer_to_disk(resolved,key,source,data)
        except ProviderCancelled:return
        path=resolved['url']
        li.setPath(path)
    # Service uses the title key to apply preferences and persist progress.
    sub = DB.db.execute('SELECT path FROM media_subtitles WHERE media_key=?', (media_key,)).fetchone()
    subtitle = sub[0] if sub and os.path.isfile(sub[0]) else ''
    if subtitle:
        li.setSubtitles([subtitle])
    pending = {'key': media_key, 'title_key': key, 'path': path, 'subtitle': subtitle,
               'release': source['name'], 'size': source.get('size', 0), 'provider': source['provider'],
               'source_id': source.get('id', '')}
    xbmcgui.Window(10000).setProperty('personalcinema.pending', json.dumps(pending))
    log_playback(key, media_key, source['provider'], 'attempted', source['name'])
    # Keep one add-on window behind Kodi's native player; no playback XML dialog.
    xbmc.Player().play(path, li, windowed=False)


def buffer_to_disk(resolved,key,source,data):
    import uuid
    if not source.get('size'):
        raise ProviderError('This source has no verified size for disk reservation. Disable disk buffering or choose another source.')
    if not storage():raise ProviderError('Choose a managed media folder before using disk buffering.')
    ident=uuid.uuid4().hex
    host=xbmcgui.Window(10000)
    if host.getProperty('personalcinema.cache.active'):
        xbmc.Player().stop()
    DB.execute("INSERT INTO cache_jobs(id,title_key,source,data,size,state,keep,created) VALUES (?,?,?,?,?,'queued',?,?)",
               (ident,key,json.dumps(source),json.dumps(data),source['size'],int(setting('disk_cache_keep')=='true'),time.time()))
    prop='personalcinema.cache.request.'+ident
    host.setProperty(prop,json.dumps(resolved))
    progress=Progress(xbmcgui.DialogProgress());progress.create('Preparing disk buffer','Reserving disk space. Downloading continues while playback is paused.')
    monitor=xbmc.Monitor()
    try:
        for _ in range(200):
            if progress.iscanceled() or monitor.abortRequested() or BROWSER and getattr(BROWSER,'closing',False):break
            row=DB.db.execute('SELECT state,error FROM cache_jobs WHERE id=?',(ident,)).fetchone()
            if row and row['state'] in ('ready','complete'):
                base=host.getProperty('personalcinema.cache.base')
                if not re.fullmatch(r'http://127\.0\.0\.1:\d+/[a-f0-9]{32}/',base):raise ProviderError('Local cache endpoint is unavailable. Restart Kodi.')
                return dict(resolved,url=base+ident,headers={})
            if row and row['state']=='failed':raise ProviderError(row['error'])
            if monitor.waitForAbort(.1):break
        DB.execute("UPDATE cache_jobs SET state='cancelled' WHERE id=?",(ident,))
        raise ProviderCancelled('Disk buffer preparation cancelled or timed out. Restart Kodi if the service was updated.')
    finally:
        host.clearProperty(prop);progress.close()


def cache_status():
    rows=DB.db.execute('SELECT * FROM cache_jobs ORDER BY created DESC').fetchall()
    for row in rows:
        data=json.loads(row['data'])
        name=data.get('title') or data.get('name') or 'Video'
        if data.get('season') is not None:name+=' S%02dE%02d' % (data['season'],data['episode'])
        item(name,'cache_action',folder=False,ident=row['id'],data=data,
             secondary='%s · %d%% buffered · %.2f GB reserved%s%s' % (row['state'],int(row['bytes']*100/max(1,row['size'])),row['size']/1e9,
                        ' · Keep for later' if row['keep'] else ' · Temporary', ' · '+row['error'] if row['error'] else ''))
    if not rows:item('No active disk buffer','settings',folder=False,secondary='Enable disk buffering in Storage. Webshare, Archive and Přehraj file sources are supported.')
    finish()


def cache_action(ident):
    choice=DIALOG.select('Disk buffer',['Keep completed video in Downloads','Delete temporary buffer after playback','Stop playback and discard temporary buffer'])
    row=DB.db.execute('SELECT state,keep FROM cache_jobs WHERE id=?',(ident,)).fetchone()
    if choice==1 and row and row['state']=='complete' and row['keep']:
        DIALOG.ok('Video already saved','This completed video is saved in Downloads. Remove it there when no longer needed.')
        return
    if choice in (0,1):DB.execute('UPDATE cache_jobs SET keep=? WHERE id=?',(int(choice==0),ident))
    elif choice==2:
        xbmc.Player().stop()
        DB.execute("UPDATE cache_jobs SET state='cancelled' WHERE id=?",(ident,))


def source_action(key, ident, provider='webshare'):
    row = DB.db.execute('SELECT data FROM sources WHERE title_key=? AND provider=? AND ident=?', (key, provider, ident)).fetchone()
    if not row:
        raise ProviderError('Source no longer cached; search again.')
    src = json.loads(row['data'])
    if provider in ('youtube', 'dailymotion'):
        try:
            resolved = resolve_source(src, key)
        except ProviderCancelled:
            return
        if not BROWSER or not getattr(BROWSER, 'closing', False):
            play(resolved, key, src)
        return
    data = DB.title(key)
    names = [data.get('title') or data.get('name')] if data.get('native_provider') else verified_names(key, data)
    minimum = float(setting('min_episode_mb') or 20) if data.get('season') is not None else float(setting('min_movie_mb') or 80)
    src = assess_candidate(src, names, (data.get('release_date') or data.get('first_air_date') or '')[:4],
                        data.get('season'), data.get('episode'), minimum, float(setting('max_source_gb') or 20))
    options = ['Stream now', 'Choose subtitles, then stream', 'Save for later (download queue)', 'Source information',
               'Confirm this source belongs to this title', 'Forget confirmed match']
    if data.get('web_url'):
        options.append('Open the official programme website')
    action = DIALOG.select(src['name'], options)
    if src.get('accepted') is False and action in (0, 1, 2):
        if src.get('identity_match') is False:
            DIALOG.ok('Different series or episode', 'This filename does not match the selected series and episode. It cannot be played as that episode. Check Source information for the selected title and detected filename.')
            return
        if not DIALOG.yesno('Filtered source', src.get('rejection', 'Uncertain match') + '. Use this video anyway?'):
            return
    if action == 0:
        try:
            resolved = resolve_source(src, key)
        except ProviderCancelled:
            return
        play(resolved, key, src)
    elif action == 1:
        try:
            path = resolve_source(src, key)
        except ProviderCancelled:
            return
        media_key = media_identity(key, src['provider'], ident)
        if subtitle_picker(key, src['name'], media_key, path['url'], src.get('size', 0)):
            play(path, key, src)
    elif action == 2:
        if src['provider'] not in ('webshare', 'archive', 'prehraj'):
            raise ProviderError('Offline saving is available for Webshare, Internet Archive and accessible Přehraj files. This source streams only.')
        if not setup(require_storage=True):
            return
        filename = re.sub(r'[^A-Za-z0-9._-]', '_', src['name'])[:150]
        from hashlib import sha256
        prefix = sha256((src['provider'] + ':' + ident).encode('utf-8')).hexdigest()[:16]
        target = os.path.join(storage(), prefix + '-' + filename)
        used = usage()
        if not src['size'] or used + src['size'] > limit():
            raise ProviderError('File size unknown or download exceeds the storage limit.')
        DB.execute('INSERT OR IGNORE INTO downloads(title_key,source,path,state) VALUES (?,?,?,?)',
                   (key, json.dumps(src), target, 'queued'))
        download = DB.db.execute('SELECT id FROM downloads WHERE path=?', (target,)).fetchone()
        DB.execute('INSERT OR REPLACE INTO download_info VALUES (?,?)', (download[0], json.dumps(data)))
        DIALOG.notification('Personal Cinema', 'Added to download queue')
    elif action == 4:
        if not src.get('accepted'):
            raise ProviderError('A filtered filename cannot be confirmed as a different title or episode.')
        DB.pin_source(key, src)
        DIALOG.notification('Personal Cinema', 'Confirmed source match saved locally')
    elif action == 5:
        DB.execute('DELETE FROM source_matches WHERE title_key=? AND provider=? AND ident=?', (key, provider, ident))
        DIALOG.notification('Personal Cinema', 'Confirmed match removed')
    elif action == 6 and data.get('web_url'):
        import webbrowser
        webbrowser.open(data['web_url'])
    elif action == 3:
        selected = DB.title(key) or {}
        title = selected.get('title') or selected.get('name') or key
        if selected.get('season') is not None:
            title += ' S%02dE%02d' % (selected['season'], selected['episode'])
        detected_episode = 'Unrecognised'
        if src.get('detected_season') is not None:
            detected_episode = 'S%02dE%02d' % (src['detected_season'], src['detected_episode'])
        native = src['provider'] not in ('webshare', 'local')
        provenance = src.get('metadata', '') if native else 'Quality, edition and title are filename hints.'
        audio_label = 'Reported audio tracks' if src.get('language_verified') else 'Language hints (unverified)'
        DIALOG.textviewer('Source details', 'Selected: %s\nProvider: %s\nSource title: %s\nDetected episode: %s\n\nMatch: %s\n\nQuality: %s\nEdition: %s\n%s: %s\nSize: %s\n\nSource name:\n%s\n\n%s' %
                          (title, PROVIDER_NAMES.get(src['provider'], src['provider']),
                           src.get('detected_title') or filename_title(src['name']), tr(detected_episode),
                           tr(src.get('rejection') or ('Provider catalogue selection' if native else 'Automatic filename match')),
                           tr(src['quality']), tr(src['edition']), tr(audio_label), tr(src['languages']),
                           '%.2f GB' % (src['size'] / 1e9) if src['size'] else tr('Unknown / streamed'), src['name'], display(provenance)))
    finish()


def accounts(group=''):
    if group == 'oneplay':
        oneplay_settings()
        return
    groups = {'webshare': ('Webshare', [('Username / email', 'ws_user', False), ('Password', 'ws_password', True)]),
              'prehraj': ('Přehraj.to', [('Email', 'prehraj_user', False), ('Password', 'prehraj_password', True)]),
              'tmdb': ('TMDB catalogue', [('API Read Access Token', 'tmdb_token', True)]),
              'subtitles': ('OpenSubtitles.com', [('API key', 'os_key', True), ('Username (optional)', 'os_user', False),
                                               ('Password (optional)', 'os_password', True)])}
    if not group:
        while True:
            selected = DIALOG.select('Accounts and services', ['Webshare', 'Přehraj.to', 'Oneplay', 'TMDB catalogue', 'OpenSubtitles.com', 'Receive accounts — QR pairing', 'Send saved accounts', 'Done'])
            if selected < 0 or selected == 7:
                return
            if selected in (5, 6):
                from resources.lib.pairing import receive_ui, send_ui
                (receive_ui if selected == 5 else send_ui)(ADDON)
            else:
                accounts(['webshare', 'prehraj', 'oneplay', 'tmdb', 'subtitles'][selected])
    title, fields = groups[group]
    while True:
        labels = [name + (' [saved]' if setting(key) else ' [not set]') for name, key, _ in fields]
        extras = ['Test login / use saved account','Check access / subscription','Done'] if group=='prehraj' else ['Test login', 'Done'] if group=='webshare' else ['Done']
        choice = DIALOG.select(title + ' — each field saves immediately', labels + extras)
        if choice < 0 or choice == len(fields) + len(extras) - 1:
            return
        if group == 'webshare' and choice == len(fields):
            webshare().login()
            DIALOG.ok('Webshare', 'Login successful.')
            continue
        if group == 'prehraj' and choice == len(fields):
            status=prehraj().login()
            DIALOG.ok('Přehraj.to', 'Login successful. Subscription: '+status['subscription']+
                      '. Unknown means the provider did not expose a reliable status. Free playback may have limits; premium is a separate subscription.')
            continue
        if group == 'prehraj' and choice == len(fields)+1:
            status=prehraj().status()
            DIALOG.ok('Přehraj access', ('Signed in' if status['signed_in'] else 'Not signed in — using public access')+
                      '\nSubscription: '+status['subscription']+'.\nInactive: premium playback may be unavailable. Unknown: status could not be verified; no subscription is assumed.')
            continue
        name, key, secret = fields[choice]
        keyboard = xbmc.Keyboard('' if secret else setting(key), tr(name), secret)
        keyboard.doModal()
        if keyboard.isConfirmed():
            value = keyboard.getText()
            if value:
                ADDON.setSetting(key, value.strip() if key.endswith('token') or key.endswith('_key') else value)
                if group == 'prehraj':
                    # Stored cookies must not keep a previous account signed in.
                    import xbmcvfs
                    session=os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),'prehraj-session.cookies')
                    if os.path.isfile(session):os.remove(session)
                    access=os.path.join(os.path.dirname(session),'prehraj-access.json')
                    if os.path.isfile(access):os.remove(access)
                DIALOG.notification('Personal Cinema', name + ' saved')
            elif DIALOG.yesno('Clear saved value?', 'Remove ' + name + '?'):
                ADDON.setSetting(key, '')
                if group == 'prehraj':
                    import xbmcvfs
                    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
                    for filename in ('prehraj-session.cookies', 'prehraj-access.json'):
                        path = os.path.join(profile, filename)
                        if os.path.isfile(path):
                            os.remove(path)


def subtitle_picker(key, release='', media_key='', media_url='', media_size=0):
    data = DB.title(key)
    if not data:
        raise ProviderError('Choose a movie or episode first.')
    active_json = xbmcgui.Window(10000).getProperty('personalcinema.active')
    active = json.loads(active_json) if active_json else {}
    if not media_key and active.get('title_key') == key and xbmc.Player().isPlayingVideo():
        media_key, media_url = active['key'], active['path']
        release, media_size = active.get('release', ''), active.get('size', 0)
    if not media_key:
        DIALOG.ok('Choose a video source first', 'Use “Choose subtitles, then stream” on a source, or use the Subtitles button while watching. This lets suggestions match the actual video release.')
        return None
    choice = DIALOG.select('Subtitles', ['Find on OpenSubtitles.com', 'Choose a local subtitle file', 'Disable subtitles'])
    if choice < 0:
        return None
    if choice == 2:
        DB.execute('DELETE FROM media_subtitles WHERE media_key=?', (media_key,))
        if xbmc.Player().isPlayingVideo():
            xbmc.Player().showSubtitles(False)
        return None
    if choice == 1:
        path = DIALOG.browseSingle(1, 'Choose subtitles', 'files', mask='.srt|.ass|.ssa|.vtt')
        if not path:
            return None
    else:
        provider = OpenSubtitles(setting('os_key'), setting('os_user'), setting('os_password'))
        provider.login()
        fingerprint = movie_hash(media_url, media_size) if media_url else None
        results = provider.search(data.get('title') or data.get('name'),
                                  [setting('subtitle_primary') or 'eng', setting('subtitle_secondary')],
                                  None if data.get('native_provider') else data.get('id'),
                                  data.get('season'), data.get('episode'), fingerprint)
        if not results:
            DIALOG.ok('OpenSubtitles', 'No subtitles found for this movie or episode and the selected languages.')
            return None
        language = language_code(setting('subtitle_primary') or 'eng')
        results = rank_subtitles(results, release, language)
        files, labels = [], []
        for result in results:
            a = result.get('attributes', {})
            for file in a.get('files', []):
                labels.append('%s | %s | %s%s' % (a.get('language', '?'), result['match_reason'],
                              a.get('release') or file.get('file_name', ''),
                              ' | hearing impaired' if a.get('hearing_impaired') else ''))
                files.append(file)
        if not files:
            DIALOG.ok('OpenSubtitles', 'Results contained no downloadable subtitle files.')
            return None
        short = labels[:5]
        if len(files) > 5:
            short += ['Show all %d subtitle files' % len(files)]
        selected = DIALOG.select('Suggested subtitles — ' + (release or 'selected video'), short)
        if len(files) > 5 and selected == 5:
            selected = DIALOG.select('All subtitles — timing is unverified without a fingerprint match', labels)
        if selected < 0:
            return None
        if not setup(require_storage=True):
            return None
        path = provider.save(files[selected]['file_id'], storage(), limit(), usage())
    DB.execute('INSERT OR REPLACE INTO media_subtitles VALUES (?,?,?)', (media_key, key, path))
    active = xbmcgui.Window(10000).getProperty('personalcinema.active')
    if active and json.loads(active).get('key') == media_key and xbmc.Player().isPlayingVideo():
        xbmc.Player().setSubtitles(path)
        xbmc.Player().showSubtitles(True)
    DIALOG.notification('Personal Cinema', 'Subtitles selected — adjust timing in Kodi if needed')
    return path


def playback_tools():
    player = xbmc.Player()
    if not player.isPlayingVideo():
        DIALOG.ok('Playback tools', 'Start a video first. During playback you can also use Kodi’s audio/subtitle controls.')
        return
    active = xbmcgui.Window(10000).getProperty('personalcinema.active')
    info = json.loads(active) if active else {}
    key = info.get('title_key', '')
    choice = DIALOG.select('Playback tools', ['Download / select subtitles', 'Select embedded audio track',
                                          'Select embedded subtitles', 'Subtitle timing / Kodi controls'])
    if choice == 0 and key:
        subtitle_picker(key)
    elif choice in (1, 2):
        prop = 'audiostreams' if choice == 1 else 'subtitles'
        response = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                              'params': {'playerid': 1, 'properties': [prop]}})))
        streams = response.get('result', {}).get(prop, [])
        options = ['%s | %s' % (s.get('language') or 'Unknown language', s.get('name') or s.get('codec') or '') for s in streams]
        index = DIALOG.select('Available tracks', options)
        if index >= 0:
            if choice == 1:
                player.setAudioStream(streams[index]['index'])
            else:
                player.setSubtitleStream(streams[index]['index'])
                player.showSubtitles(True)
    elif choice == 3:
        xbmc.executebuiltin('ActivateWindow(SubtitleSettings)')


def downloads(group='', series='', season=''):
    rows=[]
    for row in DB.db.execute('SELECT d.*,i.data AS metadata FROM downloads d LEFT JOIN download_info i ON i.download_id=d.id ORDER BY d.id DESC'):
        data=json.loads(row['metadata']) if row['metadata'] else DB.title(row['title_key']) or {}
        src=json.loads(row['source'])
        is_tv=data.get('season') is not None
        if group=='movies' and is_tv or group=='tv' and not is_tv:continue
        if group=='active' and row['state']=='complete':continue
        if series and str(data.get('id') or data.get('name') or data.get('title'))!=series:continue
        if season and str(data.get('season'))!=season:continue
        rows.append((row,data,src))
    if not group:
        for label,ident in [('All downloads','all'),('Movies','movies'),('TV shows / seasons','tv'),('Queued / downloading / paused','active')]:
            item(label,'downloads',group=ident)
        item('Disk buffering / keep cached video','cache_status')
    elif group=='tv' and not series:
        seen=set()
        for row,data,src in rows:
            ident=str(data.get('id') or data.get('name') or data.get('title'))
            if ident in seen:continue
            seen.add(ident)
            item(data.get('name') or data.get('title') or 'TV show','downloads',group='tv',series=ident,data=data)
    elif group=='tv' and not season:
        seen=set()
        for row,data,src in rows:
            number=str(data.get('season'))
            if number in seen:continue
            seen.add(number)
            item('Season '+number,'downloads',group='tv',series=series,season=number,data=data)
    else:
        for row,data,src in rows:
            title=data.get('title') or data.get('name') or src.get('name') or 'Saved video'
            if data.get('season') is not None:
                title+=' · S%02dE%02d' % (data['season'],data['episode'])
                if data.get('episode_name'):title+=' · '+data['episode_name']
            total=int(src.get('size') or 0)
            percent=' · %d%%' % min(100,int(row['bytes']*100/total)) if total else ''
            detail='%s%s · %.2f / %s GB · %s · %s' % (row['state'],percent,row['bytes']/1e9,
                    '%.2f' % (total/1e9) if total else '?',src.get('quality','Unknown quality'),src.get('languages','Unknown audio'))
            if row['error']:detail+=' · '+row['error']
            item(title,'download',folder=False,download_id=row['id'],data=data,secondary=detail)
        if not rows:item('No downloads in this category','downloads',group='all')
    finish()


def free_providers():
    result = []
    if setting('enable_ct') == 'true':
        result.append(('ct', CTProvider()))
    if setting('enable_archive') == 'true':
        result.append(('archive', ArchiveProvider()))
    if setting('local_library'):
        result.append(('local', LocalProvider(setting('local_library'))))
    if setting('enable_prehraj') == 'true':
        result.append(('prehraj', prehraj()))
    result.extend(http_providers())
    return result


def prehraj():
    from resources.lib.runtime import prehraj as client
    return client()


def oneplay_settings():
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.oneplay)'):
        choice=DIALOG.select('Oneplay setup',['Install Oneplay Kodi add-on','Setup information','Cancel'])
        if choice==0:xbmc.executebuiltin('InstallAddon(plugin.video.oneplay)')
        elif choice==1:DIALOG.textviewer('Oneplay setup','Install the community Oneplay add-on by waladir from your Kodi repository, then return here.\nSource: https://github.com/waladir/plugin.video.oneplay\n\nIt owns your Oneplay login, profile and Widevine setup. Active subscription is required for subscribed content. Android playback verification is pending.')
        return
    import xbmcaddon
    addon=xbmcaddon.Addon('plugin.video.oneplay')
    addon.openSettings()


def oneplay_page(link='',query=''):
    from resources.lib.oneplay import route,checked,directory
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.oneplay)'):
        item('Set up Oneplay first','accounts',folder=False,group='oneplay',secondary='Oneplay add-on missing · account / DRM setup required')
        finish();return
    if not link:
        item('Oneplay account / profile / DRM settings','accounts',folder=False,group='oneplay',
             secondary='Subscription and playback not verified by Personal Cinema; Oneplay checks entitlement when opening content.')
        item('Browse Oneplay catalogue','oneplay_browse',link=route('list_categories',label='Oneplay'))
        item('Search Oneplay','oneplay_search',query=query)
        finish();return
    for row in directory(checked(link)):
        target=row.get('file','')
        if not target.startswith('plugin://plugin.video.oneplay/'):continue
        data={'title':row.get('title') or row.get('label') or 'Oneplay','overview':row.get('plot') or '', 'image':row.get('thumbnail')}
        is_folder=row.get('filetype')=='directory'
        item(row.get('label') or data['title'],'oneplay_browse' if is_folder else 'oneplay_play',
             folder=is_folder,link=checked(target),data=data,secondary='Oneplay · provider account / entitlement applies')
    finish()


def oneplay_search(query=''):
    from resources.lib.oneplay import route
    query=query or DIALOG.input('Search Oneplay films and series')
    if query:oneplay_page(route('program_search',query=query,label='Oneplay — '+query))
    else:finish()


def http_providers():
    result = []
    for link in setting('http_providers').split(';'):
        if link.strip():
            provider = HTTPAddonProvider(link)
            PROVIDER_NAMES[provider.id] = provider.name
            result.append((provider.id, provider))
    return result


def manage_providers():
    links = [s for s in setting('http_providers').split(';') if s]
    while True:
        index = DIALOG.select('Public HTTP stream providers', ['Add a public manifest URL'] + links + ['Done'])
        if index < 0 or index == len(links)+1:
            return
        if index == 0:
            link = DIALOG.input('Public HTTPS manifest.json URL (login-free)').strip()
            if link:
                provider = HTTPAddonProvider(link)
                provider.manifest()
                if link not in links:
                    links.append(link)
        elif DIALOG.yesno('Remove provider?', 'Remove this stream index from Personal Cinema?'):
            links.pop(index-1)
        ADDON.setSetting('http_providers', ';'.join(links))


def web_video(provider='youtube'):
    import xbmcvfs
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    return WebVideoProvider(ART_ROOT, provider, os.path.join(profile, 'playback-manifests'))


def video_task(label, operation):
    progress = Progress(xbmcgui.DialogProgress())
    progress.create(label, 'Resolving public video metadata. You can cancel this operation.')
    try:
        monitor = xbmc.Monitor()
        def cancelled():
            return progress.iscanceled() or monitor.abortRequested() or bool(BROWSER and getattr(BROWSER, 'closing', False))
        result = operation(cancelled)
        if cancelled():
            raise ProviderCancelled()
        return result
    finally:
        progress.close()
        # Keep the Python wrapper alive until the native closing animation ends.
        monitor = xbmc.Monitor()
        for _ in range(40):
            if not xbmc.getCondVisibility('System.HasModalDialog'):
                break
            if monitor.waitForAbort(.05):
                break


def launch_video_ui(initial=None):
    import base64
    payload = base64.urlsafe_b64encode(json.dumps(initial or {}).encode('utf8')).decode('ascii')
    path = os.path.join(ART_ROOT,'video_entry.py')
    command = 'RunScript("%s",%s)' % (path,payload)
    if BROWSER:
        BROWSER.request_exit(command)
    else:
        if HANDLE >= 0:
            finish()
        xbmc.executebuiltin(command)


def public_catalogue_results(query):
    """Public catalogues appear in general search, including without a TMDB key."""
    providers = []
    if setting('enable_ct') == 'true':
        providers.append(('ct', CTProvider()))
    if setting('enable_archive') == 'true':
        providers.append(('archive', ArchiveProvider()))
    progress = Progress(xbmcgui.DialogProgress())
    progress.create('Searching public catalogues', 'Finding programme and video identities...')
    try:
        for index, (name, provider) in enumerate(providers):
            if progress.iscanceled():
                break
            progress.update(int(index*100/max(1,len(providers))), PROVIDER_NAMES[name])
            try:
                rows, total = provider.search(query)
                wanted = set(normalize(query).split()) - {'the','and','of','a','an'}
                rows = [row for row in rows if len(wanted & set(normalize(catalogue_text(row.get('title'))).split())) / max(1,len(wanted)) >= .8]
                if name == 'ct':
                    for row in rows[:6]:
                        key = 'ctshow:' + str(row['id'])
                        data = {'title':row['title'], 'image':row.get('previewImage'), 'native_provider':'ct',
                                'ct_show_id':str(row['id']), 'overview':'ČT on-demand programme. Choose a season/episode, then source quality.'}
                        DB.title(key, data)
                        item(row['title']+' | ČT archive', 'title', key=key, data=data, secondary='Available in the provider catalogue')
                    route, args = 'ct_search', {}
                elif name == 'archive':
                    for row in rows[:6]:
                        ident = row['identifier']
                        key = 'archive:' + ident
                        data = {'title':catalogue_text(row.get('title') or ident), 'native_provider':'archive', 'archive_id':ident,
                                'release_date':str(row.get('year') or row.get('date') or '')[:4],
                                'image':'https://archive.org/services/img/'+ident, 'overview':catalogue_text(row.get('description'))}
                        DB.title(key,data)
                        item(data['title']+' | Internet Archive', 'sources', key=key,data=data,
                             secondary='Public archive item · choose a video file')
                    route, args = 'archive_search', {}
                if rows:
                    item('More results from '+PROVIDER_NAMES[name], route, query=query, **args)
            except ProviderCancelled:
                break
            except ProviderError:
                DIALOG.notification(PROVIDER_NAMES[name], 'Catalogue search unavailable; other results are retained.')
    finally:
        progress.close()


def web_search_page(provider, query='', page=1):
    query = query or DIALOG.input('Search ' + PROVIDER_NAMES[provider])
    if not query:
        finish()
        return
    DB.remember_search(query, provider)
    if BROWSER:
        BROWSER.params = {'action': 'web_search', 'provider': provider, 'query': query, 'page': page}
    try:
        rows, total = video_task('Searching '+PROVIDER_NAMES[provider], lambda cancelled:
                                web_video(provider).search(query, page, cancelled=cancelled))
    except ProviderCancelled:
        finish()
        return
    if not rows:
        DIALOG.notification(PROVIDER_NAMES[provider], 'No public video results were returned.')
    for row in rows:
        key = provider + ':' + row['id']
        data = {'title':row['title'], 'native_provider':provider, 'video_id':row['id'],
                'image':row.get('image'), 'overview':row.get('description') or '', 'duration':row.get('duration') or 0,
                'uploader': row.get('uploader') or ''}
        DB.title(key, data)
        item(row['title'], 'video_sources', key=key, data=data,
             secondary='%s · %s · %s' % (PROVIDER_NAMES[provider], video_duration(data['duration']), row.get('uploader') or 'Public video'))
    if provider == 'dailymotion' and total > page*20:
        item('More Dailymotion results', 'web_search', provider=provider, query=query, page=page+1)
    finish()


def video_duration(seconds):
    seconds = int(seconds or 0)
    if not seconds:
        return 'Duration unavailable'
    minutes, seconds = divmod(seconds, 60)
    if minutes >= 60:
        hours, minutes = divmod(minutes, 60)
        return '%d:%02d:%02d' % (hours, minutes, seconds)
    return '%d:%02d' % (minutes, seconds)


def video_sources_page(key):
    data = DB.title(key) or {}
    provider, ident = data['native_provider'], data['video_id']
    client = web_video(provider)
    def load(cancelled):
        info = client.info(ident, cancelled=cancelled)
        return info, client.sources(ident, cancelled=cancelled)
    try:
        info, sources = video_task('Loading video qualities', load)
    except ProviderCancelled:
        finish()
        return
    except ProviderError as exc:
        log_playback(key, media_identity(key, provider, ident), provider, 'failed', str(exc))
        raise
    data.update(title=info.get('title') or data.get('title') or ident,
                image=info.get('thumbnail') or data.get('image'),
                overview=info.get('description') or data.get('overview') or '',
                duration=info.get('duration') or data.get('duration') or 0,
                uploader=info.get('uploader') or data.get('uploader') or '')
    DB.title(key, data)
    DB.record_check(key, data['title'], sources, provider=provider)
    if BROWSER:
        BROWSER.current_key = key
        BROWSER.params = {'action': 'video_sources', 'key': key, 'provider': provider}
    for source in sources:
        item(source['quality'] + ' — ' + data['title'], 'source', folder=False,
             key=key, ident=source['id'], provider=provider, data=data,
             secondary='%s · %s · %s' % (PROVIDER_NAMES[provider], video_duration(data['duration']), data['uploader'] or 'Public video'),
             art=source_art(ART_ROOT, source))
    if not sources:
        raise ProviderError('No playable video with audio up to 1080p was returned. Try another public video.')
    finish()


def catalogue_text(value):
    if isinstance(value, list):
        value = ' / '.join(str(v) for v in value)
    return re.sub(r'<[^>]+>', ' ', str(value or ''))


def free_home():
    item('Open a prehraj.to video link','prehraj_link',secondary='Exact provider domain only · optional account in settings')
    item('ČT iVysílání — search programmes', 'ct_search', secondary='Films and series on demand · no account')
    item('ČT iVysílání — browse categories', 'ct_categories')
    item('Internet Archive — search films', 'archive_search', secondary='Public archive files · no account')
    item('Local video library', 'local_library', secondary='Read-only folder · original files never removed')
    item('Choose local video-library folder', 'choose_library', folder=False)
    item('YouTube / Dailymotion videos', 'video_home', secondary='Separate from movie and TV search')
    item('Free-provider settings', 'settings', folder=False)
    item('Add / remove public HTTP stream providers', 'manage_providers', folder=False,
         secondary='Stremio manifest protocol · IMDb movie/episode matching · direct HTTPS streams')
    finish()


def video_home():
    item('Search YouTube videos', 'web_search', provider='youtube')
    item('Search Dailymotion videos', 'web_search', provider='dailymotion')
    item('Open a YouTube / Dailymotion link', 'youtube', secondary='Choose video quality · no separate video add-on')
    item('Recent videos', 'video_history')
    finish()


def ct_search_page(query='', page=1):
    query = query or DIALOG.input('Search ČT films and series')
    if not query:
        finish()
        return
    if page == 1:
        DB.remember_search(query, 'ct')
    shows, total = CTProvider().search(query, page)
    for show in shows:
        item(show['title'], 'ct_show', ident=show['id'],
             data={'title': show['title'], 'image': show.get('previewImage'),
                   'overview': 'ČT on-demand catalogue. Choose the programme, then a season/episode and source quality.'},
             secondary='ČT iVysílání · provider programme ID ' + str(show['id']))
    if total > page * 20:
        item('More ČT search results', 'ct_search', query=query, page=page+1)
    if not shows:
        item('No ČT programmes returned', 'source_help', folder=False)
    finish()


def ct_show_page(ident):
    show = CTProvider().show(ident)
    image = (show.get('images') or {}).get('card')
    if show.get('showType') == 'series' or show.get('seasons'):
        key = 'ctshow:' + str(show['id'])
        if BROWSER:
            BROWSER.current_key = key
        DB.title(key, {'title': show['title'], 'image': image, 'overview': show.get('shortDescription'),
                       'native_provider': 'ct', 'ct_show_id': str(show['id']), 'media_type': 'tv'})
        item('All available episodes — ČT order', 'ct_episodes', idec=show['idec'],
             secondary='ČT programme/season IDs are kept separate from TMDB episode numbering')
        for season in show.get('seasons') or []:
            item(season['title'], 'ct_episodes', idec=show['idec'], season=season['id'])
        finish()
    else:
        idec = str(show.get('playableIdec') or show['idec'])
        key = 'ct:' + idec
        DB.title(key, {'title': show['title'], 'image': image, 'overview': show.get('shortDescription'),
                       'native_provider': 'ct', 'ct_idec': idec, 'release_date': str(show.get('year') or ''),
                       'web_url': 'https://www.ceskatelevize.cz/porady/' + str(show['id']) + '/'})
        source_page(key)


def ct_episodes_page(idec, season='', page=1):
    episodes, total = CTProvider().episodes(idec, season, page)
    for episode in episodes:
        key = 'ct:' + str(episode['id'])
        title = episode.get('showTitle', '') + ' — ' + episode['title']
        data = {'title': title, 'image': (episode.get('images') or {}).get('card'),
                'overview': episode.get('description') or '', 'episode_name': episode['title'],
                'native_provider': 'ct', 'ct_idec': str(episode['id']), 'media_type': 'episode',
                'web_url': 'https://www.ceskatelevize.cz/porady/' + str(episode['showId']) + '/'}
        DB.title(key, data)
        item(episode['title'], 'sources', key=key, data=data,
             secondary='%s · %.0f min · ČT episode ID %s' %
             ((episode.get('season') or {}).get('title', 'ČT archive'), (episode.get('duration') or 0)/60, episode['id']))
    if total > page*30:
        item('More ČT episodes', 'ct_episodes', idec=idec, season=season, page=page+1)
    finish()


def ct_categories_page():
    for category in CTProvider().categories():
        ids = category.get('categoryId') or []
        if ids:
            item(category['title'], 'ct_category', ident=ids[0] if isinstance(ids, list) else ids)
    finish()


def ct_category_page(ident, page=1):
    shows, total = CTProvider().category(ident, page)
    for show in shows:
        item(show['title'], 'ct_show', ident=show['id'],
             data={'title': show['title'], 'image': (show.get('images') or {}).get('card'),
                   'overview': show.get('shortDescription') or ''},
             secondary='ČT · ' + str(show.get('year') or ''))
    if total > page*20:
        item('More ČT programmes', 'ct_category', ident=ident, page=page+1)
    finish()


def archive_search_page(query='', page=1):
    query = query or DIALOG.input('Search Internet Archive films')
    if not query:
        finish()
        return
    if page == 1:
        DB.remember_search(query, 'archive')
    docs, total = ArchiveProvider().search(query, page)
    for doc in docs:
        ident = doc['identifier']
        data = {'title': catalogue_text(doc.get('title') or ident), 'native_provider': 'archive',
                'archive_id': ident, 'overview': catalogue_text(doc.get('description')),
                'image': 'https://archive.org/services/img/' + ident,
                'release_date': str(doc.get('year') or doc.get('date') or '')[:4]}
        key = 'archive:' + ident
        DB.title(key, data)
        item('%s (%s)' % (data['title'], data['release_date'] or 'year unknown'), 'sources', key=key, data=data,
             secondary='Internet Archive · ' + catalogue_text(doc.get('language') or 'Language not verified'))
    if total > page*20:
        item('More archive results', 'archive_search', query=query, page=page+1)
    if not docs:
        item('No Internet Archive items returned', 'source_help', folder=False)
    finish()


def local_library_page():
    sources, capped = LocalProvider(setting('local_library')).scan()
    # Display in bounded pages rather than building thousands of Kodi controls.
    page = max(1, int(PARAMS.get('page', 1)))
    for src in sources[(page-1)*50:page*50]:
        from resources.lib.discovery import episode_numbers
        numbers = episode_numbers(src['name'])
        src.update(accepted=True, native_selection=True, metadata='User-selected local video; track metadata read during playback')
        key = 'local:' + src['id']
        data = {'title': src['name'], 'native_provider': 'local', 'local_source': src,
                'overview': src['relative_path']}
        if numbers:
            data.update(season=numbers[0], episode=numbers[1])
        DB.title(key, data)
        item(src['name'], 'sources', key=key, data=data, secondary='Local file · %.2f GB' % (src['size']/1e9))
    if len(sources) > page*50:
        item('More local videos', 'local_library', page=page+1)
    if capped:
        DIALOG.notification('Local library', 'Scan capped at 5,000 videos. Choose a smaller folder if needed.')
    finish()


def youtube_page(link=''):
    link = link or DIALOG.input('Paste a public YouTube or Dailymotion video link')
    if not link:
        return
    provider, ident = video_id(link)
    key = provider + ':' + ident
    if not DB.title(key):
        DB.title(key, {'title':ident, 'native_provider':provider, 'video_id':ident})
    video_sources_page(key)


def prehraj_link(link=''):
    link=link or DIALOG.input('Paste a https://prehraj.to video page link')
    if not link:finish();return
    parsed=urlparse(link)
    match=re.fullmatch(r'/([^/]+)/([a-f0-9]{10,32})/?',parsed.path)
    if parsed.scheme!='https' or parsed.hostname not in ('prehraj.to','www.prehraj.to') or parsed.username or parsed.password or not match:
        raise ProviderError('Use an HTTPS video page on the exact prehraj.to domain. Other sites and redirects are not accepted.')
    key='prehraj:'+match[2]
    DB.title(key,{'title':match[1].replace('-',' '),'native_provider':'prehraj','video_id':match[2],'prehraj_page':parsed.path})
    source_page(key)


def watch_providers(key):
    data = DB.title(key) or {}
    if data.get('native_provider'):
        raise ProviderError('Open this title through TMDB movie/TV search to check other streaming services.')
    kind = 'tv' if key.startswith('tv:') else 'movie'
    region = (setting('watch_region') or 'CZ').upper()
    result = tmdb().get('%s/%s/watch/providers' % (kind, data['id'])).get('results', {}).get(region, {})
    labels = {'flatrate': 'Subscription', 'free': 'Free', 'ads': 'With ads', 'rent': 'Rent', 'buy': 'Buy'}
    DB.execute('INSERT OR REPLACE INTO availability VALUES (?,?,?,?,?)',
               (key, 'tmdb_watch', region, json.dumps({field: result.get(field, []) for field in labels}), time.time()))
    lines = ['Country: ' + region, 'Availability data: JustWatch via TMDB. Exact prices and in-app playback are not supplied.']
    for field, label in labels.items():
        if result.get(field):
            lines.append(label + ': ' + ', '.join(p['provider_name'] for p in result[field]))
    if len(lines) == 2:
        lines.append('No provider listing returned for this country; this does not prove unavailability.')
    DIALOG.textviewer('Where to watch — JustWatch / TMDB', '\n\n'.join(lines))


def download_action(ident):
    row = DB.db.execute('SELECT * FROM downloads WHERE id=?', (ident,)).fetchone()
    src=json.loads(row['source'])
    labels=['Play' if row['state']=='complete' else 'Queue / resume','Pause','Source details','Remove saved file / partial download']
    choice=DIALOG.select('Download',labels)
    if choice==0:
        if row['state']=='complete':play(row['path'],row['title_key'],src)
        elif setup(require_storage=True):DB.execute("UPDATE downloads SET state='queued',error='' WHERE id=?",(ident,))
    elif choice==1:DB.execute("UPDATE downloads SET state='paused' WHERE id=?",(ident,))
    elif choice==2:DIALOG.textviewer('Source details',src.get('name','')+'\n'+PROVIDER_NAMES.get(src['provider'],src['provider'])+'\n'+row['path'])
    elif choice==3 and DIALOG.yesno('Remove download?', 'Remove only this app-managed video and its partial download?'):
        active=json.loads(xbmcgui.Window(10000).getProperty('personalcinema.active') or '{}')
        if xbmc.Player().isPlayingVideo() and active.get('provider')==src['provider'] and active.get('source_id')==src['id']:
            DIALOG.ok('Video is playing','Stop playback before removing this saved video.')
            return
        DB.execute("UPDATE downloads SET state='deleting' WHERE id=?",(ident,))
        DIALOG.notification('Personal Cinema','Removal queued; the download worker will close the file before deleting it.')
    finish()


def main():
    action = PARAMS.get('action', '')
    key = PARAMS.get('key', '')
    if not action:
        if not setup():
            finish()
            return
        item('Search movies and TV shows', 'search')
        item('Browse movie providers — ČT, Archive, local', 'free_home')
        item('YouTube / Dailymotion videos', 'video_home')
        item('Search history', 'search_history')
        item('Local catalogue / recently found titles', 'library')
        item('Downloads', 'downloads')
        item('Disk buffering / keep cached video','cache_status')
        item('Oneplay films and series','oneplay_home',secondary='Account / profile / DRM handled by Oneplay')
        item('Accounts — save credentials immediately', 'accounts', folder=False)
        item('Playback / download subtitles', 'playback_tools', folder=False)
        item('Settings', 'settings', folder=False)
        item('Updates', 'updates', folder=False)
        item('Storage status', 'storage_status', folder=False)
        item('Playback / link history', 'playback_log', folder=False)
        item('Export catalogue as JSON', 'export', folder=False)
        item('About / credits', 'about', folder=False)
        item('Close add-on (keep Kodi open)', 'close_addon', folder=False)
        item('Quit Kodi', 'quit_kodi', folder=False)
        finish()
    elif action == 'search':
        catalogue(PARAMS.get('query'), int(PARAMS.get('page', 1)))
    elif action == 'free_home':
        free_home()
    elif action == 'ct_search':
        ct_search_page(PARAMS.get('query', ''), int(PARAMS.get('page', 1)))
    elif action == 'ct_show':
        ct_show_page(PARAMS['ident'])
    elif action == 'ct_episodes':
        ct_episodes_page(PARAMS['idec'], PARAMS.get('season', ''), int(PARAMS.get('page', 1)))
    elif action == 'ct_categories':
        ct_categories_page()
    elif action == 'ct_category':
        ct_category_page(PARAMS['ident'], int(PARAMS.get('page', 1)))
    elif action == 'archive_search':
        archive_search_page(PARAMS.get('query', ''), int(PARAMS.get('page', 1)))
    elif action == 'local_library':
        local_library_page()
    elif action == 'choose_library':
        path = DIALOG.browseSingle(0, 'Choose a read-only local movie folder (not a cache)', 'files')
        if path:
            ADDON.setSetting('local_library', path)
            DIALOG.notification('Personal Cinema', 'Library folder saved. Original files are never deleted.')
    elif action == 'youtube':
        youtube_page(PARAMS.get('link', ''))
    elif action == 'prehraj_link':
        prehraj_link(PARAMS.get('link',''))
    elif action == 'web_search':
        web_search_page(PARAMS.get('provider','youtube'), PARAMS.get('query',''), int(PARAMS.get('page',1)))
    elif action == 'video_home':
        video_home()
    elif action == 'video_sources':
        video_sources_page(PARAMS['key'])
    elif action == 'video_history':
        for row in DB.db.execute('SELECT * FROM titles ORDER BY updated DESC LIMIT 500'):
            data = json.loads(row['data'])
            if data.get('native_provider') in ('youtube','dailymotion'):
                item(data.get('title') or data.get('name'), 'video_sources', key=row['key'], data=data,
                     secondary='%s · %s · %s' % (PROVIDER_NAMES[data['native_provider']], video_duration(data.get('duration')), data.get('uploader') or 'Public video'))
        finish()
    elif action == 'manage_providers':
        manage_providers()
    elif action == 'open_web':
        import webbrowser
        link = PARAMS.get('link', '')
        if urlparse(link).hostname not in ('www.ceskatelevize.cz', 'www.youtube.com'):
            raise ProviderError('This external playback link is not a supported official provider.')
        webbrowser.open(link)
    elif action == 'watch_providers':
        watch_providers(key)
    elif action == 'provider_checks':
        rows = DB.db.execute('SELECT provider,query,outcome,count,checked FROM checks WHERE title_key=? ORDER BY checked DESC LIMIT 30', (key,)).fetchall()
        DIALOG.textviewer('Provider checks', '\n\n'.join('%s · %s · %d candidates\n%s · %s' %
                          (PROVIDER_NAMES.get(r['provider'], r['provider']), tr(r['outcome']), r['count'],
                           time.strftime('%Y-%m-%d %H:%M', time.localtime(r['checked'])), r['query']) for r in rows))
    elif action == 'open_browser':
        launch_browser()
    elif action == 'title':
        title_page(key)
    elif action == 'season':
        season_page(key, int(PARAMS['season']))
    elif action == 'sources':
        source_page(key, PARAMS.get('cached') == '1', PARAMS.get('custom') == '1', PARAMS.get('show_hidden') == '1', PARAMS.get('edition', 'All editions'))
    elif action == 'edition_filter':
        options = ['All editions', 'Extended', "Director's cut", 'Theatrical', 'Edition unspecified']
        index = DIALOG.select('Choose movie edition (filename hints)', options)
        if index >= 0:
            params = {'action': 'sources', 'key': key, 'cached': 1, 'edition': options[index]}
            if BROWSER:
                BROWSER.busy_action = False
                BROWSER.navigate(params)
            else:
                xbmc.executebuiltin('Container.Update(%s)' % url('sources', key=key, cached=1, edition=options[index]))
    elif action == 'source':
        source_action(key, PARAMS['ident'], PARAMS.get('provider', 'webshare'))
    elif action == 'source_help':
        DIALOG.textviewer('Source matching', 'Series matching uses only English/Czech/alternative names verified for the selected TMDB series ID, plus its exact season and episode.\n\nOutlander / Cizinka and Outlander: Blood of My Blood / Cizinka: Krev mé krve remain separate series. A refined search changes retrieval, not the selected series identity.\n\nThe filtered list shows rejected filenames and the reason. Other series and wrong episodes cannot be played as the selected episode. Size-only filtered files can be explicitly selected.\n\nSubtitle files, images and archives are not playable candidates. No exact video returned by this provider is different from universal unavailability.')
    elif action == 'search_history':
        rows = DB.db.execute("SELECT 'tmdb' AS provider,query,updated FROM search_history UNION ALL "
                             'SELECT provider,query,updated FROM provider_search_history ORDER BY updated DESC').fetchall()
        for row in rows:
            route = {'tmdb': 'search', 'ct': 'ct_search', 'archive': 'archive_search', 'youtube':'web_search', 'dailymotion':'web_search'}.get(row['provider'], 'search')
            label = 'TMDB' if row['provider'] == 'tmdb' else PROVIDER_NAMES.get(row['provider'], row['provider'])
            args = {'provider':row['provider']} if route == 'web_search' else {}
            item(row['query'], route, query=row['query'], secondary=label + ' · ' + time.strftime('%Y-%m-%d %H:%M', time.localtime(row['updated'])), **args)
        if rows:
            item('Clear search history', 'clear_search_history', folder=False)
        else:
            item('No searches saved yet — start a search', 'search')
        finish()
    elif action == 'clear_search_history':
        if DIALOG.yesno('Clear search history?', 'Remove the saved search queries from this device?'):
            DB.execute('DELETE FROM search_history')
            DB.execute('DELETE FROM provider_search_history')
            if BROWSER:
                BROWSER.busy_action = False
                BROWSER.navigate({'action': 'search_history'}, remember=False)
            else:
                xbmc.executebuiltin('Container.Refresh')
    elif action == 'close_addon':
        if BROWSER:
            BROWSER.request_exit()
        else:
            xbmc.executebuiltin('ActivateWindow(home)')
    elif action == 'quit_kodi':
        if BROWSER:
            BROWSER.request_exit('Quit')
        else:
            xbmc.executebuiltin('Quit')
    elif action == 'library':
        for row in DB.db.execute('SELECT * FROM titles ORDER BY updated DESC LIMIT 500'):
            data = json.loads(row['data'])
            if data.get('native_provider') in ('youtube','dailymotion'):
                continue
            label = data.get('title') or data.get('name')
            if data.get('season') is not None:
                label += ' S%02dE%02d' % (data['season'], data['episode'])
            item(label, 'title', key=row['key'], data=data)
        finish()
    elif action == 'downloads':
        downloads(PARAMS.get('group',''),PARAMS.get('series',''),PARAMS.get('season',''))
    elif action == 'cache_status':
        cache_status()
    elif action == 'cache_action':
        cache_action(PARAMS['ident'])
    elif action == 'oneplay_home':
        oneplay_page()
    elif action == 'oneplay_browse':
        oneplay_page(PARAMS['link'])
    elif action == 'oneplay_search':
        oneplay_search(PARAMS.get('query',''))
    elif action == 'oneplay_play':
        from resources.lib.oneplay import checked
        xbmc.executebuiltin('PlayMedia("%s")' % checked(PARAMS['link']))
    elif action == 'download':
        download_action(int(PARAMS['download_id']))
    elif action == 'settings':
        from resources.lib.preferences import open_settings
        def dispatch_settings(params):
            previous = PARAMS.copy()
            try:
                PARAMS.clear(); PARAMS.update(params)
                main()
            finally:
                PARAMS.clear(); PARAMS.update(previous)
        open_settings(ADDON, dispatch_settings, ART_ROOT)
        finish()
    elif action in ('disable_storage', 'pause_storage'):
        if xbmcgui.Window(10000).getProperty('personalcinema.cache.active'):
            xbmc.Player().stop()
        DB.execute("UPDATE cache_jobs SET state='cancelled'")
        DB.execute("UPDATE downloads SET state='paused' WHERE state IN ('queued','downloading')")
        if action == 'disable_storage':
            ADDON.setSetting('storage_mode', '0')
            ADDON.setSetting('storage_mode_initialized', 'true')
            ADDON.setSetting('storage_setup_done', 'true')
            if PARAMS.get('quiet') != '1':
                DIALOG.ok('Media storage disabled', 'Streaming stays available. Existing saved files are kept.')
    elif action == 'storage_settings':
        from resources.lib.storage_preferences import open_storage
        previous=PARAMS.copy()
        def dispatch_storage(params):
            try:
                PARAMS.clear(); PARAMS.update(params); main()
            finally:
                PARAMS.clear(); PARAMS.update(previous)
        open_storage(ADDON, dispatch_storage)
    elif action == 'accounts':
        accounts(PARAMS.get('group', ''))
    elif action == 'updates':
        from resources.lib.updates import BASE as UPDATE_BASE, REPOSITORY, latest_version, version_tuple
        installed=ADDON.getAddonInfo('version')
        choice=DIALOG.select(tr('Updates')+' — '+tr('Installed version')+': '+installed,
                             ['Check for updates','Open Kodi update manager','Repository installation address','Back'])
        if choice==0:
            latest=latest_version()
            if version_tuple(latest)<=version_tuple(installed):
                DIALOG.ok('Updates',tr('You have the latest version.')+'\n'+installed)
                return
            if not xbmc.getCondVisibility('System.HasAddon('+REPOSITORY+')'):
                DIALOG.ok('Install the update repository first',UPDATE_BASE)
                return
            if not DIALOG.yesno('Update available',tr('Installed version')+': '+installed+'\n'+tr('Available version')+': '+latest+'\n\n'+tr('Open Kodi to install this update?')):
                return
            xbmc.executebuiltin('UpdateAddonRepos')
        if choice in (0,1):
            command='ActivateWindow(AddonBrowser,addons://outdated/,return)'
            if BROWSER:BROWSER.request_exit(command)
            else:xbmc.executebuiltin(command)
        elif choice==2:DIALOG.textviewer('Repository installation address',UPDATE_BASE)
    elif action == 'subtitles':
        subtitle_picker(key)
    elif action == 'playback_tools':
        playback_tools()
    elif action == 'manual':
        title = DB.title(key) or {}
        name = title.get('title') or title.get('name') or key
        path = DIALOG.input('Direct media URL for ' + name + ' (MP4/MKV/HLS; YouTube links open their own video)')
        if path:
            if youtube_id(path) or (urlparse(path).hostname or '').lower() in ('dailymotion.com','www.dailymotion.com','dai.ly'):
                youtube_page(path)
                return
            media_key = media_identity(key, 'direct', path)
            try:
                validate_direct_url(path)
                play(path, key)
            except ProviderError as exc:
                log_playback(key, media_key, 'direct', 'rejected', str(exc))
                raise
        finish()
    elif action == 'storage_status':
        if not storage():
            DIALOG.textviewer('Storage status', tr('Storage mode')+': '+tr('Streaming only')+'\n'+tr('Media folder')+': '+
                              (setting('storage') or tr('Not selected'))+'\n\n'+tr('Folder and buffering preferences are kept. Change Storage mode to enable saving again.'))
            return
        used = usage()
        DIALOG.textviewer('Managed storage', 'Selected folder: %s\nApp-managed folder: %s\n\nUsed / reserved: %.3f GB of %.1f GB\n\nApp-managed downloads, subtitles and whole-file disk-buffer reservations share this limit. Unrelated files are not modified.' % (storage_base(), storage(), used / 1e9, limit() / 1e9))
    elif action == 'playback_log':
        rows = DB.db.execute('SELECT * FROM playback_events ORDER BY id DESC LIMIT 100').fetchall()
        lines = []
        for r in rows:
            title = DB.title(r['title_key']) or {}
            name = title.get('title') or title.get('name') or r['title_key']
            if title.get('season') is not None:
                name += ' S%02dE%02d' % (title['season'], title['episode'])
            lines.append('%s | %s | %s | %s\n%s' % (time.strftime('%Y-%m-%d %H:%M', time.localtime(r['created'])),
                         name, r['provider'], tr(r['status']), display(r['detail'])))
        DIALOG.textviewer('Playback and link history', '\n\n'.join(lines) or 'No new playback events recorded yet.')
    elif action == 'export':
        if not setup(require_storage=True):
            return
        path = os.path.join(storage(), 'catalogue-export.json')
        DB.export(path)
        DIALOG.ok('Export complete', path)
        finish()
    elif action == 'about':
        DIALOG.textviewer('Personal Cinema ' + ADDON.getAddonInfo('version'),
            'Movie/TV search includes TMDB, ČT and Internet Archive. Movie sources include Webshare, ČT, Archive, local files and configured public HTTP indexes. YouTube and Dailymotion have a separate Videos section and do not slow down movie searches.\n\n'
            'YouTube and Dailymotion resolve inside this add-on using bundled yt-dlp and QuickJS helpers on Windows x64. No other video add-on or account is required. Restricted/sign-in-only videos remain unavailable. Third-party licenses are bundled under resources/bin/windows-x64.\n\n'
            'Videos use the Personal Cinema browser, with one choice per quality. Metadata requests have a 35-second limit and a two-minute memory cache. Kodi’s normal video controls are available.\n\n'
            'Přehraj uses the exact prehraj.to domain, public search and published media sources. Accounts are optional; free access can have limits. Subscription status can be unknown. Oneplay requires its own Kodi add-on, account/profile and DRM setup; Android playback is pending verification.\n\n'
            'Disk buffering is opt-in, uses a loopback-only service and reserves the complete file size against managed storage. It continues while paused while Kodi is running. Temporary data is deleted after playback unless saved to Downloads. Oneplay/DRM and segmented streams do not use this file cache.\n\n'
            'ČT subtitles are cached as complete SRT timelines. ČT episode matching uses exact programme names and unique translated episode titles; ambiguous episodes require provider browsing. Geographic restrictions and DRM still apply.\n\n'
            'Source badges distinguish filename hints from reported/opened audio tracks. Edition labels remain hints. Provider claims do not verify actual file content.\n\n'
            'This product uses the TMDB API but is not endorsed or certified by TMDB. Where-to-watch listings are supplied by JustWatch via TMDB; no playback or exact prices. OpenSubtitles.com requires its own API key. Unconfirmed title metadata expires after 180 days.')
        finish()


def run_browser():
    global BROWSER
    from resources.lib.browser import CinemaBrowser
    host = xbmcgui.Window(10000)
    marker = 'personalcinema.browser.running'
    if host.getProperty(marker) not in ('', 'starting'):
        return
    host.setProperty(marker, 'true')
    try:
        monitor = xbmc.Monitor()
        # endOfDirectory wakes the directory loader; its busy dialog may still
        # be unwinding. Never show WindowXML on that modal loading stack.
        for _ in range(100):
            if not xbmc.getCondVisibility('System.HasModalDialog'):
                break
            if monitor.waitForAbort(.05):
                return
        else:
            raise ProviderError('Kodi still has a dialog open. Close it and open Personal Cinema again.')
        # WindowXML.close() restores its previous window. Make that window Home,
        # rather than the Videos plugin directory that can reload this add-on.
        xbmc.executebuiltin('ActivateWindow(home)', True)
        if xbmcgui.getCurrentWindowId() != 10000:
            raise ProviderError('Kodi could not open Home. Close any open dialog and try again.')
        xbmc.log('PersonalCinema browser: opening from Kodi Home', xbmc.LOGINFO)
        def dispatch(params):
            PARAMS.clear()
            PARAMS.update({k: str(v) for k, v in params.items()})
            main()
        BROWSER = CinemaBrowser('Browser.xml', ADDON.getAddonInfo('path'), 'default', '1080i')
        BROWSER.dispatch = dispatch
        BROWSER.title_data = DB.title
        BROWSER.has_sources = lambda key: bool(DB.db.execute('SELECT 1 FROM sources WHERE title_key=? LIMIT 1',(key,)).fetchone())
        BROWSER.addon_path = ADDON.getAddonInfo('path')
        BROWSER.prepare_events()
        BROWSER.show()
        while not getattr(BROWSER, 'closing', False):
            if monitor.abortRequested():
                BROWSER.request_exit('')
                break
            BROWSER.process_events()
            if monitor.waitForAbort(.05):
                BROWSER.request_exit('')
                break
        command = getattr(BROWSER, 'exit_command', '')
        # WindowXML restores its parent on destruction. Only navigate after this
        # has finished, or Kodi rejects Home because a modal window is active.
        BROWSER = None
        if command:
            xbmc.executebuiltin(command, True)
            if command != 'Quit':
                xbmc.log('PersonalCinema browser: closed; Kodi window=%d; dialog=%d' %
                         (xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId()), xbmc.LOGINFO)
    finally:
        BROWSER = None
        host.clearProperty(marker)


if __name__ == '__main__':
    try:
        if not PARAMS.get('action') and setting('touch_browser') != 'false':
            if HANDLE >= 0:
                launch_browser()
            else:
                run_browser()
        else:
            main()
    except Exception as exc:
        message = str(exc) if isinstance(exc, (ProviderError, ValueError)) else 'Unexpected %s. See development instructions.' % type(exc).__name__
        xbmc.log('PersonalCinema: ' + type(exc).__name__, xbmc.LOGERROR)
        DIALOG.ok('Personal Cinema', message)
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    finally:
        DB.db.close()

"""Temporary LAN account receiver. HTTP worker never calls Kodi or writes settings."""
import html
import ipaddress
import json
import queue
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit

FIELDS = {'tmdb_token': 'TMDB — API Read Access Token', 'ws_user': 'Webshare — username',
          'ws_password': 'Webshare — password', 'prehraj_user': 'Přehraj.to — email',
          'prehraj_password': 'Přehraj.to — password', 'os_key': 'OpenSubtitles — API key',
          'os_user': 'OpenSubtitles — username', 'os_password': 'OpenSubtitles — password'}


def validate_values(values):
    if not isinstance(values, dict) or not values or set(values) - set(FIELDS):
        raise ValueError('Invalid account fields')
    if any(not isinstance(v, str) or not v or len(v) > 4096 or '\x00' in v for v in values.values()):
        raise ValueError('Invalid account value')
    result = {k: v.strip() if k.endswith(('token', '_key')) else v for k, v in values.items()}
    if any(not value for value in result.values()):
        raise ValueError('Empty account value')
    return result


def local_address():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        # UDP connect chooses the LAN interface; it sends no data.
        probe.connect(('192.0.2.1', 9))
        address = probe.getsockname()[0]
    if not ipaddress.ip_address(address).is_private or address.startswith('127.'):
        raise ValueError('No local network address')
    return address


def receiver_address(value):
    parsed = urlsplit(value if '://' in value else 'http://' + value)
    address = ipaddress.ip_address(parsed.hostname or '')
    if parsed.scheme != 'http' or address.version != 4 or not address.is_private or address.is_loopback:
        raise ValueError('Enter the local IPv4 address shown on the receiving device')
    if not parsed.port or parsed.username or parsed.password or parsed.path not in ('', '/') or parsed.query or parsed.fragment:
        raise ValueError('Invalid receiver address')
    return 'http://%s:%d' % (address, parsed.port)


def page(labels=None):
    fields = ''.join('<label>%s<input name="%s" type="%s" autocomplete="off"></label>' %
                     (html.escape(label), key, 'password' if key.endswith(('password', 'token', '_key')) else 'text')
                     for key, label in (labels or FIELDS).items())
    return ('''<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Personal Cinema</title><style>body{font:18px system-ui;max-width:620px;margin:30px auto;padding:16px;background:#10202c;color:white}label{display:block;margin:18px 0}input,button{box-sizing:border-box;width:100%;font:inherit;padding:10px}button{background:#51c9d4}small{color:#bdd}</style>
<h1>Personal Cinema</h1><p>Account setup / Nastavení účtů</p>
<small>Local network only. Fill selected fields; blank fields stay unchanged.<br>Jen místní síť. Prázdná pole se nezmění. Confirm on the receiving device / Potvrďte na přijímajícím zařízení.</small>
<form><label>Pairing code / Párovací kód<input name="code" inputmode="numeric" required maxlength="6"></label>''' + fields +
'''<button>Send accounts / Odeslat účty</button></form><p id="status" role="status"></p>
<script>const f=document.querySelector('form');f.elements.code.value=location.hash.slice(1);history.replaceState(null,'',location.pathname);
f.onsubmit=async e=>{e.preventDefault();const b=f.querySelector('button');b.disabled=true;let values={};for(const [k,v] of new FormData(f))if(k!=='code'&&v)values[k]=v;
try{let r=await fetch('/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:f.elements.code.value,values})});document.querySelector('#status').textContent=r.ok?'Sent. Confirm in Kodi / Odesláno. Potvrďte v Kodi.':'Could not send / Odeslání selhalo';if(r.ok)f.reset();}catch(e){document.querySelector('#status').textContent='Connection failed / Spojení selhalo';}b.disabled=false;};</script>''').encode('utf-8')


class Receiver:
    def __init__(self, host=None, labels=None):
        self.code = '%06d' % secrets.randbelow(1000000)
        self.deadline = time.monotonic() + 300
        self.pending = queue.Queue(maxsize=1)
        self.attempts = 0
        self.submitted = False
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass  # Never log request bodies, pairing codes or addresses.

            def setup(self):
                super().setup()
                self.connection.settimeout(2)

            def reply(self, status, body=b''):
                self.send_response(status)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'")
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def active(self):
                return time.monotonic() < owner.deadline and owner.attempts < 6 and not owner.submitted

            def do_GET(self):
                self.reply(200, page(labels)) if self.path == '/' and self.active() else self.reply(404)

            def do_POST(self):
                if self.path != '/pair' or not self.active():
                    return self.reply(410)
                origin = self.headers.get('Origin')
                if origin and origin != 'http://' + self.headers.get('Host', ''):
                    return self.reply(403)
                try:
                    size = int(self.headers.get('Content-Length', '0'))
                    if not 0 < size <= 40000:
                        return self.reply(413)
                    data = json.loads(self.rfile.read(size))
                    if not isinstance(data, dict) or not secrets.compare_digest(str(data.get('code', '')), owner.code):
                        owner.attempts += 1
                        return self.reply(403)
                    values = validate_values(data.get('values'))
                    owner.pending.put_nowait(values)
                    owner.submitted = True
                    self.reply(202)
                except (ValueError, TypeError, queue.Full):
                    self.reply(400)

        self.server = HTTPServer((host or local_address(), 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .2}, daemon=True)

    @property
    def address(self):
        return 'http://%s:%d' % self.server.server_address

    def start(self):
        self.thread.start()

    def close(self):
        if self.thread.is_alive():
            self.server.shutdown()
            self.thread.join(3)
        self.server.server_close()


def send(address, code, values):
    from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler
    class NoRedirect(HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    target = receiver_address(address)
    values = validate_values(values)
    if len(code) != 6 or not code.isdigit():
        raise ValueError('Invalid pairing code')
    request = Request(target + '/pair', data=json.dumps({'code': code, 'values': values}).encode(),
                      headers={'Content-Type': 'application/json'}, method='POST')
    with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=8) as response:
        if response.status != 202:
            raise ValueError('Receiver did not accept the transfer')


def receive_ui(addon):
    import os
    import xbmc
    import xbmcgui
    import xbmcvfs
    import segno
    from resources.lib.i18n import tr, Dialog
    dialog = Dialog(xbmcgui.Dialog())
    receiver = None
    image = None
    window = None
    class PairWindow(xbmcgui.WindowDialog):
        cancelled = False
        def onAction(self, action):
            if action.getId() in (9, 10, 92):
                self.cancelled = True
        def onControl(self, control):
            self.cancelled = True
    try:
        receiver = Receiver(labels={key: tr(label) for key, label in FIELDS.items()})
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        os.makedirs(profile, exist_ok=True)
        image = os.path.join(profile, 'pairing-qr.png')
        segno.make(receiver.address + '/#' + receiver.code, micro=False).save(image, scale=10, border=4)
        window = PairWindow()
        background = os.path.join(addon.getAddonInfo('path'), 'resources', 'art', 'pairing-background.png')
        window.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, background))
        window.addControl(xbmcgui.ControlLabel(70, 25, 1140, 45, tr('Receive accounts — QR pairing'), font='font30'))
        window.addControl(xbmcgui.ControlImage(70, 110, 400, 400, image))
        window.addControl(xbmcgui.ControlLabel(510, 120, 720, 45, receiver.address, font='font30'))
        window.addControl(xbmcgui.ControlLabel(510, 185, 720, 45, tr('Pairing code') + ': ' + receiver.code, font='font30'))
        instructions = xbmcgui.ControlTextBox(510, 260, 690, 270, font='font20')
        window.addControl(instructions)
        instructions.setText(tr('Scan with another device, or open this address in a browser. Paste account details there, or use Send saved accounts in Personal Cinema. Same home network required. Local HTTP transfer; use a trusted network. Expires in 5 minutes.'))
        button = xbmcgui.ControlButton(510, 565, 400, 55, tr('Cancel'))
        window.addControl(button)
        window.show()
        window.setFocus(button)
        receiver.start()
        monitor = xbmc.Monitor()
        values = None
        while not window.cancelled and time.monotonic() < receiver.deadline and receiver.attempts < 6:
            try:
                values = receiver.pending.get_nowait()
                break
            except queue.Empty:
                if monitor.waitForAbort(.15):
                    break
        window.close()
        window = None
        receiver.close()
        receiver = None
        if values and dialog.yesno('Receive accounts?', tr('Replace only these saved fields? Blank fields stay unchanged.') + '\n\n' + '\n'.join(FIELDS[k] for k in values)):
            for key, value in values.items():
                addon.setSetting(key, value)
            if any(k.startswith('prehraj_') for k in values):
                for name in ('prehraj-session.cookies', 'prehraj-access.json'):
                    path = os.path.join(profile, name)
                    if os.path.isfile(path):
                        os.remove(path)
            dialog.ok('Personal Cinema', 'Accounts received and saved.')
    except Exception:
        dialog.ok('Personal Cinema', 'Pairing could not start. Connect both devices to the same home network and allow local network access.')
    finally:
        if window:
            window.close()
        if receiver:
            receiver.close()
        if image and os.path.isfile(image):
            os.remove(image)


def send_ui(addon):
    import xbmcgui
    from resources.lib.i18n import Dialog
    dialog = Dialog(xbmcgui.Dialog())
    keys = [key for key in FIELDS if addon.getSetting(key)]
    if not keys:
        dialog.ok('Personal Cinema', 'No saved accounts to send.')
        return
    selected = dialog.multiselect('Choose account fields to send', [FIELDS[k] for k in keys])
    if not selected:
        return
    address = dialog.input('Receiver address — IP:port')
    if not address:
        return
    code = dialog.input('Pairing code')
    if not code:
        return
    try:
        send(address.strip(), code.strip(), {keys[i]: addon.getSetting(keys[i]) for i in selected})
        dialog.ok('Personal Cinema', 'Accounts sent. Confirm on the receiving device.')
    except Exception:
        dialog.ok('Personal Cinema', 'Could not send accounts. Check the address, pairing code, home network and firewall.')

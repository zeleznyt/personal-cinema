"""Touch-friendly local Kodi windows with persistent navigation and playback buttons."""
import json
import traceback
from collections import deque
import xbmc
import xbmcgui
from resources.lib.core import ProviderError
from resources.lib.i18n import tr, display, Dialog, translate_controls, language, translation_batch
from resources.lib.artwork import localized_art


class CinemaBrowser(xbmcgui.WindowXML):
    def prepare_events(self):
        # Native callbacks only enqueue input. The owning script drains this
        # queue, so extraction, SQLite and window changes stay on one thread.
        self.events = deque()
        self.processing = False

    def enqueue(self, kind, value=None):
        if getattr(self, 'closing', False) or self.processing or self.events:
            return
        self.events.append((kind, value))

    def process_events(self):
        if getattr(self, 'closing', False):
            self.events.clear()
            return
        if not self.events:
            return
        kind, value = self.events.popleft()
        self.processing = True
        try:
            if kind == 'init':
                self.initialize()
            elif kind == 'click':
                self.click(value)
            elif kind == 'row':
                params, folder = value
                if folder:
                    self.navigate(params)
                else:
                    self.invoke(params)
            elif kind == 'back':
                self.back()
            elif kind == 'render':
                self.render()
        finally:
            self.processing = False

    def request_exit(self, command='ActivateWindow(home)'):
        if getattr(self, 'closing', False):
            return
        self.closing = True
        self.exit_command = command
        self.close()

    def onInit(self):
        if getattr(self, 'closing', False):
            return
        self.enqueue('render' if getattr(self, '_initialized', False) else 'init')

    def initialize(self):
        if getattr(self, 'closing', False):
            return
        if getattr(self, '_initialized', False):
            self.render()
            return
        self._initialized = True
        self.rows, self.history, self.params = [], [], {}
        self.last_results, self.current_key = None, ''
        self.busy_action = False
        self.navigate({}, remember=False)

    def snapshot(self):
        return (self.params.copy(), list(self.rows), self.getControl(100).getSelectedPosition())

    def restore(self, snapshot):
        self.params, self.rows, selected = snapshot
        self.render()
        self.getControl(100).selectItem(max(0, selected))

    def navigate(self, params, remember=True):
        if getattr(self, 'closing', False):
            return
        previous = self.snapshot()
        searches = ('search', 'ct_search', 'archive_search', 'ct_category', 'local_library', 'web_search', 'oneplay_search')
        if self.params.get('action') in searches:
            self.last_results = previous
        if remember:
            self.history.append(previous)
        self.params, self.rows = params.copy(), []
        if params.get('key'):
            self.current_key = params['key']
        try:
            self.dispatch(params)
            if getattr(self, 'closing', False):
                return
            # Cancelled searches and incomplete metadata must not replace a
            # usable directory with an empty screen, regardless of its route.
            if not self.rows and previous[1]:
                if remember:
                    self.history.pop()
                self.restore(previous)
                return
            if params.get('action') in searches and self.rows:
                self.last_results = self.snapshot()
        except Exception as exc:
            if remember:
                self.history.pop()
            self.restore(previous)
            if not getattr(self, 'closing', False):
                self.error(exc)

    def error(self, exc):
        if getattr(self, 'closing', False):
            return
        xbmc.log('PersonalCinema: ' + type(exc).__name__ + '\n' + ''.join(traceback.format_list(traceback.extract_tb(exc.__traceback__))), xbmc.LOGERROR)
        message = str(exc) if isinstance(exc, (ProviderError, ValueError)) else 'Operation failed (%s).' % type(exc).__name__
        Dialog(xbmcgui.Dialog()).ok('Personal Cinema', message)

    @translation_batch()
    def render(self):
        if getattr(self, 'closing', False) or self.busy_action:
            return
        translate_controls(self, 'Browser.xml')
        for li, params, folder in self.rows:
            if li.getProperty('personalcinema.language') == language():
                continue
            label = li.getProperty('personalcinema.label')
            if label:
                li.setLabel(label if li.getProperty('personalcinema.external_title') else display(label))
                li.setLabel2(display(li.getProperty('personalcinema.secondary')))
            art = li.getProperty('personalcinema.source_art')
            if isinstance(art, str) and art:
                path = localized_art(art)
                li.setArt({'icon': path, 'thumb': path, 'poster': path})
            context = li.getProperty('personalcinema.context')
            if isinstance(context, str) and context:
                li.addContextMenuItems([(tr(label), command) for label, command in json.loads(context)], replaceItems=True)
            li.setProperty('personalcinema.language', language())
        control = self.getControl(100)
        control.reset()
        control.addItems([row[0] for row in self.rows])
        labels = {'': 'Home', 'search': 'Movie and TV search', 'title': 'Title / seasons',
                  'season': 'Episodes', 'sources': 'Sources — choose quality and edition',
                  'library': 'Local catalogue', 'downloads': 'Downloads', 'search_history': 'Search history',
                  'free_home': 'Free sources', 'ct_search': 'ČT programme search', 'ct_show': 'ČT programme / seasons',
                  'ct_categories': 'ČT categories', 'ct_category': 'ČT programmes', 'ct_episodes': 'ČT episodes',
                  'archive_search': 'Internet Archive search', 'local_library': 'Local videos', 'web_search':'Public video search',
                  'video_home':'YouTube / Dailymotion videos', 'video_history':'Recent videos'}
        labels['video_sources'] = 'Video — choose quality'
        labels.update(oneplay_home='Oneplay — account and catalogue',oneplay_browse='Oneplay catalogue',
                      oneplay_search='Oneplay search',cache_status='Disk buffering — continues while paused')
        heading = tr(labels.get(self.params.get('action', ''), 'Personal Cinema'))
        if self.current_key and self.params.get('action') in ('sources','title','season','video_sources'):
            data = getattr(self, 'title_data', lambda key:{})(self.current_key) or {}
            name = data.get('title') or data.get('name') or ''
            if data.get('season') is not None:
                name += ' S%02dE%02d' % (data['season'], data['episode'])
            if name:heading += ' — ' + name
        self.getControl(30).setLabel(heading)
        self.getControl(10).setEnabled(bool(self.history))
        self.getControl(13).setEnabled(self.last_results is not None or self.params.get('action') == 'search')
        self.getControl(14).setEnabled(bool(self.current_key))
        self.getControl(19).setVisible(self.params.get('action') == 'sources')
        self.setFocusId(100)

    def back(self):
        if self.history:
            self.restore(self.history.pop())

    def invoke(self, params):
        previous_busy = self.busy_action
        previous_params = self.params.copy()
        selected = self.getControl(100).getSelectedPosition()
        self.busy_action = True
        try:
            self.dispatch(params)
        except Exception as exc:
            self.error(exc)
        finally:
            self.busy_action = previous_busy
            if not getattr(self, 'closing', False):
                self.render()
            if self.params == previous_params and not getattr(self, 'closing', False):
                self.getControl(100).selectItem(max(0, selected))

    def watch(self):
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')

    def onClick(self, control_id):
        if getattr(self, 'closing', False) or self.processing:
            return
        if control_id == 100:
            index = self.getControl(100).getSelectedPosition()
            if 0 <= index < len(self.rows):
                _, params, folder = self.rows[index]
                self.enqueue('row', (params.copy(), folder))
        else:
            self.enqueue('click', control_id)

    def click(self, control_id):
        if getattr(self, 'closing', False):
            return
        if control_id == 100:
            index = self.getControl(100).getSelectedPosition()
            if not 0 <= index < len(self.rows):
                return
            _, params, folder = self.rows[index]
            if folder:
                self.navigate(params)
            else:
                self.invoke(params)
        elif control_id == 10:
            self.back()
        elif control_id == 11:
            self.navigate({})
        elif control_id == 12:
            if self.params.get('action','').startswith('oneplay_'):
                self.navigate({'action':'oneplay_search'})
            elif self.params.get('action') in ('video_home', 'video_history', 'web_search', 'video_sources'):
                self.navigate({'action': 'web_search', 'provider': self.params.get('provider', 'youtube')})
            else:
                self.navigate({'action': 'search'})
        elif control_id == 13 and self.last_results:
            self.history.append(self.snapshot())
            self.restore(self.last_results)
        elif control_id == 14 and self.current_key:
            if self.params.get('action') == 'video_sources':
                self.navigate({'action': 'video_sources', 'key': self.current_key})
            else:
                data = getattr(self, 'title_data', lambda key:{})(self.current_key) or {}
                route = 'title' if data.get('media_type') == 'tv' and data.get('season') is None else 'sources'
                params = {'action':route,'key':self.current_key}
                if route == 'sources' and getattr(self, 'has_sources', lambda key:False)(self.current_key):
                    params['cached'] = 1
                self.navigate(params)
        elif control_id == 16:
            if xbmc.Player().isPlayingVideo():
                self.watch()
        elif control_id == 17:
            self.invoke({'action': 'accounts'})
        elif control_id == 18:
            self.invoke({'action': 'close_addon'})
        elif control_id == 19 and self.current_key:
            self.invoke({'action': 'edition_filter', 'key': self.current_key})
        elif control_id == 21:
            self.navigate({'action': 'search_history'})
        elif control_id == 22:
            self.invoke({'action': 'quit_kodi'})

    def onAction(self, action):
        if getattr(self, 'closing', False):
            return
        if action.getId() in (9, 10, 92):
            if getattr(self, 'history', []):
                self.enqueue('back')

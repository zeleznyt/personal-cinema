"""Run the custom GUI independently of Kodi's plugin directory request."""
import os
import runpy
import sys

root = os.path.dirname(os.path.abspath(__file__))
if root not in sys.path:
    sys.path.insert(0, root)
sys.argv = ['plugin://plugin.video.personalcinema', '-1', '']
runpy.run_path(os.path.join(root, 'addon.py'), run_name='__main__')

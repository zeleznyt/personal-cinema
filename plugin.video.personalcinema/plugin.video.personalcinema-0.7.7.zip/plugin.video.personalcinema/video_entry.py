"""Start standard Kodi video dialogs after the movie window has been destroyed."""
import base64
import json
import os
import runpy
import sys

root = os.path.dirname(os.path.abspath(__file__))
if root not in sys.path:
    sys.path.insert(0,root)
initial = json.loads(base64.urlsafe_b64decode(sys.argv[1]).decode('utf8')) if len(sys.argv)>1 else {}
sys.argv = ['plugin://plugin.video.personalcinema','-1','']
app = runpy.run_path(os.path.join(root,'addon.py'))
try:
    from resources.lib.video_ui import run
    run(app,initial)
finally:
    app['DB'].db.close()

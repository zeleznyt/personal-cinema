"""Media identity, editions, managed storage and direct-link validation."""
import hashlib
import os
import re
from urllib.parse import urlparse
from resources.lib.core import ProviderError, request, folder_bytes, normalize


def media_identity(title_key, provider, ident):
    digest = hashlib.sha256(str(ident).encode('utf-8')).hexdigest()[:24]
    return '%s|%s:%s' % (title_key, provider, digest)


def edition(name):
    value = normalize(name)
    if re.search(r'\b(extended|prodlouzen[aey]?|rozsiren[aey]?)\b', value):
        return 'Extended'
    if re.search(r'\b(director s cut|directors cut|rezisersk[aey]?)\b', value):
        return "Director's cut"
    if re.search(r'\b(theatrical|kinoverze|kinov[aey]?)\b', value):
        return 'Theatrical'
    return 'Edition unspecified'


def within(path, root):
    try:
        return os.path.commonpath([os.path.realpath(root), os.path.realpath(path)]) == os.path.realpath(root)
    except ValueError:
        return False


def managed_usage(managed_root, legacy_paths=()):
    total = folder_bytes(managed_root) if os.path.isdir(managed_root) else 0
    for path in set(legacy_paths):
        if not within(path, managed_root):
            for candidate in (path, path + '.part'):
                if os.path.isfile(candidate):
                    total += os.path.getsize(candidate)
    return total


def validate_direct_url(value):
    parsed = urlparse(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ProviderError('Use an HTTPS media-file or stream URL without embedded login details.')
    host = parsed.hostname.lower()
    if host in ('youtu.be', 'youtube.com', 'www.youtube.com', 'm.youtube.com') or 'lookmovie' in host:
        raise ProviderError('This title action needs a direct media stream, not a webpage. For YouTube use Free sources → Open a YouTube link. LookMovie webpage playback is not integrated.')
    with request(value, headers={'Range': 'bytes=0-1023'}) as response:
        kind = response.headers.get('Content-Type', '').split(';')[0].lower()
        sample = response.read(1024)
    if kind in ('text/html', 'application/xhtml+xml') or sample.lstrip().lower().startswith((b'<!doctype html', b'<html')):
        raise ProviderError('The link returns a webpage. Attach a direct MP4/MKV file or HLS stream to this title instead.')
    binary = sample.startswith(b'\x1aE\xdf\xa3') or b'ftyp' in sample[:32] or sample.lstrip().startswith(b'#EXTM3U')
    if not (kind.startswith(('video/', 'audio/')) or 'mpegurl' in kind or binary or kind == 'application/octet-stream'):
        raise ProviderError('The link did not return a recognised media stream.')
    return value

"""OpenSubtitles REST provider. Credentials are supplied by local settings only."""
import json
import os
import re
import struct
from urllib.parse import urlencode, urlparse
from resources.lib.core import ProviderError, request, folder_bytes
from resources.lib.core import normalize
from resources.lib.media import edition


def movie_hash(path, size=0):
    """128 KiB fingerprint; remote servers must honour ranges, never fetch the whole film."""
    chunks = []
    if os.path.isfile(path):
        size = os.path.getsize(path)
        if size < 131072:
            return None
        with open(path, 'rb') as file:
            for offset in (0, size - 65536):
                file.seek(offset)
                chunks.append(file.read(65536))
    elif path.startswith('https://'):
        try:
            for value in ('bytes=0-65535', 'bytes=-65536'):
                with request(path, headers={'Range': value}) as response:
                    span = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
                    if response.getcode() != 206 or not span:
                        return None
                    start, end, total = map(int, span.groups())
                    if total < 131072 or end - start + 1 != 65536:
                        return None
                    if (not chunks and start != 0) or (chunks and end != total - 1):
                        return None
                    if size and size != total:
                        return None
                    size = total
                    chunks.append(response.read(65537))
        except (ProviderError, OSError):
            return None
    else:
        return None
    if len(chunks) != 2 or any(len(c) != 65536 for c in chunks):
        return None
    value = size
    for chunk in chunks:
        value += sum(x[0] for x in struct.iter_unpack('<Q', chunk))
    return '%016x' % (value & 0xffffffffffffffff)


def rank_subtitles(results, release, preferred='en'):
    source_words = set(normalize(release).split())
    source_edition = edition(release)
    technical = {'1080p', '720p', '2160p', 'bluray', 'bdrip', 'brrip', 'webrip', 'web', 'dl', 'hdtv', 'x264', 'x265', 'hevc'}
    # A release group or encoding tag is more useful for timing than shared movie-title words.
    group = re.search(r'-([a-z0-9]+)(?:\.[a-z0-9]{2,4})?$', release.lower())
    group_word = group.group(1) if group else ''
    ranked = []
    for result in results:
        a = result.get('attributes', {})
        words = set(normalize(a.get('release', '')).split())
        exact = bool(a.get('moviehash_match'))
        cut = edition(a.get('release', ''))
        conflict = source_edition != 'Edition unspecified' and cut != 'Edition unspecified' and cut != source_edition
        cut_match = source_edition != 'Edition unspecified' and cut == source_edition
        technical_overlap = len(words & source_words & technical)
        group_match = bool(group_word and group_word in words)
        reason = 'Exact video fingerprint match' if exact else (
            'Different edition — timing likely wrong' if conflict else
            'Same release group / encoding hints' if group_match else
            'Same edition / release hints' if cut_match and technical_overlap else
            'Some release hints match — check timing' if technical_overlap else
            'Title match only — timing unverified')
        score = (a.get('language') != preferred, not exact, conflict, not group_match, not cut_match,
                 -technical_overlap, -len(words & source_words), -int(a.get('download_count') or 0))
        ranked.append((score, dict(result, match_reason=reason)))
    return [r for _, r in sorted(ranked, key=lambda value: value[0])]


def language_code(value):
    return {'eng': 'en', 'english': 'en', 'ces': 'cs', 'cze': 'cs', 'cz': 'cs',
            'czech': 'cs', 'slk': 'sk', 'slo': 'sk'}.get(value.lower(), value.lower())


class OpenSubtitles:
    def __init__(self, key, user='', password=''):
        self.key, self.user, self.password = key.strip(), user, password
        self.token = ''
        self.base = 'https://api.opensubtitles.com'

    def api(self, method, payload=None, **params):
        if not self.key:
            raise ProviderError('Open Accounts and set an OpenSubtitles.com API key first. An account password alone is not enough.')
        headers = {'Api-Key': self.key, 'Accept': 'application/json', 'User-Agent': 'PersonalCinema v0.6.2'}
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
        body = None
        if payload is not None:
            headers['Content-Type'] = 'application/json'
            body = json.dumps(payload).encode('utf-8')
        query = '?' + urlencode(sorted(params.items())) if params else ''
        with request(self.base + '/api/v1/' + method + query, body, headers) as response:
            return json.load(response)

    def login(self):
        if not self.user and not self.password:
            return
        if not self.user or not self.password:
            raise ProviderError('Set both OpenSubtitles username and password, or leave both empty.')
        result = self.api('login', {'username': self.user, 'password': self.password})
        self.token = result.get('token', '')
        if not self.token:
            raise ProviderError('OpenSubtitles login did not return a token.')
        host = result.get('base_url', 'api.opensubtitles.com')
        host = (host[8:] if host.startswith('https://') else host).rstrip('/')
        if host not in ('api.opensubtitles.com', 'vip-api.opensubtitles.com'):
            raise ProviderError('OpenSubtitles returned an unrecognised API host.')
        self.base = 'https://' + host

    def search(self, title, languages, tmdb_id, season=None, episode=None, fingerprint=None):
        params = {'languages': ','.join(dict.fromkeys(language_code(x) for x in languages if x)),
                  'order_by': 'download_count', 'order_direction': 'desc'}
        if not tmdb_id:
            params['query'] = title
            if season is not None:
                params.update(season_number=season, episode_number=episode, type='episode')
        elif season is None:
            params['tmdb_id'] = tmdb_id
            params['type'] = 'movie'
        else:
            params.update(parent_tmdb_id=tmdb_id, season_number=season, episode_number=episode, type='episode')
        if fingerprint:
            params['moviehash'] = fingerprint
        result = self.api('subtitles', **params)
        return result.get('data', [])

    def save(self, file_id, root, quota, used_bytes=None):
        target = os.path.join(root, 'subtitles', str(int(file_id)) + '.srt')
        if os.path.isfile(target):
            return target
        result = self.api('download', {'file_id': int(file_id), 'sub_format': 'srt'})
        link = result.get('link', '')
        if urlparse(link).scheme != 'https':
            raise ProviderError('OpenSubtitles did not return an HTTPS download link.')
        # Subtitle downloads are small; cap the read and check the managed-media budget.
        with request(link) as response:
            content = response.read(2 * 1024 * 1024 + 1)
        if len(content) > 2 * 1024 * 1024:
            raise ProviderError('Subtitle file exceeded the 2 MB limit.')
        if not content.strip() or not re.search(rb'\d{1,2}:\d{2}:\d{2}[,.]\d{3}\s*-->', content):
            raise ProviderError('Downloaded file is not recognisable SRT subtitles.')
        used = folder_bytes(root) if used_bytes is None else used_bytes
        if used + len(content) > quota:
            raise ProviderError('Managed storage full: %.2f GB used of %.2f GB. Open Storage status to review it.' % (used / 1e9, quota / 1e9))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target + '.part', 'wb') as f:
            f.write(content)
        os.replace(target + '.part', target)
        return target

"""Presentation-only English/Czech translation; provider identities stay unchanged."""
import json
import os
import re
import threading
from contextlib import contextmanager
from functools import lru_cache

_LOCAL = threading.local()


@contextmanager
def translation_batch():
    if hasattr(_LOCAL, 'language'):
        yield
        return
    _LOCAL.language = language()
    try:
        yield
    finally:
        del _LOCAL.language

with open(os.path.join(os.path.dirname(__file__), '..', 'language', 'cs.json'), encoding='utf-8') as stream:
    CZECH = json.load(stream)


def language():
    if hasattr(_LOCAL, 'language'):
        return _LOCAL.language
    try:
        import xbmcaddon
        value = xbmcaddon.Addon('plugin.video.personalcinema').getSetting('ui_language')
        return 'cs' if value in ('1', 'cs', 'cs-CZ') else 'en'
    except (ImportError, AttributeError):
        return 'en'


FORMAT = re.compile(r'%(?:\([^)]+\))?[-+0 #]*\d*(?:\.\d+)?[sdfi]')
TEMPLATES = []
STATES = {'queued', 'downloading', 'paused', 'complete', 'failed', 'ready', 'cancelled',
          'deleting', 'unknown', 'active', 'inactive', 'attempted', 'started', 'stopped',
          'ended', 'rejected', 'available', 'unavailable', 'empty', 'error'}
for original, translated in CZECH.items():
    tokens = list(FORMAT.finditer(original))
    if not tokens:
        continue
    # Match only complete application templates, never words inside movie names.
    pieces = []; end = 0
    for token in tokens:
        pieces.append(re.escape(original[end:token.start()].replace('%%', '%')))
        pieces.append('(.*?)' if token.group().endswith('s') else r'([-+\d.,]+)')
        end = token.end()
    pieces.append(re.escape(original[end:].replace('%%', '%')))
    TEMPLATES.append((re.compile('^' + ''.join(pieces) + '$', re.S), translated))

FRAGMENTS = sorted((s for s in CZECH if len(s.strip()) >= 8 and not FORMAT.search(s)), key=len, reverse=True)


def tr(text):
    if not isinstance(text, str) or language() != 'cs':
        return text
    if text in CZECH:
        return CZECH[text]
    for pattern, translated in TEMPLATES:
        match = pattern.fullmatch(text)
        if match:
            def parameter(value):
                if value in STATES or len(value.strip()) > 8 and value in CZECH:
                    return CZECH.get(value, value)
                if value.startswith(' · '):
                    return display(value)
                return value
            values = iter(parameter(value) for value in match.groups())
            return FORMAT.sub(lambda unused: next(values), translated).replace('%%', '%')
    return text


def display(text):
    """Translate application fragments at the UI edge, without editing stored data."""
    translated = tr(text)
    if translated != text or not isinstance(text, str) or language() != 'cs':
        return translated
    if text.strip() != text and text.strip():
        left = len(text) - len(text.lstrip())
        right = len(text) - len(text.rstrip())
        return text[:left] + display(text.strip()) + (text[-right:] if right else '')
    # Composed labels retain dynamic provider filenames, names, numbers and URLs.
    for source in FRAGMENTS:
        if text.startswith(source):
            return CZECH[source] + display(text[len(source):])
        if text.endswith(source):
            return display(text[:-len(source)]) + CZECH[source]
    parts = re.split(r'(\n| \| | · |: )', text)
    if len(parts) > 1:
        return ''.join(tr(part) if index % 2 == 0 else part for index, part in enumerate(parts))
    return text


class Dialog:
    def __init__(self, raw):
        self.raw = raw

    def __getattr__(self, method):
        original = getattr(self.raw, method)
        def call(*args, **kwargs):
            positions = {'ok': (0, 1, 2, 3), 'yesno': (0, 1, 2, 3, 4, 5),
                         'notification': (0, 1), 'textviewer': (0, 1), 'input': (0,),
                         'select': (0, 1), 'multiselect': (0, 1), 'browseSingle': (1,)}.get(method, ())
            values = list(args)
            for index in positions:
                if index < len(values):
                    value = values[index]
                    values[index] = [display(v) for v in value] if isinstance(value, list) else display(value)
            for key in ('heading', 'message', 'yeslabel', 'nolabel', 'autoclose'):
                if key in kwargs and key != 'autoclose':
                    kwargs[key] = display(kwargs[key])
            return original(*values, **kwargs)
        return call


class Progress:
    def __init__(self, raw):
        self.raw = raw

    def create(self, *args):
        return self.raw.create(*(display(value) for value in args))

    def update(self, percent, *args):
        return self.raw.update(percent, *(display(value) for value in args))

    def __getattr__(self, name):
        return getattr(self.raw, name)


@lru_cache(maxsize=4)
def control_labels(filename):
    import xml.etree.ElementTree as ET
    path = os.path.join(os.path.dirname(__file__), '..', 'skins', 'default', '1080i', filename)
    return [(int(c.get('id')), c.findtext('label')) for c in ET.parse(path).iter('control')
            if c.get('id') and c.findtext('label') and not c.findtext('label').startswith('$')]


def translate_controls(window, filename):
    current = language()
    if getattr(window, '_controls_language', None) == current:
        return
    for ident, label in control_labels(filename):
        window.getControl(ident).setLabel(tr(label))
    window._controls_language = current

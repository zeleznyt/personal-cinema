"""Search ranking and conservative filename matching, independent of Kodi."""
import math
import os
import re
from resources.lib.core import normalize
from resources.lib.media import edition

ALIASES = {'lotr': 'The Lord of the Rings', 'dr who': 'Doctor Who', 'dr. who': 'Doctor Who',
           'fast and furious': 'Fast & Furious', 'faf': 'Fast & Furious'}
VIDEO_EXTENSIONS = {'.mkv', '.mp4', '.avi', '.m4v', '.mov', '.webm', '.ts', '.m2ts', '.mpg', '.mpeg', '.wmv', '.flv', '.ogm'}


def expand_query(query):
    return ALIASES.get(query.strip().lower(), query.strip())


def rank_titles(results, query):
    q = normalize(expand_query(query)).replace(' and ', ' ')
    words = set(q.split()) - {'the', 'and'}
    unique = {}
    for data in results:
        if data.get('media_type') not in ('movie', 'tv'):
            continue
        key = (data['media_type'], data['id'])
        previous = unique.get(key, {})
        merged = dict(previous, **data)
        if previous.get('_collection_match'):
            merged.update(_collection_match=True, _collection_order=previous['_collection_order'])
        unique[key] = merged

    def score(d):
        names = [normalize(d.get(k, '')) for k in ('title', 'name', 'original_title', 'original_name')]
        relevance = max((len(words & set(n.split())) / max(len(words), 1) for n in names), default=0)
        # Substantial audience support lifts feature films above fan edits and making-of extras.
        audience = math.log10(1 + (d.get('vote_count') or 0))
        return (bool(d.get('_collection_match')), -d.get('_collection_order', 0),
                relevance >= .8, relevance * 2 + audience, d.get('popularity', 0))
    return sorted(unique.values(), key=score, reverse=True)


def episode_numbers(name):
    normalized = normalize(name)
    matches = list(EPISODE_PATTERN.finditer(normalized))
    if len(matches) != 1:
        return None
    match = matches[0]
    tail = normalized[match.end():]
    if re.match(r'\s*(?:e\s*\d|s\s*\d+\s*e\s*\d)', tail, re.I):
        return None
    if re.search(r'\b(?:s\s*\d{1,2}[ ._-]*e\s*\d{1,3}|\d{1,2}x\d{1,3}|season\s*\d{1,2}\s*episode\s*\d{1,3})\s*[-+]\s*\d{1,3}(?!\d)', name, re.I):
        return None
    values = match.groups()
    return (int(next(v for v in values[::2] if v is not None)),
            int(next(v for v in values[1::2] if v is not None)))


EPISODE_PATTERN = re.compile(r'\b(?:s\s*(\d{1,2})\s*e\s*(\d{1,3})(?!\d)|'
                             r'(\d{1,2})x(\d{1,3})(?!\d)|'
                             r'(?:season|serie|sezona)\s*(\d{1,2})\s*(?:episode|dil|epizoda)\s*(\d{1,3})(?!\d))', re.I)


def series_title_matches(name, aliases):
    """Exact title namespace, allowing metadata aliases and technical tags, never spin-off suffixes."""
    # Release group prefixes in brackets are not part of a series title.
    value = name.replace('_', ' ')
    normalized_aliases = [normalize(a).split() for a in aliases if normalize(a)]
    def strip_group(match):
        content = normalize(match.group(1)).split()
        return match.group(1) if content in normalized_aliases else ' '
    value = re.sub(r'^\s*\[([^]]+)\]\s*', strip_group, value)
    normalized = normalize(value)
    marker = EPISODE_PATTERN.search(normalized)
    prefix = normalized[:marker.start()] if marker else normalized
    # A release year/quality often separates the title from the episode marker.
    prefix = re.split(r'\b(?:(?:19|20)\d{2}|2160p|1080p|720p|576p|480p)\b', prefix)[0]
    remaining = prefix.split()
    matched = False
    for alias in sorted(normalized_aliases, key=len, reverse=True):
        while alias and len(remaining) >= len(alias):
            index = next((i for i in range(len(remaining) - len(alias) + 1)
                          if remaining[i:i + len(alias)] == alias), None)
            if index is None:
                break
            remaining[index:index + len(alias)] = []
            matched = True
    technical = {'en','eng','english','cz','cs','ces','cze','czech','sk','slk','slovak',
                 'dub','dab','dabing','dabbed','dual','multi','audio','hdtv','web','dl','webrip',
                 'bluray','bdrip','brrip','x264','x265','h264','h265','hevc'}
    return matched and not (set(remaining) - technical)


def filename_title(name):
    """Readable filename title before its episode/year/encoding, useful for catalogue lookup."""
    prefix = re.split(r'\b(?:s\s*\d{1,2}[ ._-]*e\s*\d{1,3}|\d{1,2}x\d{2,3}|(?:19|20)\d{2}|2160p|1080p|720p)\b',
                      name.replace('_', ' '), maxsplit=1, flags=re.I)[0]
    return re.sub(r'[._]+', ' ', prefix).strip(' -[]()')


def assess_source(source, names, year='', season=None, episode=None, min_mb=50, max_gb=20):
    name = source['name']
    ext = os.path.splitext(name.lower())[1]
    size = int(source.get('size') or 0)
    reason = ''
    if ext not in VIDEO_EXTENSIONS:
        reason = 'Not a supported video filename'
    elif size < min_mb * 1e6:
        reason = 'Below minimum size'
    elif size > max_gb * 1e9:
        reason = 'Above maximum size'
    # Match the title portion before the episode marker / release-year / quality tags.
    normalized = normalize(name)
    prefix = re.split(r'\b(?:s\s*\d{1,2}\s*e\s*\d{1,3}|\d{1,2}x\d{2,3}|(?:19|20)\d{2}|2160p|1080p|720p)\b', normalized)[0]
    title_words = set(prefix.split())
    coverage = max((len(set(normalize(n).split()) & title_words) / max(len(set(normalize(n).split())), 1)
                    for n in names if n), default=0)
    if season is not None:
        if not series_title_matches(name, names):
            reason = reason or ('Different series title or spin-off' if coverage >= .8 else 'Title does not match')
    else:
        extra_markers = {'sample', 'trailer', 'featurette'} & set(normalized.split())
        own_words = set(' '.join(normalize(n) for n in names).split())
        if extra_markers - own_words:
            reason = reason or 'Sample, trailer or extra'
    actual_episode = episode_numbers(name)
    if season is not None and actual_episode != (season, episode):
        reason = reason or 'Wrong or unrecognised episode'
    elif season is None and actual_episode:
        reason = reason or 'Episode file for a movie search'
    if coverage < .8:
        reason = reason or 'Title does not match'
    # Series filenames often carry the episode air year, rather than the series premiere year.
    if season is None and year:
        years = re.findall(r'\b(?:19|20)\d{2}\b', normalize(name))
        if years and str(year) not in years:
            reason = reason or 'Different movie release year'
    quality = re.search(r'(?<!\d)(2160|1080|720|576|480)[pi]?(?!\d)', name, re.I)
    langs = []
    for label, pattern in [('EN', r'\b(eng|en|english)\b'), ('CZ', r'\b(cz|cs|ces|cze|czech)\b'),
                           ('SK', r'\b(sk|slk|slo|slovak)\b')]:
        if re.search(pattern, normalized):
            langs.append(label)
    return dict(source, edition=edition(name), quality=quality.group(1) + 'p' if quality else 'Unknown',
                resolution=int(quality.group(1)) if quality else 0,
                languages=', '.join(langs) or 'Unknown', confidence=round(coverage, 2),
                accepted=not reason, rejection=reason,
                episode_match=season is not None and actual_episode == (season, episode),
                detected_season=actual_episode[0] if actual_episode else None,
                detected_episode=actual_episode[1] if actual_episode else None,
                detected_title=filename_title(name),
                series_match=series_title_matches(name, names) if season is not None else coverage >= .8,
                identity_match=(series_title_matches(name, names) and actual_episode == (season, episode)) if season is not None else coverage >= .8,
                metadata='Filename hints only; audio and subtitle tracks are unverified')


def source_groups(sources):
    """Only actual video candidates belong in the inspectable filtered count."""
    videos = [s for s in sources if os.path.splitext(s['name'].lower())[1] in VIDEO_EXTENSIONS]
    return ([s for s in videos if s['accepted']], [s for s in videos if not s['accepted']],
            len(sources) - len(videos))


def candidate_order(source, audio='eng'):
    return (not source['accepted'], not source.get('episode_match', False), source_order(source, audio))


def source_order(source, audio='eng'):
    preferred = 'CZ' if audio in ('ces', 'cze', 'cs', 'cz') else 'EN'
    resolution = source.get('resolution', 0)
    # Direct-play 1080p first, then 720p. Unknowns and 4K below known FullHD sources.
    quality = {1080: 4, 720: 3, 576: 2, 480: 1}.get(resolution, 0)
    return (-source.get('confidence', 0), -quality, preferred not in source.get('languages', ''), source.get('size', 0))

import os
import xbmcaddon
import xbmcvfs
from resources.lib.core import Store, TMDB, Webshare
from resources.lib.media import managed_usage, within

ADDON = xbmcaddon.Addon('plugin.video.personalcinema')


def setting(name):
    return ADDON.getSetting(name)


def store():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    return Store(os.path.join(path, 'library.sqlite'))


def tmdb():
    return TMDB(setting('tmdb_token'), setting('catalogue_language') or 'en-US')


def webshare():
    return Webshare(setting('ws_user'), setting('ws_password'))


def prehraj():
    from resources.lib.prehraj import PrehrajProvider
    profile=xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    return PrehrajProvider(profile,setting('prehraj_user'),setting('prehraj_password'))


def storage():
    root = storage_base()
    return os.path.join(root, 'PersonalCinema') if root else ''


def storage_base():
    if setting('storage_mode_initialized') == 'true' and setting('storage_mode') == '0':
        return ''
    return xbmcvfs.translatePath(setting('storage'))


def usage():
    if not storage():
        return 0
    db = store()
    try:
        paths = [r[0] for r in db.db.execute('SELECT path FROM downloads')]
        paths += [r[0] for r in db.db.execute('SELECT path FROM selected_subtitles')]
        paths += [r[0] for r in db.db.execute('SELECT path FROM media_subtitles')]
        return managed_usage(storage(), [p for p in paths if within(p, storage_base())])
    finally:
        db.db.close()


def limit():
    value = float(setting('storage_gb') or 20)
    if value <= 0:
        raise ValueError('Storage limit must be positive.')
    return int(value * 1000 ** 3)

"""Public Stremio-protocol HTTP stream indexes, mapped by IMDb identity."""
import hashlib
import json
import re
from urllib.parse import urlparse, quote
from resources.lib.core import ProviderError
from resources.lib.providers import candidate, json_request, check_cancelled
from resources.lib.media import validate_direct_url


class HTTPAddonProvider:
    def __init__(self, manifest_url):
        parsed = urlparse(manifest_url.strip())
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
                or parsed.query or parsed.fragment or not parsed.path.endswith('/manifest.json')):
            raise ProviderError('Use a public HTTPS manifest.json URL without account tokens, query parameters or embedded credentials.')
        self.base = manifest_url.strip()[:-len('/manifest.json')]
        self.id = 'httpaddon_' + hashlib.sha256(self.base.encode()).hexdigest()[:12]
        self.name = parsed.hostname

    def manifest(self):
        value = json_request(self.base + '/manifest.json')
        resources = [r if isinstance(r,str) else r.get('name') for r in value.get('resources',[])]
        if 'stream' not in resources:
            raise ProviderError('This manifest does not provide streams; metadata-only catalogues add no playback sources.')
        self.name = str(value.get('name') or self.name)[:80]
        return value

    def sources(self, kind, video):
        data = json_request(self.base + '/stream/%s/%s.json' % (kind,quote(video,safe=':')))
        results = []
        for index, stream in enumerate(data.get('streams', [])):
            # Torrent hashes and external browser links need a different player.
            link = stream.get('url') or ''
            parsed = urlparse(link)
            if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
                continue
            if stream.get('drm') or stream.get('infoHash'):
                continue
            name = str(stream.get('name') or self.name)
            description = str(stream.get('description') or stream.get('title') or '')
            identity = hashlib.sha256(json.dumps([index,name,description],ensure_ascii=False).encode()).hexdigest()[:20]
            hints = stream.get('behaviorHints') or {}
            filename = hints.get('filename') or name + ' ' + description
            resolution = re.search(r'\b(2160|1080|720|576|480)p?\b', filename, re.I)
            results.append(candidate(self.id, video+':'+identity, name+' '+description,
                                     stream_key=identity, video_id=video, stream_kind=kind,
                                     resolution=int(resolution.group(1)) if resolution else 0,
                                     quality=resolution.group(1)+'p' if resolution else 'Unknown',
                                     metadata='IMDb/episode ID supplied to public HTTP index; quality is a provider label, tracks unverified'))
        return results

    def find(self, data, names, cancelled=lambda: False):
        check_cancelled(cancelled)
        imdb = data.get('imdb_id') or ''
        if not re.fullmatch(r'tt\d+', imdb):
            return []
        manifest = self.manifest()
        check_cancelled(cancelled)
        kind = 'series' if data.get('season') is not None else 'movie'
        if kind not in manifest.get('types', []):
            return []
        video = imdb + (':%d:%d' % (data['season'], data['episode']) if kind == 'series' else '')
        return self.sources(kind, video)

    def resolve(self, source):
        # Re-fetch ephemeral URLs; source records contain stable keys only.
        data = json_request(self.base + '/stream/%s/%s.json' % (source['stream_kind'],quote(source['video_id'],safe=':')))
        for index, stream in enumerate(data.get('streams', [])):
            name = str(stream.get('name') or self.name)
            description = str(stream.get('description') or stream.get('title') or '')
            identity = hashlib.sha256(json.dumps([index,name,description],ensure_ascii=False).encode()).hexdigest()[:20]
            if identity == source['stream_key']:
                link = stream.get('url') or ''
                validate_direct_url(link)
                return {'url':link}
        raise ProviderError('HTTP provider streams changed. Refresh sources.')

"""Bundled navigation art and source badges; no image library needed in Kodi."""
import os
import re


MENU = {
    'search': 'search', 'search_history': 'history', 'clear_search_history': 'trash',
    'library': 'library', 'downloads': 'download', 'download': 'download',
    'accounts': 'accounts', 'playback_tools': 'playback', 'settings': 'settings',
    'storage_status': 'storage', 'playback_log': 'log', 'export': 'export',
    'about': 'info', 'close_addon': 'exit', 'quit_kodi': 'power',
    'sources': 'sources', 'source_help': 'info', 'manual': 'link',
    'subtitles': 'subtitles', 'season': 'series', 'edition_filter': 'filter',
    'free_home': 'sources', 'ct_search': 'search', 'archive_search': 'search',
    'ct_categories': 'library', 'ct_category': 'library', 'ct_show': 'series',
    'ct_episodes': 'series', 'local_library': 'library', 'choose_library': 'storage',
    'youtube': 'link', 'open_web': 'link', 'watch_providers': 'info', 'provider_checks': 'log',
    'web_search':'search', 'video_home':'playback', 'video_history':'history', 'manage_providers':'sources',
    'oneplay_home':'playback','oneplay_browse':'series','oneplay_search':'search','oneplay_play':'playback',
    'cache_status':'storage','cache_action':'storage',
    'prehraj_link':'link',
}


def menu_art(root, action, data=None, args=None):
    name = 'download' if action == 'updates' else MENU.get(action, 'movie')
    if action == 'title':
        name = 'series' if (data or {}).get('media_type') == 'tv' else 'movie'
    if action == 'sources':
        args = args or {}
        name = 'filter' if args.get('show_hidden') else 'search' if args.get('custom') else 'sources'
    return os.path.join(root, 'resources', 'art', 'menu', name + '.png')


def source_badge_key(source):
    resolution = int(source.get('resolution') or 0)
    quality = {2160: 'uhd', 1080: 'fhd', 720: 'hd', 576: 'sd', 480: 'sd', 404: 'sd', 288: 'sd'}.get(resolution, 'unknown')
    tokens = re.findall(r'[A-Z]+', str(source.get('languages') or '').upper())
    languages = [code.lower() for code in ('EN', 'CZ', 'SK') if code in tokens]
    return quality + '-' + ('-'.join(languages) or 'unknown') + ('-verified' if source.get('language_verified') else '')


def source_art(root, source):
    return localized_art(os.path.join(root, 'resources', 'art', 'sources', source_badge_key(source) + '.png'))


def localized_art(path):
    # Share the same badges in both languages, including previously cached paths.
    return path.replace('sources-cs/', 'sources/').replace('sources-cs\\', 'sources\\')

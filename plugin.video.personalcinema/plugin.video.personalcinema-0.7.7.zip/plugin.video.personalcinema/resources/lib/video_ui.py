"""Standalone video dialogs. Long work never runs in movie WindowXML callbacks."""
import time
import xbmc
import xbmcgui
from resources.lib.core import ProviderError
from resources.lib.providers import ProviderCancelled, PROVIDER_NAMES
from resources.lib.webvideo import video_id


def wait_for_dialogs():
    monitor = xbmc.Monitor()
    deadline = time.monotonic() + 3
    while xbmc.getCondVisibility('System.HasModalDialog'):
        if time.monotonic() > deadline or monitor.waitForAbort(.05):
            raise ProviderCancelled('Close the other Kodi dialog and reopen Videos.')


def run(app, initial=None):
    dialog = app['DIALOG']
    db = app['DB']
    initial = initial or {}

    def choose(heading, labels):
        wait_for_dialogs()
        return dialog.select(heading, labels)

    def keyboard(heading):
        wait_for_dialogs()
        return dialog.input(heading)

    def open_video(provider, ident):
        client = app['web_video'](provider)
        key = provider + ':' + ident
        def load(cancelled):
            info = client.info(ident, cancelled=cancelled)
            return info, client.sources(ident, cancelled=cancelled)
        wait_for_dialogs()
        info, sources = app['video_task']('Loading video qualities', load)
        data = {'title':info.get('title') or ident, 'native_provider':provider,
                'video_id':ident, 'image':info.get('thumbnail'), 'overview':info.get('description') or ''}
        db.title(key, data)
        db.record_check(key, data['title'], sources, provider=provider)
        selected = choose('Video quality — ' + data['title'], [s['quality'] for s in sources])
        if selected < 0:
            return False
        source = sources[selected]
        wait_for_dialogs()
        resolved = app['video_task']('Opening video stream', lambda cancelled:client.resolve(source,cancelled=cancelled))
        wait_for_dialogs()
        app['play'](resolved, key, source)
        return True

    def search(provider, query=''):
        query = query or keyboard('Search '+PROVIDER_NAMES[provider])
        if not query:
            return False
        db.remember_search(query,provider)
        wait_for_dialogs()
        rows, _ = app['video_task']('Searching '+PROVIDER_NAMES[provider], lambda cancelled:
                                  app['web_video'](provider).search(query,cancelled=cancelled))
        if not rows:
            wait_for_dialogs()
            dialog.ok(PROVIDER_NAMES[provider], 'No public video results were returned.')
            return False
        while True:
            selected = choose(PROVIDER_NAMES[provider]+' — '+query,
                              ['%s | %.0f min' % (row['title'],(row.get('duration') or 0)/60) for row in rows])
            if selected < 0:
                return False
            if open_video(provider,rows[selected]['id']):
                return True

    def recent():
        import json
        rows = []
        for row in db.db.execute('SELECT key,data FROM titles ORDER BY updated DESC LIMIT 500'):
            data = json.loads(row['data'])
            if data.get('native_provider') in ('youtube','dailymotion'):
                rows.append(data)
        selected = choose('Recent videos', [r.get('title') or r['video_id'] for r in rows])
        if selected >= 0:
            return open_video(rows[selected]['native_provider'],rows[selected]['video_id'])
        return False

    pending = initial
    while not xbmc.Monitor().abortRequested():
        try:
            if pending.get('ident'):
                if open_video(pending['provider'],pending['ident']):return
            elif pending.get('link'):
                provider, ident = video_id(pending['link'])
                if open_video(provider,ident):return
            elif pending.get('action') == 'web_search':
                if search(pending.get('provider','youtube'),pending.get('query','')):return
            elif pending.get('action') == 'video_history':
                if recent():return
            elif pending.get('action') == 'youtube':
                link = keyboard('Paste a YouTube or Dailymotion video link')
                if link:
                    provider,ident=video_id(link)
                    if open_video(provider,ident):return
            else:
                selected = choose('Personal Cinema — videos',
                                  ['Search YouTube','Search Dailymotion','Paste video link','Recent videos','Done'])
                if selected < 0 or selected == 4:return
                if selected in (0,1):
                    if search(('youtube','dailymotion')[selected]):return
                elif selected == 2:
                    pending={'action':'youtube'}
                    continue
                elif recent():return
        except ProviderCancelled:
            return
        except ProviderError as exc:
            wait_for_dialogs()
            dialog.ok('Personal Cinema videos',str(exc))
        pending = {}

"""Login-free source adapters. Persist identities, resolve media URLs only on use."""
import hashlib
import json
import os
import re
from urllib.parse import quote, urlencode
from resources.lib.core import ProviderError, request, normalize
from resources.lib.discovery import assess_source, VIDEO_EXTENSIONS

PROVIDER_NAMES = {'webshare': 'Webshare', 'prehraj': 'Přehraj.to', 'oneplay': 'Oneplay', 'ct': 'ČT iVysílání', 'archive': 'Internet Archive',
                  'local': 'Local files', 'youtube': 'YouTube', 'dailymotion':'Dailymotion', 'stremio': 'Stremio provider'}


class ProviderCancelled(ProviderError):
    pass


def check_cancelled(cancelled):
    if cancelled():
        raise ProviderCancelled('Provider search cancelled.')


def observed_languages(source):
    mapping = {'eng':'EN', 'en':'EN', 'cze':'CZ', 'ces':'CZ', 'cs':'CZ', 'cz':'CZ', 'slk':'SK', 'sk':'SK'}
    labels = list(dict.fromkeys(mapping.get(s.get('language', '').lower(), s.get('language', '').upper())
                               for s in source.get('observed_audio', []) if s.get('language')))
    if labels:
        source.update(languages=', '.join(labels), language_verified=True)
    return source


def json_request(url, data=None):
    payload = json.dumps(data).encode('utf-8') if data is not None else None
    with request(url, payload, {'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=12) as response:
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ProviderError('Provider response is too large. Refine your search.')
    try:
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError('Expected an object')
        return value
    except (ValueError, UnicodeError):
        raise ProviderError('Provider returned an invalid response.') from None


def candidate(provider, ident, name, **info):
    result = dict(provider=provider, id=str(ident), name=name, size=0, resolution=0,
                  quality='Unknown', languages='Unknown', edition='Edition unspecified',
                  accepted=True, identity_match=True, confidence=1, rejection='',
                  episode_match=False, detected_season=None, detected_episode=None,
                  detected_title=name, metadata='Provider catalogue selection',
                  downloadable=False, language_verified=False)
    result.update(info)
    return result


def assess_candidate(source, names, year='', season=None, episode=None, min_mb=50, max_gb=20):
    if source.get('provider') in ('webshare', 'local', 'prehraj'):
        assessed = assess_source(source, names, year, season, episode, min_mb, max_gb)
        if source.get('provider') == 'prehraj':
            # Quality is a provider variant, not a filename hint. Its stable ID
            # also repairs older cached records whose resolution was overwritten.
            variant = re.fullmatch(r'[a-f0-9]{10,32}:(\d{3,4})', str(source.get('id', '')))
            height = int(variant[1]) if variant else int(source.get('resolution') or 0)
            if 0 < height <= 1080:
                assessed.update(resolution=height, quality=str(height)+'p')
        if source.get('provider') in ('local','prehraj') and source.get('native_selection'):
            assessed.update(accepted=True, identity_match=True, rejection='')
        return observed_languages(assessed)
    # Catalogue IDs selected in a provider's own browser do not use filename filters.
    result = observed_languages(dict(source))
    # Catalogue identity does not prove that a file is a full movie. Do not
    # apply file-size limits to small HLS/DASH manifests or subtitle resources.
    if source.get('provider') == 'archive':
        size = int(source.get('size') or 0)
        reason = ('Below minimum size' if size and size < min_mb * 1e6 else
                  'Above maximum size' if size > max_gb * 1e9 else '')
        words = set(normalize(source.get('name', '')).split())
        if {'trailer', 'sample', 'featurette'} & words - set(normalize(' '.join(names)).split()):
            reason = reason or 'Sample, trailer or extra'
        duration = float(source.get('duration') or 0)
        if duration and source.get('expected_duration') and duration < source['expected_duration'] * .7:
            reason = reason or 'Much shorter than selected title'
        if reason:
            result.update(accepted=False, rejection=reason)
    return result


class ArchiveProvider:
    id = 'archive'

    def search(self, query, page=1):
        terms = ['mediatype:movies', 'title:(%s)' % json.dumps(query, ensure_ascii=False)]
        params = [('q', ' AND '.join(terms)), ('rows', '20'), ('page', str(page)),
                  ('output', 'json')]
        params += [('fl[]', field) for field in ('identifier', 'title', 'year', 'date', 'description', 'language')]
        data = json_request('https://archive.org/advancedsearch.php?' + urlencode(params))
        response = data.get('response')
        if not isinstance(response, dict):
            raise ProviderError('Internet Archive search is unavailable. Try again later.')
        return response.get('docs', []), int(response.get('numFound', 0))

    def details(self, ident):
        data = json_request('https://archive.org/metadata/' + quote(ident, safe=''))
        if not isinstance(data, dict) or not data.get('metadata'):
            raise ProviderError('Internet Archive item is unavailable or removed.')
        if data.get('is_dark') or str(data['metadata'].get('nodownload', '')).lower() == 'true':
            raise ProviderError('This Internet Archive item is restricted, not a public download.')
        return data

    def sources(self, ident):
        data = self.details(ident)
        title = str(data['metadata'].get('title') or ident)
        sources = []
        for file in data.get('files', []):
            name = file.get('name', '')
            if file.get('private') or os.path.splitext(name.lower())[1] not in VIDEO_EXTENSIONS | {'.ogv'}:
                continue
            try:
                size = int(file.get('size') or 0)
                height = int(file.get('height') or 0)
            except (TypeError, ValueError):
                continue
            if not size:
                continue
            match = re.search(r'\b(2160|1080|720|576|480)[pi]\b', name, re.I)
            height = height or (int(match.group(1)) if match else 0)
            sources.append(candidate('archive', ident + ':' + name, name,
                                     archive_id=ident, file_name=name, size=size, resolution=height,
                                     quality=str(height) + 'p' if height else file.get('format', 'Unknown'),
                                     detected_title=title, downloadable=True,
                                     duration=float(file.get('length') or 0) if str(file.get('length') or '').replace('.', '', 1).isdigit() else 0,
                                     metadata='Internet Archive file metadata; audio tracks not yet verified'))
        return sources

    def find(self, data, names, cancelled=lambda: False):
        # Episodic uploads have no dependable universal season/episode mapping.
        if data.get('season') is not None:
            return []
        wanted_year = str(data.get('release_date') or '')[:4]
        matches = []
        seen = set()
        for query in names[:2]:
            check_cancelled(cancelled)
            docs, _ = self.search(query)
            for doc in docs:
                check_cancelled(cancelled)
                ident = doc.get('identifier')
                title = str(doc.get('title') or '')
                year = str(doc.get('year') or doc.get('date') or '')[:4]
                if ident in seen or normalize(title) not in {normalize(n) for n in names}:
                    continue
                if wanted_year and year != wanted_year:
                    continue
                seen.add(ident)
                matches.extend(self.sources(ident))
                if len(seen) >= 2:
                    return matches
        return matches

    def resolve(self, source):
        # Recheck removal/restrictions and that the selected file still exists.
        files = self.sources(source['archive_id'])
        if not any(s['id'] == source['id'] for s in files):
            raise ProviderError('Internet Archive file is no longer available. Refresh sources.')
        return {'url': 'https://archive.org/download/%s/%s' %
                (quote(source['archive_id'], safe=''), quote(source['file_name'], safe='/'))}


class LocalProvider:
    id = 'local'

    def __init__(self, root):
        self.root = os.path.realpath(root) if root else ''
        self.library_id = hashlib.sha256(os.path.normcase(self.root).encode('utf-8')).hexdigest()[:20]

    def scan(self, cancelled=lambda: False):
        if not self.root or not os.path.isdir(self.root):
            raise ProviderError('Choose an existing read-only video-library folder in Free sources settings.')
        results = []
        for base, dirs, names in os.walk(self.root, followlinks=False):
            check_cancelled(cancelled)
            dirs[:] = sorted(d for d in dirs if not d.startswith('.') and not os.path.islink(os.path.join(base, d)))
            for name in sorted(names):
                path = os.path.realpath(os.path.join(base, name))
                if os.path.splitext(name.lower())[1] not in VIDEO_EXTENSIONS:
                    continue
                try:
                    if os.path.commonpath([path, self.root]) != self.root or not os.path.isfile(path):
                        continue
                    relative = os.path.relpath(path, self.root)
                    size = os.path.getsize(path)
                except (OSError, ValueError):
                    continue
                ident = hashlib.sha256((self.library_id + relative).encode('utf-8')).hexdigest()[:24]
                results.append(candidate('local', ident, name, relative_path=relative, library_id=self.library_id, size=size))
                if len(results) >= 5000:
                    return results, True
        return results, False

    def find(self, data, names, cancelled=lambda: False):
        sources, _ = self.scan(cancelled)
        return sources

    def resolve(self, source):
        if source.get('library_id') != self.library_id:
            raise ProviderError('The local library folder changed. Browse it again to select this video.')
        path = os.path.realpath(os.path.join(self.root, source['relative_path']))
        try:
            inside = os.path.commonpath([path, self.root]) == self.root
        except ValueError:
            inside = False
        if not inside or not os.path.isfile(path):
            raise ProviderError('Local video is missing or outside the configured library folder.')
        return {'url': path}


def youtube_id(url):
    from urllib.parse import urlparse, parse_qs
    value = urlparse(url)
    host = (value.hostname or '').lower()
    ident = ''
    if host == 'youtu.be':
        ident = value.path.strip('/')
    elif host in ('youtube.com', 'www.youtube.com', 'm.youtube.com'):
        ident = parse_qs(value.query).get('v', [''])[0]
        if value.path.startswith(('/shorts/', '/embed/')):
            ident = value.path.split('/')[2]
    return ident if re.fullmatch(r'[A-Za-z0-9_-]{11}', ident) else ''


def resolve_candidate(source, local_root=''):
    provider = source['provider']
    if provider == 'archive':
        return ArchiveProvider().resolve(source)
    if provider == 'local':
        return LocalProvider(local_root).resolve(source)
    if provider == 'ct':
        from resources.lib.ct import CTProvider
        return CTProvider().resolve(source)
    raise ProviderError('This provider has no playback adapter.')

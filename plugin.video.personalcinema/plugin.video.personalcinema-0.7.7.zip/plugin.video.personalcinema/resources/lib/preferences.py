"""Settings in the chosen interface language, independent of Kodi's skin locale."""
import math
import json
import os
import xml.etree.ElementTree as ET
from urllib.parse import parse_qsl, urlparse
import xbmcgui
from resources.lib.i18n import tr, Dialog


def open_settings(addon, dispatch, root):
    dialog = Dialog(xbmcgui.Dialog())
    categories = list(ET.parse(os.path.join(root, 'resources', 'settings.xml')).getroot())
    with open(os.path.join(root, 'resources', 'language', 'settings_labels.json'), encoding='utf-8') as stream:
        labels = json.load(stream)
    for category in categories:
        for field in [category] + list(category):
            field.set('label', labels.get(field.get('label'), field.get('label', '')))
    while True:
        index = dialog.select(tr('Settings'), [tr(c.get('label')) for c in categories] + [tr('Done')])
        if index < 0 or index >= len(categories):
            return
        category = categories[index]
        if category.get('label') == 'Storage':
            from resources.lib.storage_preferences import open_storage
            open_storage(addon, dispatch)
            continue
        fields = [f for f in category if f.get('visible') != 'false']
        while True:
            labels = []
            for field in fields:
                value = addon.getSetting(field.get('id', '')) or field.get('default', '')
                kind = field.get('type')
                if kind == 'bool': value = tr('On' if value == 'true' else 'Off')
                if field.get('id') == 'ui_language': value = 'Čeština' if value == '1' else 'English'
                label = tr(field.get('label', ''))
                labels.append(label + (': ' + value if field.get('id') else ''))
            selected = dialog.select(tr(category.get('label')), labels + [tr('Back')])
            if selected < 0 or selected >= len(fields):
                break
            field = fields[selected]; kind = field.get('type'); ident = field.get('id')
            value = addon.getSetting(ident) or field.get('default', '') if ident else ''
            if ident == 'ui_language':
                choice = dialog.select('Interface language / Jazyk rozhraní', ['English', 'Čeština'])
                if choice >= 0: addon.setSetting(ident, str(choice))
            elif kind == 'action':
                action = field.get('action', '')
                if action.startswith('RunPlugin(plugin://plugin.video.personalcinema/?') and action.endswith(')'):
                    dispatch(dict(parse_qsl(urlparse(action[len('RunPlugin('):-1]).query)))
                return
            elif kind == 'lsep':
                dialog.ok(tr(category.get('label')), tr(field.get('label')))
            elif kind == 'bool':
                addon.setSetting(ident, 'false' if value == 'true' else 'true')
            elif kind == 'folder':
                folder = dialog.browseSingle(0, tr(field.get('label')), 'files', defaultt=value)
                if folder: addon.setSetting(ident, folder)
            else:
                result = dialog.input(tr(field.get('label')), defaultt=value)
                if result:
                    if kind == 'number':
                        try:
                            number = float(result)
                            if not math.isfinite(number) or number <= 0: raise ValueError()
                        except ValueError:
                            dialog.ok(tr('Settings'), tr('Enter a positive number.'))
                            continue
                    addon.setSetting(ident, result)

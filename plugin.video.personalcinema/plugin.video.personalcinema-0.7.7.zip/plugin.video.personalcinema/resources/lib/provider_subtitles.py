"""Convert provider captions into complete, seekable SRT files before playback."""
import html
import json
import os
import re
from resources.lib.core import ProviderError, request


def stamp(value):
    value = str(value).strip().replace('.', ',')
    if re.fullmatch(r'\d{2}:\d{2},\d{3}', value):
        value = '00:' + value
    if not re.fullmatch(r'\d{2,3}:\d{2}:\d{2},\d{3}', value):
        raise ProviderError('Provider subtitle timestamps are invalid.')
    return value


def caption_text(value):
    value = re.sub(r'<br\s*/?>', '\n', str(value), flags=re.I)
    return html.unescape(re.sub(r'<[^>]*>', '', value)).strip()


def ct_json_to_srt(raw):
    try:
        rows = json.loads(raw)
        if not isinstance(rows, list):
            raise ValueError()
        cues = []
        for row in rows:
            text = caption_text(row['text'])
            if text:
                cues.append('%d\n%s --> %s\n%s\n' %
                            (len(cues)+1, stamp(row['fromTime']), stamp(row['toTime']), text))
        if not cues:
            raise ValueError()
        return '\n'.join(cues).encode('utf-8')
    except (ValueError, TypeError, KeyError):
        raise ProviderError('ČT returned invalid subtitle data.') from None


def vtt_to_srt(raw):
    text = raw.decode('utf-8-sig') if isinstance(raw, bytes) else raw
    cues = []
    for block in re.split(r'\r?\n\s*\r?\n', text):
        lines = block.strip().splitlines()
        if not lines or lines[0].startswith(('WEBVTT', 'NOTE', 'STYLE', 'REGION')):
            continue
        marker = next((i for i,line in enumerate(lines) if '-->' in line), None)
        if marker is None:
            continue
        times = lines[marker].split('-->')
        body = caption_text('\n'.join(lines[marker+1:]))
        if body:
            cues.append('%d\n%s --> %s\n%s\n' %
                        (len(cues)+1, stamp(times[0]), stamp(times[1].strip().split()[0]), body))
    if not cues:
        raise ProviderError('Provider returned no subtitle cues.')
    return '\n'.join(cues).encode('utf-8')


def cache_ct_subtitles(resolved, idec, root, quota, used):
    if not root:
        raise ProviderError('Set a media folder in Settings → Storage to enable downloads and disk buffering.')
    paths = []
    for track in resolved.get('subtitle_tracks', []):
        language = re.sub(r'[^a-zA-Z-]', '', track.get('language') or 'unknown')[:12]
        target = os.path.join(root, 'subtitles', 'ct-%s.%s.srt' % (str(idec), language))
        if os.path.isfile(target):
            paths.append(target)
            continue
        with request(track['url'], timeout=12) as response:
            raw = response.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ProviderError('Provider subtitle file exceeded 2 MB.')
        content = ct_json_to_srt(raw) if track['format'] == 'json' else vtt_to_srt(raw)
        if used + len(content) > quota:
            raise ProviderError('Managed storage is full; provider subtitles could not be saved.')
        os.makedirs(os.path.dirname(target), exist_ok=True)
        temporary = target + '.part'
        with open(temporary, 'wb') as stream:
            stream.write(content)
        os.replace(temporary, target)
        used += len(content)
        paths.append(target)
    return paths

"""Bounded disk-backed HTTP range cache. Background fill continues while paused."""
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from resources.lib.core import ProviderError, request

BLOCK=256*1024


def byte_range(value,size):
    if not value:return 0,size-1,False
    match=re.fullmatch(r'bytes=(\d*)-(\d*)',value)
    if not match or not any(match.groups()):raise ValueError('Invalid byte range')
    if not match[1]:start=max(0,size-int(match[2]));end=size-1
    else:start=int(match[1]);end=min(size-1,int(match[2]) if match[2] else size-1)
    if start>=size or start<0 or end<start:raise ValueError('Unsatisfiable range')
    return start,end,True


class DiskFile:
    def __init__(self,url,path,size,headers=None,progress=lambda count:None,allow_http=False):
        parsed=urlparse(url)
        if parsed.scheme!='https' and not allow_http:raise ProviderError('Disk buffering requires an HTTPS file source.')
        if size<=0:raise ProviderError('File size must be known before reserving disk space.')
        self.url,self.path,self.size=url,path,int(size)
        self.headers=headers or {};self.progress=progress
        self.blocks=set();self.lock=threading.Lock();self.stopped=threading.Event()
        self.priority=threading.Event();self.error='';self.complete=False
        os.makedirs(os.path.dirname(path),exist_ok=True)
        # Reserve the whole logical size upfront. Managed usage therefore also
        # counts bytes not downloaded yet, preventing overcommitting the quota.
        with open(path,'xb') as output:output.truncate(size)
        self.thread=threading.Thread(target=self.fill,daemon=True)
        self.thread.start()

    @property
    def downloaded(self):
        return sum(min(BLOCK,self.size-n*BLOCK) for n in self.blocks.copy())

    def block(self,index):
        with self.lock:
            if self.stopped.is_set():raise ProviderError('Disk buffering stopped.')
            if index in self.blocks:return
            if self.error:raise ProviderError(self.error)
            start=index*BLOCK;end=min(start+BLOCK,self.size)-1
            headers=dict(self.headers,Range='bytes=%d-%d' % (start,end))
            with request(self.url,headers=headers,timeout=12) as response:
                expected='bytes %d-%d/%d' % (start,end,self.size)
                if response.getcode()!=206 or response.headers.get('Content-Range')!=expected:
                    raise ProviderError('Provider does not support reliable byte ranges for disk buffering.')
                body=response.read(end-start+2)
            if len(body)!=end-start+1:raise ProviderError('Incomplete cache block; refresh the source and retry.')
            if self.stopped.is_set():raise ProviderError('Disk buffering stopped.')
            with open(self.path,'r+b') as output:
                output.seek(start);output.write(body)
            self.blocks.add(index)
            self.progress(self.downloaded)

    def fill(self):
        try:
            for index in range((self.size+BLOCK-1)//BLOCK):
                if self.stopped.is_set():return
                while self.priority.is_set():
                    if self.stopped.wait(.02):return
                self.block(index)
            self.complete=True
        except Exception as exc:
            if not self.stopped.is_set():
                self.error=str(exc) if isinstance(exc,ProviderError) else 'Disk buffering failed; refresh the source to retry.'

    def read(self,start,count):
        self.priority.set()
        try:
            index=start//BLOCK
            self.block(index)
            count=min(count,BLOCK-start%BLOCK,self.size-start)
            with open(self.path,'rb') as source:source.seek(start);return source.read(count)
        finally:self.priority.clear()

    def close(self,delete=True):
        self.stopped.set();self.thread.join(timeout=13)
        with self.lock:
            if delete and os.path.isfile(self.path):os.remove(self.path)


class CacheServer:
    def __init__(self,token):
        self.files={};self.token=token
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_HEAD(self):self.send_file(True)
            def do_GET(self):self.send_file(False)
            def send_file(self,head):
                parts=urlparse(self.path).path.split('/')
                if len(parts)!=3 or parts[1]!=owner.token or parts[2] not in owner.files:
                    self.send_error(404);return
                file=owner.files[parts[2]]
                try:start,end,partial=byte_range(self.headers.get('Range'),file.size)
                except ValueError:
                    self.send_response(416);self.send_header('Content-Range','bytes */%d' % file.size);self.end_headers();return
                sent=False
                try:
                    first=file.read(start,min(64*1024,end-start+1)) if not head else b''
                    self.send_response(206 if partial else 200)
                    self.send_header('Content-Type','application/octet-stream')
                    self.send_header('Content-Length',str(end-start+1))
                    self.send_header('Accept-Ranges','bytes')
                    self.send_header('Cache-Control','no-store')
                    if partial:self.send_header('Content-Range','bytes %d-%d/%d' % (start,end,file.size))
                    self.end_headers();sent=True
                    if head:return
                    self.connection.settimeout(15)
                    self.wfile.write(first);start+=len(first)
                    while start<=end:
                        data=file.read(start,min(64*1024,end-start+1))
                        if not data:break
                        self.wfile.write(data);start+=len(data)
                except Exception:
                    if not sent:self.send_error(503,'Cache source unavailable')
                    self.close_connection=True
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads=True
        self.base='http://127.0.0.1:%d/%s/' % (self.server.server_port,token)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()

    def close(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=2)

"""Explicit storage mode, retained folder and dependent buffering options."""
import math
import os
import tempfile
import xbmcgui
import xbmcvfs
from resources.lib.i18n import tr, Dialog


def initialise(addon):
    if addon.getSetting('storage_mode_initialized') != 'true':
        addon.setSetting('storage_mode', '1' if addon.getSetting('storage') else '0')
        addon.setSetting('storage_mode_initialized', 'true')


def prepare_folder(folder):
    path = os.path.join(xbmcvfs.translatePath(folder), 'PersonalCinema')
    os.makedirs(path, exist_ok=True)
    with tempfile.TemporaryFile(dir=path) as stream:
        stream.write(b'Personal Cinema storage check')


def open_storage(addon, dispatch):
    initialise(addon)
    dialog = Dialog(xbmcgui.Dialog())
    while True:
        enabled = addon.getSetting('storage_mode') == '1' and bool(addon.getSetting('storage'))
        folder = addon.getSetting('storage')
        mode = tr('Media storage enabled' if enabled else 'Streaming only')
        limit = addon.getSetting('storage_gb') or '20'
        buffering = addon.getSetting('disk_cache') == 'true'
        keep = addon.getSetting('disk_cache_keep') == 'true'
        rows = [tr('Storage mode') + ': ' + mode,
                tr('Media folder') + ': ' + (folder or tr('Not selected')),
                tr('Storage limit') + ': ' + limit + ' GB',
                tr('Disk buffering') + ': ' + tr(('On' if buffering else 'Off') if enabled else 'Unavailable in streaming-only mode'),
                tr('Keep completed buffers') + ': ' + tr(('On' if keep else 'Off') if enabled and buffering else 'Requires disk buffering'),
                tr('Storage status'), tr('Back')]
        selected = dialog.select(tr('Storage') + ' — ' + mode, rows)
        if selected < 0 or selected == 6:
            return
        if selected == 0:
            choice = dialog.select(tr('Storage mode'), [tr('Streaming only'), tr('Media storage enabled')], preselect=1 if enabled else 0)
            if choice < 0:continue
            if choice == 0:
                dispatch({'action':'disable_storage','quiet':'1'})
            else:
                if not folder:
                    folder = dialog.browseSingle(0, tr('Choose a media folder'), 'files')
                    if not folder:continue
                try:prepare_folder(folder)
                except OSError:
                    dialog.ok(tr('Storage'), tr('The folder is not writable. Choose another folder.'))
                    continue
                addon.setSetting('storage',folder)
                addon.setSetting('storage_mode','1')
                addon.setSetting('storage_setup_done','true')
        elif selected == 1:
            chosen = dialog.browseSingle(0,tr('Choose a media folder'),'files',defaultt=folder)
            if not chosen:continue
            try:prepare_folder(chosen)
            except OSError:
                dialog.ok(tr('Storage'),tr('The folder is not writable. Choose another folder.'))
                continue
            if enabled and chosen != folder:dispatch({'action':'pause_storage'})
            addon.setSetting('storage',chosen)
        elif selected == 2:
            value=dialog.input(tr('Storage limit (GB)'),defaultt=limit)
            if not value:continue
            try:
                number=float(value)
                if not math.isfinite(number) or number <= 0:raise ValueError()
            except ValueError:
                dialog.ok(tr('Storage'),tr('Enter a positive number.'))
                continue
            addon.setSetting('storage_gb',value)
        elif selected == 3:
            if not enabled:
                dialog.ok(tr('Disk buffering'),tr('Change Storage mode to Media storage enabled first.'))
            else:addon.setSetting('disk_cache','false' if buffering else 'true')
        elif selected == 4:
            if not enabled or not buffering:
                dialog.ok(tr('Keep completed buffers'),tr('Enable disk buffering first.'))
            else:addon.setSetting('disk_cache_keep','false' if keep else 'true')
        elif selected == 5:dispatch({'action':'storage_status'})

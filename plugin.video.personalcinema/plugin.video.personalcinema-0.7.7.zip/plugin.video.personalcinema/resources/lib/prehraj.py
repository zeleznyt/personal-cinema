"""Přehraj.to: public search, optional account, stable source IDs; never execute page scripts."""
import html
import http.cookiejar
import json
import os
import re
import threading
import time
from html.parser import HTMLParser
from urllib.error import HTTPError
from urllib.parse import quote, urlencode, urljoin, urlparse
from urllib.request import Request, build_opener, HTTPCookieProcessor, HTTPRedirectHandler
from resources.lib.core import ProviderError, normalize
from resources.lib.discovery import assess_source
from resources.lib.providers import candidate, check_cancelled, ProviderCancelled

BASE = 'https://prehraj.to'
_LOCK = threading.Lock()
_LAST = 0
_BLOCKED = 0
_CACHE = {}


class SiteRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urlparse(newurl).scheme != 'https' or urlparse(newurl).hostname not in ('prehraj.to', 'www.prehraj.to'):
            raise ProviderError('Přehraj redirected outside the configured provider. Redirect blocked; check the provider domain.')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Page(HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[]; self.forms=[]; self.form=None; self.title=''
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag=='a' and a.get('href'):self.links.append(a['href'])
        if tag=='meta' and a.get('property')=='og:title':self.title=a.get('content','')
        if tag=='form':
            self.form={'action':a.get('action',''), 'id':a.get('id',''), 'fields':{}}
            self.forms.append(self.form)
        if tag=='input' and self.form is not None and a.get('name'):
            if a.get('type')=='hidden':self.form['fields'][a['name']]=a.get('value','')
    def handle_endtag(self,tag):
        if tag=='form':self.form=None


def parse_sources(body):
    # Parse only the published media descriptors, not arbitrary JS or embeds.
    result={}
    for block in re.findall(r'\{[^{}]{0,6000}\}',body):
        link=re.search(r'''(?:file|src)\s*:\s*["'](https://[^"']+)["']''',block)
        quality=re.search(r'''(?:label|res)\s*:\s*["']?(\d{3,4})p?''',block)
        if not link or not quality:continue
        height=int(quality[1]); value=html.unescape(link[1].replace('\\/','/'))
        host=urlparse(value).hostname or ''
        if height>1080 or not host.endswith('.premiumcdn.net') or not urlparse(value).path.lower().endswith('.mp4'):continue
        result.setdefault(height,value)
    return result


class PrehrajProvider:
    id='prehraj'
    def __init__(self, profile='', user='', password=''):
        self.user,self.password=user,password
        self.cookies=http.cookiejar.LWPCookieJar(os.path.join(profile,'prehraj-session.cookies') if profile else None)
        if profile:
            os.makedirs(profile,exist_ok=True)
            try:self.cookies.load(ignore_discard=True)
            except (OSError,http.cookiejar.LoadError):pass
        self.opener=build_opener(HTTPCookieProcessor(self.cookies),SiteRedirect())
        self.profile=profile
        if profile:
            try:
                with open(os.path.join(profile,'prehraj-search-cache.json'),encoding='utf8') as source:
                    for key,value in json.load(source).items():
                        if isinstance(value,list) and len(value)==2 and time.time()-float(value[0])<21600:_CACHE[key]=value
            except (OSError,ValueError,TypeError,AttributeError):pass

    def page(self,path,post=None,cancelled=lambda:False):
        global _LAST,_BLOCKED
        url=urljoin(BASE,path)
        if urlparse(url).hostname not in ('prehraj.to','www.prehraj.to'):
            raise ProviderError('Unsupported Přehraj domain.')
        with _LOCK:
            if self.profile:
                try:
                    with open(os.path.join(self.profile,'prehraj-retry-after.txt')) as source:
                        if time.time()<float(source.read()):raise ProviderError('Přehraj is rate-limited. Try again after the provider cooldown.')
                except (OSError,ValueError):pass
            if time.monotonic()<_BLOCKED:
                raise ProviderError('Přehraj is rate-limited. Cached results remain available; try again later.')
            while time.monotonic()-_LAST<1.5:
                check_cancelled(cancelled);time.sleep(.1)
            check_cancelled(cancelled);_LAST=time.monotonic()
            try:
                req=Request(url, data=urlencode(post).encode() if post else None,
                            headers={'User-Agent':'PersonalCinema/0.7.0','Referer':BASE+'/'})
                with self.opener.open(req,timeout=12) as response:
                    raw=response.read(2_000_001)
                    charset=response.headers.get_content_charset() or 'utf-8'
                if len(raw)>2_000_000:raise ProviderError('Přehraj page exceeded its size limit.')
                return raw.decode(charset,errors='replace')
            except HTTPError as exc:
                if exc.code==429:
                    try:delay=max(60,min(3600,int(exc.headers.get('Retry-After','300'))))
                    except ValueError:delay=300
                    _BLOCKED=time.monotonic()+delay
                    if self.profile:
                        with open(os.path.join(self.profile,'prehraj-retry-after.txt'),'w') as target:target.write(str(time.time()+delay))
                    raise ProviderError('Přehraj rate limit reached. Wait before retrying; previous results are preserved.') from None
                raise ProviderError('Přehraj request failed (HTTP %d).' % exc.code) from None
            except ProviderError:raise
            except Exception:raise ProviderError('Přehraj is unavailable. Check your connection and try later.') from None

    def login(self):
        if not self.user or not self.password:raise ProviderError('Enter the Přehraj email and password first.')
        body=self.page('/')
        page=Page();page.feed(body)
        form=next((f for f in page.forms if f['id']=='frm-loginDialog-login-loginForm'),None)
        if not form:raise ProviderError('Přehraj login form changed. Account was not submitted.')
        body=self.page(form['action'] or '/',dict(form['fields'],email=self.user,password=self.password,remember_login='on'))
        status=self.status(body)
        if not status['signed_in']:
            raise ProviderError('Přehraj login was not confirmed. Check credentials or sign-in requirements.')
        if self.profile:self.cookies.save(ignore_discard=True)
        return status

    def status(self,body=None):
        body=body if body is not None else self.page('/')
        signed=bool(re.search(r'(?:href|action)=["\'][^"\']*(?:logout|odhlasit)',body,re.I))
        # Do not infer subscription from marketing text saying "Premium".
        if re.search(r'(?:isPremium|is_premium)\s*[:=]\s*true\b',body):plan='active'
        elif re.search(r'(?:isPremium|is_premium)\s*[:=]\s*false\b',body):plan='inactive'
        else:plan='unknown'
        result={'signed_in':signed,'subscription':plan,'checked':time.time()}
        if self.profile:
            with open(os.path.join(self.profile,'prehraj-access.json'),'w',encoding='utf8') as output:json.dump(result,output)
        return result

    def cached_status(self):
        if self.profile:
            try:
                with open(os.path.join(self.profile,'prehraj-access.json'),encoding='utf8') as source:result=json.load(source)
                if time.time()-result.get('checked',0)<3600:return result
            except (OSError,ValueError,TypeError,AttributeError):pass
        return {'signed_in':False,'subscription':'unknown'}

    def search(self,query,cancelled=lambda:False):
        key=normalize(query)
        cached=_CACHE.get(key)
        if cached and time.time()-cached[0]<21600:return cached[1]
        body=self.page('/hledej/'+quote(query,safe=''),cancelled=cancelled)
        page=Page();page.feed(body);rows=[];seen=set()
        for link in page.links:
            parsed=urlparse(urljoin(BASE,link))
            match=re.fullmatch(r'/([^/]+)/([a-f0-9]{10,32})/?',parsed.path)
            if parsed.hostname not in ('prehraj.to','www.prehraj.to') or not match or match[2] in seen:continue
            seen.add(match[2]);rows.append({'id':match[2],'page':parsed.path,'name':match[1].replace('-',' ')+'.mp4'})
        _CACHE[key]=(time.time(),rows)
        while len(_CACHE)>100:_CACHE.pop(next(iter(_CACHE)))
        if self.profile:
            target=os.path.join(self.profile,'prehraj-search-cache.json')
            with open(target+'.tmp','w',encoding='utf8') as output:json.dump(_CACHE,output)
            os.replace(target+'.tmp',target)
        return rows

    def sources(self,row,cancelled=lambda:False):
        body=self.page(row['page'],cancelled=cancelled)
        title=Page();title.feed(body)
        name=(title.title or row['name']).split(' - online')[0].strip()
        if not name.lower().endswith('.mp4'):name+='.mp4'
        results=[]
        for height,link in sorted(parse_sources(body).items(),reverse=True):
            check_cancelled(cancelled)
            try:
                # HEAD carries no video payload. Never persist the signed URL.
                with request_head(link,row['page']) as response:
                    if not response.headers.get('Content-Type','').lower().startswith('video/'):continue
                    size=int(response.headers.get('Content-Length') or 0)
            except Exception:continue
            if not size:continue
            results.append(candidate('prehraj',row['id']+':'+str(height),name,page=row['page'],resolution=height,
                                     quality=str(height)+'p',size=size,downloadable=True,
                                     metadata='Přehraj public video file; audio/subtitle language hints unverified'))
        if not results:raise ProviderError('Přehraj returned no accessible video. Login or an active subscription may be required; free access has provider limits.')
        return results

    def find(self,data,names,cancelled=lambda:False):
        season,episode=data.get('season'),data.get('episode')
        year=(data.get('release_date') or '')[:4]
        for name in names[:3]:
            query=name+(' S%02dE%02d' % (season,episode) if season is not None else '')
            rows=self.search(query,cancelled)
            matches=[r for r in rows if assess_source(dict(r,provider='prehraj',size=1_000_000_000),names,year,season,episode,0)['accepted']]
            if matches:
                results=[];error=None
                for row in matches[:2]:
                    try:results.extend(self.sources(row,cancelled))
                    except ProviderCancelled:raise
                    except ProviderError as exc:error=exc
                if results:return results
                if error:raise error
        return []

    def resolve(self,source):
        body=self.page(source['page'])
        variant=re.fullmatch(r'[a-f0-9]{10,32}:(\d{3,4})',str(source.get('id','')))
        height=int(variant[1]) if variant else int(source['resolution'])
        link=parse_sources(body).get(height)
        if not link:raise ProviderError('Přehraj quality is no longer available. Refresh sources or check your account/subscription.')
        return {'url':link,'headers':{'Referer':BASE+source['page']},'mime':'video/mp4'}


def request_head(link,page):
    # Only the validated published CDN sources reach this function.
    from urllib.request import urlopen
    return urlopen(Request(link,method='HEAD',headers={'Referer':BASE+page,'User-Agent':'PersonalCinema/0.7.0'}),timeout=12)

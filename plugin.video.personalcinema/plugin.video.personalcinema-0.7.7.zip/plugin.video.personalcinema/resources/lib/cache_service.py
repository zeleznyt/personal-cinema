"""Kodi service coordinator for the optional, loopback-only disk cache."""
import json
import os
import re
import threading
import time
import uuid
from resources.lib.core import ProviderError
from resources.lib.diskcache import CacheServer, DiskFile
from resources.lib.runtime import store, storage, usage, limit

TRANSFER_LOCK=threading.Lock()


class CacheManager:
    def __init__(self):
        import xbmc,xbmcgui
        self.player=xbmc.Player();self.host=xbmcgui.Window(10000)
        self.host.clearProperty('personalcinema.cache.active')
        self.host.clearProperty('personalcinema.cache.base')
        self.server=None;self.active=None;self.file=None;self.held=False;self.played=False;self.promoted=False
        # Interrupted temporary caches are not complete saved downloads. Remove
        # only known job-owned paths, never unrelated files or preserved downloads.
        db=store()
        try:
            for row in db.db.execute('SELECT id,source FROM cache_jobs').fetchall():
                if not storage():continue
                path=self.path(row['id'],json.loads(row['source']))
                saved=db.db.execute('SELECT 1 FROM downloads WHERE path=?',(path,)).fetchone()
                if not saved and os.path.isfile(path):os.remove(path)
            db.execute('DELETE FROM cache_jobs')
        finally:db.db.close()

    def path(self,ident,source=None):
        if not re.fullmatch('[a-f0-9]{32}',ident):raise ProviderError('Invalid cache job identity.')
        if not storage():raise ProviderError('Choose a managed media folder first.')
        suffix=os.path.splitext((source or {}).get('name',''))[1].lower()
        if suffix not in ('.mp4','.mkv','.avi','.m4v','.webm','.mov','.ogv'):suffix='.bin'
        return os.path.join(storage(),'cache-'+ident+suffix)

    def release(self):
        if self.held:TRANSFER_LOCK.release();self.held=False

    def finish(self,db):
        if self.file:self.file.close(delete=not self.promoted)
        if self.server and self.active:self.server.files.pop(self.active['id'],None)
        if self.active:db.execute('DELETE FROM cache_jobs WHERE id=?',(self.active['id'],))
        self.file=None;self.active=None;self.played=False;self.promoted=False;self.release()
        self.host.clearProperty('personalcinema.cache.active')

    def tick(self):
        db=store()
        try:
            if self.active:
                row=db.db.execute('SELECT * FROM cache_jobs WHERE id=?',(self.active['id'],)).fetchone()
                playing=self.player.isPlayingVideo()
                path=self.player.getPlayingFile() if playing else ''
                this_video=playing and path.startswith(self.server.base+self.active['id'])
                if this_video:self.played=True
                if not row or row['state']=='cancelled' or self.played and not this_video or not self.played and time.time()-self.started>35:
                    self.finish(db)
                elif self.file.error:
                    db.execute("UPDATE cache_jobs SET state='failed',error=? WHERE id=?",(self.file.error,row['id']))
                elif self.file.complete:
                    db.execute("UPDATE cache_jobs SET state='complete',bytes=size WHERE id=?",(row['id'],))
                    self.release()
                    if row['keep'] and not self.promoted:
                        db.execute("INSERT OR IGNORE INTO downloads(title_key,source,path,state,bytes) VALUES (?,?,?,'complete',?)",
                                   (row['title_key'],row['source'],self.file.path,row['size']))
                        saved=db.db.execute('SELECT id FROM downloads WHERE path=?',(self.file.path,)).fetchone()
                        db.execute('INSERT OR REPLACE INTO download_info VALUES (?,?)',(saved['id'],row['data']))
                        self.promoted=True
            row=db.db.execute("SELECT * FROM cache_jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if not row or self.active:return
            if not TRANSFER_LOCK.acquire(False):
                db.execute("UPDATE cache_jobs SET state='failed',error=? WHERE id=?",('Another transfer is running. Pause it and retry disk buffering.',row['id']))
                return
            self.held=True
            file=None
            try:
                payload=self.host.getProperty('personalcinema.cache.request.'+row['id'])
                self.host.clearProperty('personalcinema.cache.request.'+row['id'])
                if not payload:raise ProviderError('Cache playback request expired. Start the stream again.')
                resolved=json.loads(payload)
                src=json.loads(row['source'])
                if src['provider'] not in ('webshare','archive','prehraj'):raise ProviderError('Disk buffering is not supported for this provider.')
                if row['size']<=0 or usage()+row['size']+1_000_000>limit():
                    raise ProviderError('The complete video would exceed the managed storage limit. Free space or choose a smaller source.')
                path=self.path(row['id'],src)
                last=[0]
                def progress(count):
                    if time.monotonic()-last[0]<1:return
                    last[0]=time.monotonic();connection=store()
                    try:connection.execute('UPDATE cache_jobs SET bytes=? WHERE id=?',(count,row['id']))
                    finally:connection.db.close()
                file=DiskFile(resolved['url'],path,row['size'],resolved.get('headers'),progress)
                file.block(0)
                state=db.db.execute('SELECT state FROM cache_jobs WHERE id=?',(row['id'],)).fetchone()
                if not state or state['state']!='queued':raise ProviderError('Disk buffering was cancelled.')
                if not self.server:
                    self.server=CacheServer(uuid.uuid4().hex)
                    self.host.setProperty('personalcinema.cache.base',self.server.base)
                self.server.files[row['id']]=file
                self.active=dict(row);self.file=file;self.started=time.time();self.played=False;self.promoted=False
                self.host.setProperty('personalcinema.cache.active',row['id'])
                db.execute("UPDATE cache_jobs SET state='ready' WHERE id=?",(row['id'],))
            except Exception as exc:
                if file:file.close()
                message=str(exc) if isinstance(exc,ProviderError) else 'Could not start disk buffering.'
                db.execute("UPDATE cache_jobs SET state='failed',error=? WHERE id=?",(message,row['id']))
                self.release()
        finally:db.db.close()

    def close(self):
        db=store()
        try:self.finish(db)
        finally:db.db.close()
        if self.server:self.server.close()
        self.host.clearProperty('personalcinema.cache.base')

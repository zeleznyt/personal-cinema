"""Inspect the configured distribution and hand updates to Kodi's add-on manager."""
import re
import xml.etree.ElementTree as ET
from resources.lib.core import ProviderError, request

BASE='https://zeleznyt.github.io/personal-cinema/'
REPOSITORY='repository.personalcinema'
ADDON_ID='plugin.video.personalcinema'


def version_tuple(value):
    if not re.fullmatch(r'\d+(?:\.\d+){1,3}',value):
        raise ProviderError('Update information is invalid.')
    return tuple(int(n) for n in value.split('.'))


def latest_version():
    try:
        with request(BASE+'addons.xml',timeout=12) as response:
            raw=response.read(256001)
        if len(raw)>256000:raise ValueError()
        root=ET.fromstring(raw)
        addon=next(n for n in root.findall('addon') if n.get('id')==ADDON_ID)
        version=addon.get('version','');version_tuple(version)
        return version
    except Exception:
        raise ProviderError('Could not check for updates. Try again later.') from None

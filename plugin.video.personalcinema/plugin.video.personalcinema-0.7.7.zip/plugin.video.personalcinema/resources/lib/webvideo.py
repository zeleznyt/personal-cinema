"""Public web-video extraction inside Personal Cinema; no other Kodi video add-on."""
import hashlib
import json
import os
import re
import subprocess
import tempfile
import time
from urllib.parse import urlencode, urljoin, urlparse
from resources.lib.core import ProviderError, normalize, request
from resources.lib.providers import candidate, json_request, youtube_id, check_cancelled, ProviderCancelled
from resources.lib.ct import attributes

# Reuse signed format data only during a two-minute playback window, between
# title lookup, the quality picker and immediate playback in this browser.
_INFO_CACHE = {}


def video_id(link):
    ident = youtube_id(link)
    if ident:
        return 'youtube', ident
    parsed = urlparse(link)
    host = (parsed.hostname or '').lower()
    if host in ('www.dailymotion.com', 'dailymotion.com'):
        match = re.fullmatch(r'/video/([A-Za-z0-9]+)(?:_[^/]*)?/?', parsed.path)
        if match:
            return 'dailymotion', match.group(1)
    if host == 'dai.ly' and re.fullmatch(r'/[A-Za-z0-9]+/?', parsed.path):
        return 'dailymotion', parsed.path.strip('/')
    raise ProviderError('Use a specific YouTube or Dailymotion video link.')


def page_url(provider, ident):
    pattern = r'[A-Za-z0-9_-]{11}' if provider == 'youtube' else r'[A-Za-z0-9]+'
    if not re.fullmatch(pattern, ident):
        raise ProviderError('Invalid video identifier.')
    return ('https://www.youtube.com/watch?v=' if provider == 'youtube' else
            'https://www.dailymotion.com/video/') + ident


class Extractor:
    def __init__(self, addon_root):
        self.root = os.path.join(addon_root, 'resources', 'bin', 'windows-x64')

    def extract(self, target, flat=False, cancelled=lambda: False):
        if os.name != 'nt':
            raise ProviderError('Built-in YouTube/Dailymotion extraction currently supports Windows x64. Android support is pending.')
        exe, js = os.path.join(self.root, 'yt-dlp.exe'), os.path.join(self.root, 'qjs.exe')
        if not os.path.isfile(exe) or not os.path.isfile(js):
            raise ProviderError('Bundled web-video helpers are missing. Reinstall this add-on ZIP.')
        args = [exe, '--ignore-config', '--compat-options', 'no-certifi', '--no-cache-dir', '--no-playlist',
                '--skip-download', '--dump-single-json', '--ignore-no-formats-error', '--no-warnings', '--socket-timeout', '8',
                '--retries', '0', '--extractor-retries', '0', '--js-runtimes', 'quickjs:' + js,
                '--extractor-args', 'youtube:skip=translated_subs']
        if flat:
            args += ['--flat-playlist', '--playlist-end', '8']
        args += ['--', target]
        # Temporary files avoid blocked pipes for large format lists. They are closed
        # immediately and never copied into the catalogue or application logs.
        with tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as errors:
            process = subprocess.Popen(args, stdout=output, stderr=errors, stdin=subprocess.DEVNULL,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            deadline = time.monotonic() + 35
            try:
                while process.poll() is None:
                    check_cancelled(cancelled)
                    if time.monotonic() > deadline:
                        raise ProviderError('Video metadata did not respond within 35 seconds. Nothing was played. Try another video or retry later.')
                    time.sleep(.1)
                if process.returncode:
                    errors.seek(0)
                    detail = errors.read(12000).decode('utf-8', errors='replace').lower()
                    if 'sign in' in detail or 'login' in detail or 'private' in detail:
                        raise ProviderError('This video requires sign-in or is restricted. This provider uses public videos without account cookies.')
                    if 'certificate' in detail:
                        raise ProviderError('The video provider certificate could not be verified using Windows trusted certificates.')
                    raise ProviderError('The public video could not be resolved. It may be removed, region-restricted, or the extractor may need an update.')
                output.seek(0)
                raw = output.read(8_000_001)
                if len(raw) > 8_000_000:
                    raise ProviderError('Web-video response exceeded its limit.')
                try:
                    return json.loads(raw)
                except ValueError:
                    raise ProviderError('Web-video helper returned an invalid response.') from None
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()


def full_title_match(title, names, year='', duration=0, season=None, episode=None):
    """Conservative automatic matches; native search can still browse all videos."""
    from resources.lib.discovery import episode_numbers, series_title_matches
    value = normalize(title)
    if re.search(r'\b(trailer|teaser|review|reaction|recap|scene|clip|sample)\b', value):
        return False
    if season is not None:
        return (episode_numbers(title) == (season, episode) and series_title_matches(title, names)
                and duration >= 300)
    if episode_numbers(title):
        return False
    years = re.findall(r'\b(?:19|20)\d{2}\b', value)
    if year and str(year) not in years:
        return False
    technical = {'full','official','movie','film','hd','fhd','1080p','720p','english','czech','cz','en'}
    for name in names:
        own = set(normalize(name).split())
        stripped = ' '.join(w for w in value.split()
                            if w in own or (w not in technical and not re.fullmatch(r'(?:19|20)\d{2}',w)))
        if stripped == normalize(name) and duration >= 2400:
            return True
    return False


def filtered_hls(text, base, height):
    """Keep one video variant and its audio group, retaining absolute media URLs."""
    if not text.lstrip().startswith('#EXTM3U'):
        raise ProviderError('Web-video provider did not return HLS.')
    if 'SAMPLE-AES' in text or re.search(r'KEYFORMAT="(?!identity)', text):
        raise ProviderError('This stream requires DRM playback and is unavailable here.')
    lines, variants, media, pending = text.splitlines(), [], [], None
    for line in lines:
        line = line.strip()
        if line.startswith('#EXT-X-MEDIA:'):
            media.append((line, attributes(line.split(':',1)[1])))
        elif line.startswith('#EXT-X-STREAM-INF:'):
            pending = (line, attributes(line.split(':',1)[1]))
        elif line and not line.startswith('#') and pending:
            attrs = pending[1]
            resolution = attrs.get('RESOLUTION', '').split('x')
            if len(resolution) == 2 and resolution[1].isdigit() and int(resolution[1]) == height:
                variants.append((pending[0], attrs, urljoin(base, line)))
            pending = None
    if not variants:
        raise ProviderError('This quality is no longer available; refresh sources.')
    selected = min(variants, key=lambda v: ('avc1' not in v[1].get('CODECS', ''),
                                          'mp4a.40.2' not in v[1].get('CODECS', ''),
                                          -int(v[1].get('BANDWIDTH') or 0)))
    out = ['#EXTM3U', '#EXT-X-VERSION:6']
    groups = {selected[1].get(k) for k in ('AUDIO', 'SUBTITLES', 'VIDEO') if selected[1].get(k)}
    for line, attrs in media:
        if attrs.get('GROUP-ID') in groups:
            if attrs.get('URI'):
                line = line.replace('URI="'+attrs['URI']+'"', 'URI="'+urljoin(base,attrs['URI'])+'"')
            out.append(line)
    out += [selected[0], selected[2]]
    return '\n'.join(out) + '\n'


class WebVideoProvider:
    def __init__(self, addon_root, provider='youtube', cache_root=''):
        self.extractor, self.id, self.cache_root = Extractor(addon_root), provider, cache_root

    def search(self, query, page=1, cancelled=lambda: False):
        if self.id == 'youtube':
            result = self.extractor.extract('ytsearch8:' + query, flat=True, cancelled=cancelled)
            rows = [{'id':v['id'], 'title':v.get('title') or v['id'], 'duration':v.get('duration') or 0,
                     'image':(v.get('thumbnails') or [{}])[-1].get('url'), 'uploader':v.get('channel') or v.get('uploader') or ''}
                    for v in result.get('entries', []) if v and youtube_id('https://youtu.be/'+str(v.get('id','')))]
            return rows, len(rows)
        params = {'search':query, 'fields':'id,title,duration,description,thumbnail_240_url,language',
                  'limit':20, 'page':page, 'sort':'relevance'}
        result = json_request('https://api.dailymotion.com/videos?' + urlencode(params))
        return [dict(v, image=v.get('thumbnail_240_url')) for v in result.get('list', [])], int(result.get('total', 0))

    def info(self, ident, cancelled=lambda: False):
        check_cancelled(cancelled)
        key = (os.path.normcase(self.extractor.root), self.id, ident)
        now = time.monotonic()
        cached = _INFO_CACHE.get(key)
        if cached and 0 <= now - cached[0] < 120:
            return cached[1]
        data = self.extractor.extract(page_url(self.id, ident), cancelled=cancelled)
        if not isinstance(data, dict):
            raise ProviderError('Web-video helper returned invalid video metadata.')
        _INFO_CACHE[key] = (time.monotonic(), data)
        while len(_INFO_CACHE) > 4:
            oldest = min(_INFO_CACHE, key=lambda k:_INFO_CACHE[k][0])
            del _INFO_CACHE[oldest]
        return data

    def sources(self, ident, cancelled=lambda: False):
        info = self.info(ident, cancelled)
        choices = {}
        for fmt in info.get('formats') or []:
            height = int(fmt.get('height') or 0)
            if not height or height > 1080 or fmt.get('has_drm') or fmt.get('vcodec') == 'none':
                continue
            hls = fmt.get('protocol') in ('m3u8', 'm3u8_native') and bool(fmt.get('manifest_url'))
            combined = fmt.get('acodec') not in ('none', None) and fmt.get('vcodec') not in ('none', None)
            if not hls and not combined:
                continue
            if not hls and not fmt.get('format_id'):
                continue
            selector = 'hls:%d' % height if hls else 'file:' + str(fmt['format_id'])
            # A quality is one user choice, even when the provider exposes several
            # codecs, frame rates and direct/HLS representations for that height.
            priority = (not combined, not str(fmt.get('vcodec','')).startswith(('avc1','h264')),
                        not hls, -float(fmt.get('tbr') or 0))
            if height in choices and choices[height][0] <= priority:
                continue
            source = candidate(self.id, ident+':'+selector, info.get('title') or ident,
                                     video_id=ident, selector=selector, resolution=height, quality=str(height)+'p',
                                     duration=info.get('duration') or 0,
                                     metadata='One format per video quality; provider audio/video format metadata')
            choices[height] = (priority, source)
        results = [pair[1] for pair in choices.values()]
        if not results:
            raise ProviderError('No public playable audio/video stream up to 1080p was returned.')
        return sorted(results, key=lambda s:s['resolution'], reverse=True)

    def find(self, data, names, cancelled=lambda: False):
        year = str(data.get('release_date') or '')[:4]
        query = names[0] + (' S%02dE%02d' % (data['season'],data['episode']) if data.get('season') is not None else ' '+year+' full movie')
        rows, _ = self.search(query, cancelled=cancelled)
        results = []
        for row in rows:
            check_cancelled(cancelled)
            if full_title_match(row['title'], names, year, row.get('duration') or 0, data.get('season'), data.get('episode')):
                results.extend(self.sources(row['id'], cancelled))
                break
        return results

    def resolve(self, source, cancelled=lambda: False):
        info = self.info(source['video_id'], cancelled)
        selector = source['selector']
        if selector.startswith('hls:'):
            height = int(selector.split(':')[1])
            formats = [f for f in (info.get('formats') or []) if f.get('height') == height and f.get('manifest_url')
                       and f.get('protocol') in ('m3u8','m3u8_native') and not f.get('has_drm')]
            if not formats:
                raise ProviderError('Video formats changed; refresh sources.')
            master = formats[0]['manifest_url']
            with request(master, headers=info.get('http_headers'), timeout=12) as response:
                raw = response.read(1_000_001)
            if len(raw) > 1_000_000:
                raise ProviderError('Web-video manifest exceeded its limit.')
            text = filtered_hls(raw.decode('utf-8-sig'), master, height)
            os.makedirs(self.cache_root, exist_ok=True)
            # Temporary signed manifests live outside the catalogue; replace on replay.
            target = os.path.join(self.cache_root, hashlib.sha256(source['id'].encode()).hexdigest()[:20]+'.m3u8')
            with open(target, 'w', encoding='utf8') as output:
                output.write(text)
            return {'url':target, 'mime':'application/vnd.apple.mpegurl', 'headers':info.get('http_headers', {})}
        fmt = next((f for f in (info.get('formats') or []) if 'file:'+str(f.get('format_id')) == selector), None)
        if not fmt or not fmt.get('url'):
            raise ProviderError('Video format changed; refresh sources.')
        return {'url':fmt['url'], 'headers':fmt.get('http_headers') or info.get('http_headers',{})}

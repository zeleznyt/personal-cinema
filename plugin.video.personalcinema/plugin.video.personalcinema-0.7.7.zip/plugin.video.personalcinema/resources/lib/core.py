"""Kodi-independent providers, source inspection and local catalogue."""
import hashlib
import json
import os
import re
import sqlite3
import time
import unicodedata
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen


class ProviderError(Exception):
    pass


def request(url, data=None, headers=None, timeout=25):
    h = {'User-Agent': 'PersonalCinema/0.6.2'}
    h.update(headers or {})
    try:
        return urlopen(Request(url, data=data, headers=h), timeout=timeout)
    except Exception as exc:
        # Do not include URLs, headers or credentials in errors.
        raise ProviderError('Network request failed (%s)' % type(exc).__name__) from None


def md5crypt(password, salt):
    """Portable Unix $1$ digest for Webshare, including Windows/Android."""
    salt = (salt[3:] if salt.startswith('$1$') else salt).split('$')[0][:8]
    p, s = password.encode('utf-8'), salt.encode('utf-8')
    ctx = hashlib.md5(p + b'$1$' + s)
    alt = hashlib.md5(p + s + p).digest()
    left = len(p)
    while left:
        ctx.update(alt[:min(16, left)])
        left -= min(16, left)
    n = len(p)
    while n:
        ctx.update(b'\0' if n & 1 else p[:1])
        n >>= 1
    digest = ctx.digest()
    for i in range(1000):
        c = hashlib.md5()
        c.update(p if i & 1 else digest)
        if i % 3:
            c.update(s)
        if i % 7:
            c.update(p)
        c.update(digest if i & 1 else p)
        digest = c.digest()
    alphabet = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    result = ''
    for a, b, c, count in [(0, 6, 12, 4), (1, 7, 13, 4), (2, 8, 14, 4),
                            (3, 9, 15, 4), (4, 10, 5, 4), (None, None, 11, 2)]:
        value = ((digest[a] << 16) | (digest[b] << 8) | digest[c]) if a is not None else digest[c]
        for _ in range(count):
            result += alphabet[value & 63]
            value >>= 6
    return '$1$%s$%s' % (salt, result)


class TMDB:
    def __init__(self, token, language='en-US'):
        self.token, self.language = token.strip(), language

    def get(self, path, **params):
        if not self.token:
            raise ProviderError('Enter a TMDB Read Access Token in Settings first.')
        params.setdefault('language', self.language)
        with request('https://api.themoviedb.org/3/' + path + '?' + urlencode(params),
                     headers={'Authorization': 'Bearer ' + self.token}) as response:
            return json.load(response)

    def search(self, query, page=1):
        return self.get('search/multi', query=query, include_adult='false', page=page)

    def catalogue_search(self, query, page=1):
        result = self.search(query, page)
        if page != 1:
            return result
        words = set(normalize(query).split()) - {'the', 'of', 'and', 'collection'}
        if not words:
            return result
        collections = self.get('search/collection', query=query, include_adult='false').get('results', [])
        matching = [c for c in collections if len(words & set(normalize(c.get('name', '')).split())) / len(words) >= .8]
        if matching:
            best = min(matching, key=lambda c: len(set(normalize(c.get('name', '')).split()) - words - {'collection', 'the', 'of', 'and'}))
            parts = self.get('collection/%s' % best['id']).get('parts', [])
            parts.sort(key=lambda p: p.get('release_date') or '9999')
            result['results'].extend(dict(p, media_type='movie', _collection_match=True, _collection_order=i)
                                     for i, p in enumerate(parts))
        return result

    def title_names(self, kind, ident):
        """Verified English, Czech and Slovak titles for the same metadata identity."""
        names = []
        for language in ('en-US', 'cs-CZ', 'sk-SK'):
            details = self.get('%s/%s' % (kind, ident), language=language)
            for key in ('title', 'original_title', 'name', 'original_name'):
                if details.get(key) and details[key] not in names:
                    names.append(details[key])
        alternatives = self.get('%s/%s/alternative_titles' % (kind, ident))
        for value in alternatives.get('titles', alternatives.get('results', [])):
            if value.get('iso_3166_1') in ('CZ', 'SK', 'US', 'GB') and value.get('title') not in names:
                names.append(value['title'])
        return names


class Webshare:
    def __init__(self, user='', password=''):
        self.user, self.password, self.token = user, password, ''

    def api(self, method, **params):
        if self.token:
            params['wst'] = self.token
        with request('https://webshare.cz/api/%s/' % method,
                     urlencode(params).encode('utf-8'),
                     {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}) as response:
            root = ET.fromstring(response.read())
        if root.findtext('status') != 'OK':
            raise ProviderError('Webshare: ' + (root.findtext('code') or 'request failed'))
        return root

    def login(self):
        if not self.user or not self.password:
            raise ProviderError('Enter Webshare credentials in Settings first.')
        salt = self.api('salt', username_or_email=self.user).findtext('salt')
        digest = hashlib.sha1(md5crypt(self.password, salt).encode('utf-8')).hexdigest()
        self.token = self.api('login', username_or_email=self.user,
                              password=digest, keep_logged_in=0).findtext('token')
        if not self.token:
            raise ProviderError('Webshare did not return a session token.')

    def search(self, query, offset=0):
        # Some video files are not correctly categorised by the host. Filter extensions locally.
        root = self.api('search', what=query, limit=50, offset=offset)
        return [{'id': f.findtext('ident'), 'name': f.findtext('name') or '',
                 'size': int(f.findtext('size') or 0), 'provider': 'webshare'}
                for f in root.findall('file') if f.findtext('ident')], int(root.findtext('total') or 0)

    def resolve(self, ident, download=False):
        if not self.token:
            self.login()
        link = self.api('file_link', ident=ident, force_https=1,
                        download_type='file_download' if download else 'video_stream',
                        device_vendor='PersonalCinema', device_model='Kodi').findtext('link')
        if not link or urlparse(link).scheme != 'https':
            raise ProviderError('Webshare did not return an HTTPS media link.')
        return link


def normalize(text):
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', ' ', text).strip()


def inspect_source(source, title, year='', season=None, episode=None):
    name = source['name']
    normalized = normalize(name)
    words = normalize(title).split()
    match = sum(w in normalized.split() for w in words) / max(len(words), 1)
    years = re.findall(r'\b(?:19|20)\d{2}\b', name)
    if year and years and str(year) not in years:
        match *= .35
    episode_match = re.search(r'(?:s(\d{1,2})[ ._-]*e(\d{1,3})|\b(\d{1,2})x(\d{2,3})\b)', name, re.I)
    if season is not None:
        if not episode_match:
            match *= .2
        else:
            groups = episode_match.groups()
            actual = (int(groups[0] or groups[2]), int(groups[1] or groups[3]))
            if actual != (season, episode):
                match = 0
    elif episode_match:
        match *= .1
    quality = re.search(r'(?<!\d)(2160|1080|720|576|480)[pi]?(?!\d)', name, re.I)
    languages = []
    for code, pattern in [('EN', r'\b(eng|english|en)\b'), ('CZ', r'\b(cz|cs|cze|ces|czech)\b')]:
        if re.search(pattern, normalized):
            languages.append(code)
    return dict(source, quality=quality.group(1) + 'p' if quality else 'Unknown quality',
                languages=', '.join(languages) or 'Unknown', confidence=round(match, 2),
                metadata='Filename inference; audio tracks not verified')


class Store:
    def __init__(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.db = sqlite3.connect(path, timeout=20)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
          PRAGMA journal_mode=WAL;
          CREATE TABLE IF NOT EXISTS titles (key TEXT PRIMARY KEY, data TEXT, updated REAL);
          CREATE TABLE IF NOT EXISTS sources (title_key TEXT, provider TEXT, ident TEXT, data TEXT,
            checked REAL, PRIMARY KEY(title_key,provider,ident));
          CREATE TABLE IF NOT EXISTS checks (id INTEGER PRIMARY KEY, title_key TEXT, provider TEXT,
            query TEXT, outcome TEXT, count INTEGER, checked REAL);
          CREATE TABLE IF NOT EXISTS downloads (id INTEGER PRIMARY KEY, title_key TEXT, source TEXT,
            path TEXT UNIQUE, state TEXT, bytes INTEGER DEFAULT 0, error TEXT DEFAULT '');
          CREATE TABLE IF NOT EXISTS progress (title_key TEXT PRIMARY KEY, position REAL,
            duration REAL, updated REAL);
          CREATE TABLE IF NOT EXISTS selected_subtitles (title_key TEXT PRIMARY KEY, path TEXT);
          CREATE TABLE IF NOT EXISTS media_subtitles (media_key TEXT PRIMARY KEY, title_key TEXT, path TEXT);
          CREATE TABLE IF NOT EXISTS playback_events (id INTEGER PRIMARY KEY, title_key TEXT, media_key TEXT,
            provider TEXT, status TEXT, detail TEXT, created REAL);
          CREATE TABLE IF NOT EXISTS search_history (query_key TEXT PRIMARY KEY, query TEXT,
            updated REAL, uses INTEGER NOT NULL DEFAULT 1);
          CREATE TABLE IF NOT EXISTS source_matches (title_key TEXT, provider TEXT, ident TEXT,
            data TEXT, confirmed REAL, PRIMARY KEY(title_key,provider,ident));
          CREATE TABLE IF NOT EXISTS provider_search_history (provider TEXT, query_key TEXT, query TEXT,
            updated REAL, PRIMARY KEY(provider,query_key));
          CREATE TABLE IF NOT EXISTS availability (title_key TEXT, provider TEXT, region TEXT,
            data TEXT, checked REAL, PRIMARY KEY(title_key,provider,region));
          CREATE TABLE IF NOT EXISTS download_info (download_id INTEGER PRIMARY KEY, data TEXT);
          INSERT OR IGNORE INTO download_info SELECT downloads.id,titles.data FROM downloads
            JOIN titles ON titles.key=downloads.title_key;
          CREATE TABLE IF NOT EXISTS cache_jobs (id TEXT PRIMARY KEY, title_key TEXT, source TEXT,
            data TEXT, size INTEGER, state TEXT, bytes INTEGER DEFAULT 0, error TEXT DEFAULT '',
            keep INTEGER DEFAULT 0, created REAL);
        ''')
        self.db.commit()

    def execute(self, sql, args=()):
        cursor = self.db.execute(sql, args)
        self.db.commit()
        return cursor

    def title(self, key, data=None):
        if data is not None:
            existing = self.title(key)
            if existing and existing.get('source_names') and 'source_names' not in data:
                data = dict(data, source_names=existing['source_names'], aliases_version=existing.get('aliases_version', 0))
            if existing and existing.get('match_names') and 'match_names' not in data:
                data = dict(data, match_names=existing['match_names'], match_names_version=existing.get('match_names_version', 0))
            self.execute('INSERT OR REPLACE INTO titles VALUES (?,?,?)', (key, json.dumps(data), time.time()))
            return data
        row = self.db.execute('SELECT data FROM titles WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def remember_search(self, query, provider='tmdb'):
        query = query.strip()
        if not query:
            return
        key = normalize(query)
        if provider != 'tmdb':
            self.execute('INSERT OR REPLACE INTO provider_search_history VALUES (?,?,?,?)',
                         (provider, key, query, time.time()))
            self.execute('DELETE FROM provider_search_history WHERE rowid NOT IN '
                         '(SELECT rowid FROM provider_search_history ORDER BY updated DESC LIMIT 100)')
            return
        with self.db:
            row = self.db.execute('SELECT uses FROM search_history WHERE query_key=?', (key,)).fetchone()
            latest = self.db.execute('SELECT MAX(updated) FROM search_history').fetchone()[0] or 0
            # Windows clocks may return the same timestamp for successive confirmed searches.
            updated = max(time.time(), latest + .000001)
            self.db.execute('INSERT OR REPLACE INTO search_history VALUES (?,?,?,?)',
                            (key, query, updated, row[0] + 1 if row else 1))
            self.db.execute('DELETE FROM search_history WHERE query_key NOT IN (SELECT query_key FROM search_history ORDER BY updated DESC LIMIT 100)')

    def record_check(self, key, query, sources, outcome='ok', provider='webshare'):
        now = time.time()
        if any(source['provider'] != provider for source in sources):
            raise ValueError('Source snapshot contains a different provider.')
        with self.db:
            if outcome == 'ok':
                previous = {row['ident']: json.loads(row['data']) for row in self.db.execute(
                    'SELECT ident,data FROM sources WHERE title_key=? AND provider=?', (key, provider))}
                # Replace current snapshot, retaining checks as an append-only history.
                self.db.execute('DELETE FROM sources WHERE title_key=? AND provider=?', (key, provider))
                for src in sources:
                    for field in ('observed_audio', 'observed_subtitles', 'tracks_checked'):
                        if field in previous.get(src['id'], {}):
                            src[field] = previous[src['id']][field]
                    self.db.execute('INSERT OR REPLACE INTO sources VALUES (?,?,?,?,?)',
                                    (key, src['provider'], src['id'], json.dumps(src), now))
            self.db.execute('INSERT INTO checks(title_key,provider,query,outcome,count,checked) VALUES (?,?,?,?,?,?)',
                            (key, provider, query, outcome, len(sources), now))

    def pin_source(self, key, source):
        self.execute('INSERT OR REPLACE INTO source_matches VALUES (?,?,?,?,?)',
                     (key, source['provider'], source['id'], json.dumps(source), time.time()))

    def pinned_sources(self, key):
        return [json.loads(row[0]) for row in self.db.execute(
            'SELECT data FROM source_matches WHERE title_key=? ORDER BY confirmed DESC', (key,))]

    def export(self, path):
        # Secrets, signed URLs and provider credentials never enter this database.
        tables = ['titles', 'sources', 'checks', 'downloads', 'progress', 'selected_subtitles', 'media_subtitles', 'playback_events', 'search_history', 'source_matches', 'provider_search_history', 'availability']
        data = {table: [dict(row) for row in self.db.execute('SELECT * FROM ' + table)] for table in tables}
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def folder_bytes(root):
    return sum(os.path.getsize(os.path.join(base, name)) for base, _, names in os.walk(root)
               for name in names if os.path.isfile(os.path.join(base, name)))


def download_file(url, target, root, limit, cancelled=lambda: False, progress=lambda n: None, used_bytes=None, headers=None):
    """Single-worker streaming download; preserves partial files for range resume."""
    part = target + '.part'
    if os.path.exists(target):
        raise ProviderError('Destination already exists.')
    used = folder_bytes(root) if used_bytes is None else used_bytes
    offset = os.path.getsize(part) if os.path.exists(part) else 0
    headers = dict(headers or {})
    if offset:headers['Range']='bytes=%d-' % offset
    with request(url, headers=headers) as response:
        status = response.getcode()
        if offset:
            content_range = response.headers.get('Content-Range', '')
            if status != 206 or not content_range.startswith('bytes %d-' % offset):
                raise ProviderError('Server cannot resume this partial download; use a new destination.')
        remaining = response.headers.get('Content-Length')
        if remaining and used + int(remaining) > limit:
            raise ProviderError('Download would exceed the managed storage limit.')
        with open(part, 'ab' if offset else 'wb') as f:
            count = 0
            while True:
                if cancelled():
                    raise ProviderError('Download paused.')
                try:
                    chunk = response.read(64 * 1024)
                except OSError:
                    raise ProviderError('Connection interrupted; partial download kept. Queue again to resume.') from None
                if not chunk:
                    break
                if used + len(chunk) > limit:
                    raise ProviderError('Managed storage limit reached.')
                f.write(chunk)
                used += len(chunk)
                count += len(chunk)
                progress(offset + count)
            if remaining and count != int(remaining):
                raise ProviderError('Incomplete transfer; partial file kept for resume.')
    os.replace(part, target)
    return os.path.getsize(target)

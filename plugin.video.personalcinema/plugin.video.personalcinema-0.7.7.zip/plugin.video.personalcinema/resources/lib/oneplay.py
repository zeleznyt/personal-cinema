"""Oneplay bridge: provider-owned account/DRM handling, Personal Cinema navigation."""
import json
from urllib.parse import urlencode, urlparse
from resources.lib.core import ProviderError

ADDON_ID='plugin.video.oneplay'
BASE='plugin://'+ADDON_ID+'/'


def route(action='',**params):
    return BASE+('?' + urlencode(dict(params,action=action)) if action else '')


def checked(link):
    parsed=urlparse(link)
    if parsed.scheme!='plugin' or parsed.netloc!=ADDON_ID or parsed.path not in ('','/') or parsed.fragment:
        raise ProviderError('Unsupported Oneplay navigation link.')
    return link


def directory(link):
    import xbmc
    checked(link)
    request={'jsonrpc':'2.0','id':1,'method':'Files.GetDirectory',
             'params':{'directory':link,'media':'video','properties':['title','plot','thumbnail','year','season','episode']}}
    result=json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if result.get('error'):
        raise ProviderError('Oneplay catalogue could not be opened. Check its login, selected profile and subscription in Oneplay settings.')
    return result.get('result',{}).get('files',[])

"""Local download worker, observer and opt-in loopback disk buffering."""
import json
import os
import time
import xbmc
import xbmcgui
from resources.lib.core import download_file
from resources.lib.runtime import store, webshare, storage, storage_base, usage, limit, setting
from resources.lib.media import within
from resources.lib.providers import resolve_candidate
from resources.lib.cache_service import CacheManager, TRANSFER_LOCK


def language_matches(actual, wanted):
    groups = [{'eng', 'en', 'english'}, {'ces', 'cze', 'cs', 'cz', 'czech'}]
    actual, wanted = actual.lower(), wanted.lower()
    return actual == wanted or any(actual in group and wanted in group for group in groups)


def rpc(method, params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1,
                                                      'method': method, 'params': params})))
    return result.get('result', {})


class Observer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.key, self.position, self.duration = '', 0, 0
        self.info = {}

    def event(self, info, status, detail=''):
        db = store()
        try:
            db.execute('INSERT INTO playback_events(title_key,media_key,provider,status,detail,created) VALUES (?,?,?,?,?,?)',
                       (info.get('title_key', ''), info.get('key', ''), info.get('provider', ''), status, detail, time.time()))
        finally:
            db.db.close()

    def onPlayBackError(self):
        window = xbmcgui.Window(10000)
        pending = window.getProperty('personalcinema.pending')
        info = json.loads(pending) if pending else self.info
        if info:
            self.event(info, 'failed', 'Kodi could not open or decode the stream.')
        window.clearProperty('personalcinema.pending')

    def onPlayBackStopped(self):
        if self.info:
            self.event(self.info, 'stopped')
        self.key, self.info = '', {}
        xbmcgui.Window(10000).clearProperty('personalcinema.active')

    def onPlayBackEnded(self):
        if self.info:
            self.event(self.info, 'ended')
        self.key, self.info = '', {}
        xbmcgui.Window(10000).clearProperty('personalcinema.active')

    def onAVStarted(self):
        self.key = ''
        self.position = self.duration = 0
        window = xbmcgui.Window(10000)
        window.clearProperty('personalcinema.active')
        pending = window.getProperty('personalcinema.pending')
        window.clearProperty('personalcinema.pending')
        if not pending:
            return
        try:
            info = json.loads(pending)
            if self.getPlayingFile() != info['path']:
                return
            self.key = info['key']
            self.info = info
            window.setProperty('personalcinema.active', json.dumps(info))
            self.event(info, 'started')
            props = rpc('Player.GetProperties', {'playerid': 1, 'properties': ['audiostreams', 'subtitles']})
            # Only actual opened tracks are promoted from hints to verified metadata.
            if info.get('provider') and info.get('source_id'):
                db = store()
                try:
                    row = db.db.execute('SELECT data FROM sources WHERE title_key=? AND provider=? AND ident=?',
                                        (info['title_key'], info['provider'], info['source_id'])).fetchone()
                    if row:
                        source = json.loads(row[0])
                        source['observed_audio'] = props.get('audiostreams', [])
                        source['observed_subtitles'] = props.get('subtitles', [])
                        source['tracks_checked'] = time.time()
                        db.execute('UPDATE sources SET data=? WHERE title_key=? AND provider=? AND ident=?',
                                   (json.dumps(source), info['title_key'], info['provider'], info['source_id']))
                finally:
                    db.db.close()
            for streams, method, param, primary, secondary in [
                ('audiostreams', 'Player.SetAudioStream', 'stream', 'audio_primary', 'audio_secondary'),
                ('subtitles', 'Player.SetSubtitle', 'subtitle', 'subtitle_primary', 'subtitle_secondary')]:
                selected = None
                for preference in [setting(primary), setting(secondary)]:
                    if not preference:
                        continue
                    selected = next((s for s in props.get(streams, []) if language_matches(s.get('language', ''), preference)), None)
                    if selected:
                        break
                if selected:
                    params = {'playerid': 1, param: selected['index']}
                    if streams == 'subtitles':
                        params['enable'] = setting('subtitles') == 'true'
                    rpc(method, params)
            if setting('subtitles') != 'true':
                self.showSubtitles(False)
            external = info.get('subtitle')
            if external and os.path.isfile(external):
                self.setSubtitles(external)
                self.showSubtitles(True)
        except Exception:
            xbmc.log('PersonalCinema: playback preferences could not be applied', xbmc.LOGWARNING)


def run():
    monitor, player = xbmc.Monitor(), Observer()
    db = store()
    db.execute('DELETE FROM titles WHERE updated < ? AND key NOT IN (SELECT title_key FROM source_matches) AND key NOT IN (SELECT title_key FROM downloads)', (time.time() - 180 * 86400,))
    cache = CacheManager()
    last_sample = 0
    while not monitor.abortRequested():
        try:
            cache.tick()
            if player.key and player.isPlayingVideo() and time.time() - last_sample > 5:
                player.position, player.duration = player.getTime(), player.getTotalTime()
                db.execute('INSERT OR REPLACE INTO progress VALUES (?,?,?,?)',
                           (player.key, player.position, player.duration, time.time()))
                last_sample = time.time()
            # Keep playback observation responsive: downloads run in a dedicated worker below.
        except Exception:
            xbmc.log('PersonalCinema: playback progress update failed', xbmc.LOGWARNING)
        if monitor.waitForAbort(1):
            break
    cache.close()
    db.db.close()


def download_worker():
    monitor = xbmc.Monitor()
    db = store()
    while not monitor.abortRequested():
        for deleting in db.db.execute("SELECT * FROM downloads WHERE state='deleting'").fetchall():
            if storage() and within(deleting['path'],storage()):
                try:
                    for path in (deleting['path'],deleting['path']+'.part'):
                        if os.path.isfile(path):os.remove(path)
                    db.execute('DELETE FROM download_info WHERE download_id=?',(deleting['id'],))
                    db.execute('DELETE FROM downloads WHERE id=?',(deleting['id'],))
                except OSError:pass
            else:db.execute("UPDATE downloads SET state='paused',error=? WHERE id=?",('Removal blocked: file is outside managed storage.',deleting['id']))
        row = db.db.execute("SELECT * FROM downloads WHERE state='queued' ORDER BY id LIMIT 1").fetchone()
        if row:
            if not TRANSFER_LOCK.acquire(False):
                monitor.waitForAbort(1)
                continue
            try:
                root = storage()
                # A settings change must never redirect existing jobs outside the managed folder.
                if not root or not within(row['path'], storage_base()):
                    raise ValueError('Download path is outside the current media folder.')
                os.makedirs(os.path.dirname(row['path']), exist_ok=True)
                db.execute("UPDATE downloads SET state='downloading',error='' WHERE id=? AND state='queued'", (row['id'],))
                src = json.loads(row['source'])
                headers = {}
                if src['provider'] == 'webshare':
                    link = webshare().resolve(src['id'], download=True)
                elif src['provider'] == 'archive':
                    link = resolve_candidate(src)['url']
                elif src['provider'] == 'prehraj':
                    from resources.lib.runtime import prehraj
                    resolved=prehraj().resolve(src)
                    link=resolved['url'];headers=resolved.get('headers',{})
                else:
                    raise ValueError('Offline saving is unavailable for this provider.')
                last_update = [0]

                def cancelled():
                    state = db.db.execute('SELECT state FROM downloads WHERE id=?', (row['id'],)).fetchone()
                    return monitor.abortRequested() or state[0] != 'downloading'

                def update(count):
                    if time.time() - last_update[0] > 1:
                        db.execute('UPDATE downloads SET bytes=? WHERE id=?', (count, row['id']))
                        last_update[0] = time.time()

                count = download_file(link, row['path'], root, limit(), cancelled, update, used_bytes=usage(), headers=headers)
                db.execute("UPDATE downloads SET state='complete',bytes=?,error='' WHERE id=? AND state='downloading'", (count, row['id']))
                xbmcgui.Dialog().notification('Personal Cinema', 'Download complete')
            except Exception as exc:
                part = row['path'] + '.part'
                count = os.path.getsize(part) if os.path.exists(part) else 0
                # Only predefined application error messages, never transport URLs/tokens.
                from resources.lib.core import ProviderError
                message = str(exc) if isinstance(exc, (ProviderError, ValueError)) else type(exc).__name__
                db.execute("UPDATE downloads SET state='paused',bytes=?,error=? WHERE id=? AND state!='deleting'", (count, message, row['id']))
            finally:
                TRANSFER_LOCK.release()
        if monitor.waitForAbort(2):
            break
    db.db.close()


if __name__ == '__main__':
    import threading
    # Recover interrupted rows before starting worker, avoiding startup races.
    recovery = store()
    recovery.execute("UPDATE downloads SET state='queued' WHERE state='downloading'")
    recovery.db.close()
    worker = threading.Thread(target=download_worker, daemon=True)
    worker.start()
    run()
    worker.join(timeout=30)

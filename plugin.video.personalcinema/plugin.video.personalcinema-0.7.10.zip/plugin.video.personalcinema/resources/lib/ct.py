"""ČT on-demand catalogue and clear HLS playback, independent of Kodi and accounts."""
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, urljoin
from resources.lib.core import ProviderError, request, normalize
from resources.lib.providers import json_request, candidate, check_cancelled

GRAPHQL = 'https://api.ceskatelevize.cz/graphql/?client=iVysilaniWeb&version=1.131.1&use-new-playability=true'
PLAYLIST = 'https://api.ceskatelevize.cz/video/v1/playlist-vod/v1/stream-data/media/external/'
LANGUAGES = {'cs': 'CZ', 'ces': 'CZ', 'cze': 'CZ', 'en': 'EN', 'eng': 'EN', 'sk': 'SK', 'slk': 'SK'}


def episodic_show(show):
    # ČT's weekly programmes have no seasons and use "magazine", not "series".
    return show.get('showType') in ('series', 'magazine') or bool(show.get('seasons'))


def text_request(url):
    with request(url, timeout=12) as response:
        raw = response.read(1_000_001)
    if len(raw) > 1_000_000:
        raise ProviderError('ČT manifest is too large.')
    return raw.decode('utf-8-sig')


def attributes(line):
    return {m.group(1): (m.group(2) if m.group(2) is not None else m.group(3))
            for m in re.finditer(r'([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))', line)}


def hls_variants(text, base):
    if not text.lstrip().startswith('#EXTM3U'):
        raise ProviderError('ČT did not return an HLS playlist.')
    if re.search(r'METHOD=(?:SAMPLE-AES|SAMPLE-AES-CTR)|KEYFORMAT="(?!identity)', text):
        raise ProviderError('This ČT stream requires DRM playback. Open its official page instead.')
    variants, pending, audio = [], None, {}
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-MEDIA:'):
            attr = attributes(line.split(':', 1)[1])
            if attr.get('TYPE') == 'AUDIO':
                audio.setdefault(attr.get('GROUP-ID', ''), []).append(attr)
        elif line.startswith('#EXT-X-STREAM-INF:'):
            pending = attributes(line.split(':', 1)[1])
        elif line and not line.startswith('#') and pending is not None:
            res = pending.get('RESOLUTION', '').split('x')
            height = int(res[-1]) if len(res) == 2 and res[-1].isdigit() else 0
            variants.append({'url': urljoin(base, line), 'group': pending.get('AUDIO', ''),
                             'bandwidth': int(pending.get('BANDWIDTH') or 0), 'resolution': height})
            pending = None
    # A separate audio URI must remain attached through the master playlist.
    if any(a.get('URI') for group in audio.values() for a in group):
        return [{'url': base, 'group': 'adaptive', 'bandwidth': 0, 'resolution': 0}], audio
    return variants or [{'url': base, 'group': 'adaptive', 'bandwidth': 0, 'resolution': 0}], audio


class CTProvider:
    id = 'ct'

    def graphql(self, query, variables):
        response = json_request(GRAPHQL, {'query': query, 'variables': variables})
        if response.get('errors') or not isinstance(response.get('data'), dict):
            raise ProviderError('ČT catalogue request failed. Try again later.')
        return next(iter(response['data'].values()))

    def search(self, query, page=1):
        result = self.graphql('query($keyword:String!,$limit:PaginationAmount!,$offset:Int!,$onlyPlayable:Boolean!){'
                              'searchShowsAsYouType(keyword:$keyword,limit:$limit,offset:$offset,onlyPlayable:$onlyPlayable)'
                              '{totalCount items{id sidp title previewImage playable}}}',
                              {'keyword': query, 'limit': 20, 'offset': (page-1)*20, 'onlyPlayable': True})
        return result.get('items', []), int(result.get('totalCount', 0))

    def show(self, ident):
        result = self.graphql('query($id:String!){show(id:$id){id idec title showType shortDescription year '
                              'images{card} isPlayable playableIdec seasons{id title}}}', {'id': str(ident)})
        if not result:
            raise ProviderError('This ČT programme is unavailable.')
        return result

    def categories(self):
        rows = self.graphql('{menuOnlyCategories(deviceType:"website"){categoryId title}}', {}) or []
        # The menu returns categoryId as an array; the category query takes one ID.
        return [dict(row, categoryId=row['categoryId'][0] if isinstance(row['categoryId'], list) else row['categoryId'])
                for row in rows if row.get('categoryId')]

    def category(self, ident, page=1):
        result = self.graphql('query($id:String!,$limit:PaginationAmount!,$offset:Int!){category(categoryId:$id){'
                              'programmeFind(limit:$limit,offset:$offset){totalCount items{id title showType '
                              'shortDescription year images{card} isPlayable}}}}',
                              {'id': ident, 'limit': 20, 'offset': (page-1)*20})
        if not result or not result.get('programmeFind'):
            raise ProviderError('ČT category is unavailable.')
        page = result['programmeFind']
        return page.get('items', []), int(page.get('totalCount', 0))

    def episodes(self, idec, season='', page=1, order='oldest', keyword=''):
        if order not in ('oldest', 'newest'):
            raise ValueError('Invalid ČT episode order')
        result = self.graphql('query($idec:String!,$seasonId:String,$limit:PaginationAmount!,$offset:Int!,'
                              '$orderBy:EpisodeOrderByType!,$onlyPlayable:Boolean,$keyword:String){'
                              'episodesPreviewFind(idec:$idec,seasonId:$seasonId,limit:$limit,offset:$offset,'
                              'orderBy:$orderBy,onlyPlayable:$onlyPlayable,keyword:$keyword){totalCount items{id title description duration '
                              'playable season{id title} images{card} showId showTitle}}}',
                              {'idec': str(idec), 'seasonId': season or None, 'limit': 30, 'offset': (page-1)*30,
                               'orderBy': order, 'onlyPlayable': True, 'keyword': keyword or None})
        return result.get('items', []), int(result.get('totalCount', 0))

    def playlist(self, idec, kind='hls'):
        if not re.fullmatch(r'\d+', str(idec)):
            raise ProviderError('Invalid ČT episode identifier.')
        data = json_request(PLAYLIST + str(idec) + '?' + urlencode(
            {'canPlayDrm': 'false', 'quality': 'web', 'streamType': kind, 'origin': 'ivysilani', 'usePlayability': 'true'}))
        if data.get('platformChannel'):
            raise ProviderError('This is a live-only ČT item; this library supports on-demand programmes.')
        if not data.get('streams'):
            raise ProviderError('ČT cannot play this item here now (availability window, region or playback restriction).')
        return data

    def _variants(self, idec):
        data = self.playlist(idec)
        stream = data['streams'][0]
        manifest = stream.get('url')
        if not manifest:
            raise ProviderError('ČT did not provide a stream.')
        variants, audio = hls_variants(text_request(manifest), manifest)
        # ČT HLS sometimes omits RESOLUTION. Its matching DASH representation IDs
        # provide the exact height; never infer a height from bitrate or list order.
        if any(not variant['resolution'] and variant['group'].isdigit() for variant in variants):
            try:
                dash = self.playlist(idec, 'dash')['streams'][0]['url']
                tree = ET.fromstring(text_request(dash))
                heights = {}
                for node in tree.iter():
                    if node.tag.split('}')[-1] == 'Representation' and node.get('height'):
                        heights[node.get('id', '').split('-')[-1]] = int(node.get('height'))
                for variant in variants:
                    variant['resolution'] = variant['resolution'] or heights.get(variant['group'], 0)
            except (ProviderError, ValueError, KeyError, ET.ParseError):
                pass
        langs = list(dict.fromkeys(LANGUAGES.get(t.get('language', ''), t.get('language', '').upper())
                                   for t in stream.get('audioTracks', []) if t.get('language')))
        subtitles = []
        for language in stream.get('subtitles', []):
            files = {file.get('format'): file.get('url') for file in language.get('files', [])}
            link = files.get('vtt') or files.get('srt')
            if link and link.startswith('https://'):
                subtitles.append(link)
        return data, variants, ', '.join(langs) or 'Unknown', subtitles

    def sources(self, idec):
        data, variants, languages, _ = self._variants(idec)
        results = []
        for variant in variants:
            height = variant['resolution']
            selector = variant['group'] or str(variant['bandwidth'])
            results.append(candidate('ct', str(idec)+':'+selector,
                                     data.get('episodeTitle') or data.get('title') or 'ČT programme',
                                     ct_idec=str(idec), selector=selector, resolution=height,
                                     quality=str(height)+'p' if height else 'Adaptive / unknown resolution',
                                     languages=languages, language_verified=languages != 'Unknown',
                                     metadata='ČT audio metadata and stream manifest; size unknown',
                                     bandwidth=variant['bandwidth'], duration=data.get('duration', 0)))
        return sorted(results, key=lambda s: ({1080:4,720:3,576:2,404:1,288:0}.get(s['resolution'], -1)), reverse=True)

    def find(self, data, names, cancelled=lambda: False):
        episodic = data.get('season') is not None
        episode_names = {normalize(n) for n in data.get('episode_match_names', [data.get('episode_name', '')])
                         if n and not re.fullmatch(r'(?:episode|epizoda|dil)\s*\d+|\d+', normalize(n))}
        if episodic and not episode_names:
            return []
        year = str((data.get('first_air_date') if episodic else data.get('release_date')) or '')[:4]
        for query in names[:3]:
            check_cancelled(cancelled)
            shows, _ = self.search(query)
            for show in shows:
                check_cancelled(cancelled)
                if normalize(show['title']) not in {normalize(n) for n in names}:
                    continue
                details = self.show(show['id'])
                if episodic:
                    if year and details.get('year') and str(details['year'])[:4] != year:
                        continue
                    episodes, total = self.episodes(details['idec'])
                    if total > 180:
                        continue  # Do not claim uniqueness across an incomplete programme list.
                    for page in range(2, (total+29)//30 + 1):
                        check_cancelled(cancelled)
                        batch, _ = self.episodes(details['idec'], page=page)
                        episodes.extend(batch)
                    matches = []
                    for ep in episodes:
                        # ČT often prefixes a title with its explicit part count, e.g. 1/5.
                        ordinal = re.match(r'^\s*(\d+)\s*/\s*\d+\s*', ep['title'])
                        title = ep['title'][ordinal.end():] if ordinal else ep['title']
                        if normalize(title) in episode_names:
                            matches.append((ep, int(ordinal.group(1)) if ordinal else None))
                    if len(matches) != 1 or (matches[0][1] is not None and matches[0][1] != data['episode']):
                        continue
                    results = self.sources(matches[0][0]['id'])
                    for source in results:
                        source.update(name=matches[0][0]['title'], episode_match=True,
                                      detected_season=data['season'], detected_episode=data['episode'],
                                      metadata='Exact ČT programme identity and unique translated episode-title match; provider audio/manifest metadata')
                    return results
                if episodic_show(details) or (year and str(details.get('year') or '')[:4] != year):
                    continue
                if details.get('isPlayable') and (details.get('playableIdec') or details.get('idec')):
                    return self.sources(details.get('playableIdec') or details['idec'])
        return []

    def resolve(self, source):
        data, variants, _, subtitles = self._variants(source['ct_idec'])
        for variant in variants:
            if (variant['group'] or str(variant['bandwidth'])) == source['selector']:
                # Encryption declarations may occur only in the child playlist.
                hls_variants(text_request(variant['url']), variant['url'])
                tracks = []
                for track in data.get('streams', [{}])[0].get('subtitles', []):
                    files = {file.get('format'): file.get('url') for file in track.get('files', [])}
                    kind = 'json' if files.get('json') else 'vtt'
                    if files.get(kind, '').startswith('https://'):
                        tracks.append({'language': track.get('language'), 'format': kind, 'url': files[kind]})
                return {'url': variant['url'], 'subtitles': subtitles, 'subtitle_tracks': tracks,
                        'mime': 'application/vnd.apple.mpegurl'}
        raise ProviderError('ČT stream variants changed. Refresh the source list.')
